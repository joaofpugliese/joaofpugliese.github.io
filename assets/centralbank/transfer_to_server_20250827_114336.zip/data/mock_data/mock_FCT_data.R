# ---------------------------------------------- # 
#          Mock FCT Data Generation
# ---------------------------------------------- # 
#
# Creates realistic mock data for testing both cleaning scripts
# with 1 million observations to compare performance and results
# ---------------------------------------------- #

# Packages ---------------------------------------
library(data.table)
library(dplyr)
library(lubridate)

# Set seed for reproducibility -------------------
set.seed(123)

# Parameters ------------------------------------
# Realistic structure: 10 admins x 10 groups per admin x ~100 cotas per group
n_admins <- 10
n_groups_per_admin <- 10
n_cotas_per_group <- 200
n_cotas <- n_admins * n_groups_per_admin * n_cotas_per_group  # = 20,000 cotas
cat("Generating", n_cotas, "unique cotas (", n_admins, "admins x", n_groups_per_admin, "groups x", n_cotas_per_group, "cotas)...\n")

earliest_date <- "201503"
latest_date <- "202503"

# Helper functions -------------------
generate_dates <- function(n, start_date, end_date) {
  dates <- sample(seq(as.Date(start_date), as.Date(end_date), by = "day"), n, replace = TRUE)
  format(dates, "%m/%d/%Y")
}

generate_trimester_dates <- function(years, months = c(3, 6, 9, 12)) {
  paste0(years, sprintf("%02d", months))
}

# Step 1: Generate group start dates from trimesters (201503 to 202503)
# Create all possible trimester dates
generate_trimester_sequence <- function(start_year = 2015, end_year = 2025) {
  trimester_dates <- c()
  
  for(year in start_year:end_year) {
    for(month in c(3, 6, 9, 12)) {
      # Stop at 202503 (March 2025)
      if(year == 2025 && month > 3) break
      
      trimester_dates <- c(trimester_dates, paste0(year, sprintf("%02d", month)))
    }
  }
  
  return(trimester_dates)
}

available_trimesters <- generate_trimester_sequence(2015, 2025)
cat("Available trimester start dates:", length(available_trimesters), "trimesters from", min(available_trimesters), "to", max(available_trimesters), "\n")

# Randomly assign each group to a trimester start date
n_groups_total <- n_admins * n_groups_per_admin
group_start_dates <- data.table(
  adm_cd2 = rep(paste0("ADM", sprintf("%03d", 1:n_admins)), each = n_groups_per_admin),
  gai_cd_grupo2 = paste0("GRP", sprintf("%04d", 1:n_groups_total)),
  group_start_trimester = sample(available_trimesters, n_groups_total, replace = TRUE)
)

cat("Generated", n_groups_total, "groups with trimester start dates\n")
head(group_start_dates, 10)


# Step 1: Generate unique cotas with base characteristics
base_cotas <- data.table(
  # Quota identifiers
  COT_CD_COTA = paste0("COT", sprintf("%06d", 1:n_cotas)),
  
  # Structured group and admin assignments
  adm_cd2 = rep(paste0("ADM", sprintf("%03d", 1:n_admins)), each = n_groups_per_admin * n_cotas_per_group),
  gai_cd_grupo2 = rep(paste0("GRP", sprintf("%04d", 1:(n_admins * n_groups_per_admin))), each = n_cotas_per_group),
  FCT_CD_SEG = sample(paste0("SEG", 1:5), n_cotas, replace = TRUE),  # Fewer segments
  
  # Fixed characteristics
  FCT_DT_ADESAO = generate_dates(n_cotas, "2018-01-01", "2023-12-31"),
  FCT_QT_DUR_PLANO = sample(c(12, 24, 36, 48, 60, 72, 84, 96, 120), n_cotas, replace = TRUE),
  FCT_VL_BEM = round(runif(n_cotas, 10000, 500000), 2),
  
  # Lance: 40% have 0%, others 0-50% rounded to 2 decimals
  FCT_PC_LANCE = ifelse(runif(n_cotas) < 0.4, 0, round(runif(n_cotas, 0.01, 50), 2)),
  
  # Other fixed characteristics
  FCT_PC_TX_ADM = round(runif(n_cotas, 0.5, 3.5), 2),
  FCT_PC_TAX_ADM_ANTEC = round(runif(n_cotas, 0, 2), 2),
  FCT_VL_REN_FAT_MEN_COTISTA = round(runif(n_cotas, 1000, 20000), 2),
  FCT_CD_TIP_COTISTA = sample(1:3, n_cotas, replace = TRUE, prob = c(0.2, 0.7, 0.1)),
  
  # Contemplation info (15% contemplated, must be after adesao)
  will_be_contemplated = runif(n_cotas) < 0.15,
  FCT_IB_CONTEMP = ifelse(runif(n_cotas) < 0.15, sample(c("L", "S"), n_cotas, replace = TRUE), "")
)

# Generate contemplation dates (after adesao)
base_cotas[will_be_contemplated == TRUE, {
  adesao_date <- as.Date(FCT_DT_ADESAO, format = "%m/%d/%Y")
  contemp_date <- adesao_date + sample(30:1095, .N, replace = TRUE)  # 1 month to 3 years after adesao
  FCT_DT_CONTEMP <<- format(contemp_date, "%m/%d/%Y")
}]
base_cotas[will_be_contemplated == FALSE, FCT_DT_CONTEMP := ""]

# Step 2: Create sequence structure for each cota
cota_sequences <- base_cotas[, {
  # Determine number of sequences: 50% have 1, 30% have 2, 20% have 3
  n_seq <- sample(c(1, 2, 3), 1, prob = c(0.5, 0.3, 0.2))
  
  if(n_seq == 1) {
    .(COT_CD_SEQ_COTA = 0)
  } else if(n_seq == 2) {
    .(COT_CD_SEQ_COTA = c(0, sample(1:10, 1)))
  } else {
    .(COT_CD_SEQ_COTA = c(0, sample(1:10, 2, replace = FALSE)))
  }
}, by = .(COT_CD_COTA)]

# Merge sequences back
cotas_with_seq <- merge(base_cotas, cota_sequences, by = "COT_CD_COTA")

# Step 3: Expand each cota across time periods (panel structure with realistic date logic)
mock_data <- cotas_with_seq[, {
  adesao_date <- as.Date(FCT_DT_ADESAO, format = "%m/%d/%Y")
  duration_trimesters <- ceiling(FCT_QT_DUR_PLANO / 3)  # Convert months to trimesters
  
  # Determine if this cota enters the dataset immediately after adesao or with a delay
  # 80% enter immediately (in_df_since_start = TRUE), 20% have a delay (reduced to keep more cotas)
  in_df_since_start <- runif(1) > 0.2
  
  if(in_df_since_start) {
    # First date_base = date_adesao (aligned to trimester)
    start_year <- year(adesao_date)
    start_month <- ifelse(month(adesao_date) <= 3, 3,
                         ifelse(month(adesao_date) <= 6, 6,
                               ifelse(month(adesao_date) <= 9, 9, 12)))
  } else {
    # Random delay: 1-4 trimesters between adesao and first appearance (reduced to keep more cotas)
    delay_trimesters <- sample(1:4, 1)
    
    # Calculate first appearance date
    adesao_year <- year(adesao_date)
    adesao_trimester <- ifelse(month(adesao_date) <= 3, 1,
                              ifelse(month(adesao_date) <= 6, 2,
                                    ifelse(month(adesao_date) <= 9, 3, 4)))
    
    # Add delay
    total_trimesters <- (adesao_year - 2018) * 4 + adesao_trimester + delay_trimesters
    start_year <- 2018 + floor((total_trimesters - 1) / 4)
    start_trimester <- ((total_trimesters - 1) %% 4) + 1
    start_month <- c(3, 6, 9, 12)[start_trimester]
    
    # Make sure we don't go beyond 2024
    if(start_year > 2024) {
      start_year <- 2024
      start_month <- 12
    }
  }
  
  # Create sequence of trimester dates for the duration
  relevant_dates <- c()
  current_year <- start_year
  current_month <- start_month
  
  for(i in 1:duration_trimesters) {
    if(current_year <= 2024) {
      relevant_dates <- c(relevant_dates, paste0(current_year, sprintf("%02d", current_month)))
    }
    
    # Move to next trimester
    current_month <- current_month + 3
    if(current_month > 12) {
      current_month <- 3
      current_year <- current_year + 1
    }
    
    # Stop if we go beyond 2024
    if(current_year > 2024) break
  }
  
  # Ensure every cota gets at least one observation
  if(length(relevant_dates) > 0) {
    .(DAC_DT_BASE = relevant_dates)
  } else {
    # Fallback: give a single observation in 2023Q4
    .(DAC_DT_BASE = "202312")
  }
}, by = .(COT_CD_COTA, COT_CD_SEQ_COTA, FCT_CD_SEG, adm_cd2, gai_cd_grupo2, FCT_DT_ADESAO, 
          FCT_QT_DUR_PLANO, FCT_VL_BEM, FCT_PC_LANCE, FCT_PC_TX_ADM, FCT_PC_TAX_ADM_ANTEC,
          FCT_VL_REN_FAT_MEN_COTISTA, FCT_CD_TIP_COTISTA, FCT_DT_CONTEMP, FCT_IB_CONTEMP)]

# All cotas now guaranteed to have observations (no need to filter empty records)

# Step 4: Add time-varying variables and panel logic
mock_data[, `:=`(
  # Convert DAC_DT_BASE to proper date for calculations
  date_base_calc = as.Date(paste0(DAC_DT_BASE, "01"), format = "%Y%m%d"),
  adesao_date_calc = as.Date(FCT_DT_ADESAO, format = "%m/%d/%Y"),
  contemp_date_calc = as.Date(ifelse(FCT_DT_CONTEMP == "", NA, FCT_DT_CONTEMP), format = "%m/%d/%Y", origin = "1970-01-01")
)]

# Add period number and time-varying variables
mock_data[, `:=`(
  period = .I,
  months_since_adesao = as.numeric(difftime(date_base_calc, adesao_date_calc, units = "days")) / 30.44
), by = .(COT_CD_COTA, COT_CD_SEQ_COTA)]

# Time-varying accumulated values (increase over time)
mock_data[, `:=`(
  FCT_PC_AMO_MENSAL = round(runif(.N, 1, 10), 2),
  FCT_PC_ACU_AMORT = pmin(100, round(months_since_adesao * runif(.N, 1, 3), 2)),
  FCT_VL_CON_ACU_FUN_COMUM = round(months_since_adesao * runif(.N, 100, 1000), 2),
  FCT_VL_CON_ACU_FUN_RESERVA = round(months_since_adesao * runif(.N, 50, 300), 2),
  FCT_VL_CON_ACU_TX_ADM = round(months_since_adesao * runif(.N, 50, 500), 2),
  FCT_VL_CON_ACU_JUR_MULTAS = round(months_since_adesao * runif(.N, 0, 200), 2),
  FCT_PC_ATRASO = round(pmax(0, rnorm(.N, 5, 10)), 2),
  FCT_VL_CRE_DAT_CONTEMP = ifelse(!is.na(contemp_date_calc) & date_base_calc >= contemp_date_calc, 
                                  round(runif(.N, 50000, 300000), 2), 0)
)]

# Initialize cancellation date column
mock_data[, FCT_DT_CAN_COTA := ""]

# Generate cancellation dates (20% get cancelled)
mock_data[, will_cancel := runif(.N) < 0.2, by = .(COT_CD_COTA)]
mock_data[will_cancel == TRUE, {
  # Random cancellation date between adesao and last period
  cancel_date <- adesao_date_calc[1] + sample(30:min(1095, max(months_since_adesao) * 30), 1)
  FCT_DT_CAN_COTA <<- format(cancel_date, "%m/%d/%Y")
}, by = .(COT_CD_COTA)]

# Current status based on logic
mock_data[, FCT_ST_ATUAL := {
  if(FCT_DT_CAN_COTA[1] != "") {
    "CANCELADO"
  } else if(!is.na(contemp_date_calc[1]) && any(date_base_calc >= contemp_date_calc[1])) {
    "CONTEMPLADO"  
  } else if(months_since_adesao[.N] >= FCT_QT_DUR_PLANO[1]) {
    "QUITADO"
  } else {
    "ATIVO"
  }
}, by = .(COT_CD_COTA)]

# Clean up temporary variables
mock_data[, `:=`(date_base_calc = NULL, adesao_date_calc = NULL, contemp_date_calc = NULL, 
                 period = NULL, months_since_adesao = NULL, will_cancel = NULL)]

# Create the mock data file structure --------------------

# First create the directory structure
mock_data_dir <- "mock_data"
if (!dir.exists(mock_data_dir)) {
  dir.create(mock_data_dir, recursive = TRUE)
}

# Create properly formatted output with header row
# Convert mock_data to character matrix to avoid type conflicts
mock_data_char <- mock_data[, lapply(.SD, as.character)]

# Create header row as first row
header_row <- data.table(t(names(mock_data)))
setnames(header_row, names(mock_data_char))

# Combine header and data
test_data <- rbindlist(list(header_row, mock_data_char))

# Export mock data ------------------------------
mock_file_path <- file.path(mock_data_dir, "mock_FCT_data.txt")

# Write as tab-delimited file (like original)
fwrite(test_data, mock_file_path, sep = "\t", col.names = FALSE, na = "")

# Create summary statistics ----------------------
cat("\n=== Mock Data Generation Summary ===\n")
cat("Total observations:", nrow(mock_data), "\n")
cat("Total columns:", ncol(mock_data), "\n")
cat("File size:", round(file.size(mock_file_path) / 1024^2, 2), "MB\n")
cat("File location:", mock_file_path, "\n")

# Data quality checks
cat("\n=== Data Quality Checks ===\n")
cat("Unique adm_ids:", mock_data[, uniqueN(adm_cd2)], "\n")
cat("Unique grupo_ids:", mock_data[, uniqueN(gai_cd_grupo2)], "\n")
cat("Unique cota_ids:", mock_data[, uniqueN(COT_CD_COTA)], "\n")
cat("Total cota-sequence combinations:", mock_data[, uniqueN(paste(COT_CD_COTA, COT_CD_SEQ_COTA))], "\n")
cat("Contemplated records:", mock_data[FCT_ST_ATUAL == "CONTEMPLADO", .N], "\n")
cat("Cancelled records:", mock_data[FCT_ST_ATUAL == "CANCELADO", .N], "\n")

# Check date_adesao vs date_base relationship
cat("\n=== Date Relationship Checks ===\n")
mock_data[, `:=`(
  date_adesao_calc = as.Date(FCT_DT_ADESAO, format = "%m/%d/%Y"),
  date_base_calc = as.Date(paste0(DAC_DT_BASE, "01"), format = "%Y%m%d")
)]

adesao_before_base_pct <- round(100 * mock_data[, mean(date_adesao_calc <= date_base_calc)], 1)
cat("Records where date_adesao <= date_base:", adesao_before_base_pct, "%\n")

# Check first appearances
first_appearances <- mock_data[, .(
  first_date_base = min(date_base_calc),
  date_adesao = first(date_adesao_calc)
), by = .(COT_CD_COTA, COT_CD_SEQ_COTA)]

immediate_entry_pct <- round(100 * first_appearances[, mean(date_adesao == first_date_base)], 1)
cat("Cotas entering immediately (date_adesao = first_date_base):", immediate_entry_pct, "%\n")

# Panel structure
cat("\n=== Panel Structure ===\n")
obs_per_cota <- mock_data[, .N, by = .(COT_CD_COTA, COT_CD_SEQ_COTA)]
cat("Avg observations per cota-sequence:", round(mean(obs_per_cota$N), 1), "\n")
cat("Min observations per cota-sequence:", min(obs_per_cota$N), "\n")
cat("Max observations per cota-sequence:", max(obs_per_cota$N), "\n")

# Clean up temporary variables
mock_data[, `:=`(date_adesao_calc = NULL, date_base_calc = NULL)]

# Show sample of data
cat("\n=== Sample Data (first 5 rows) ===\n")
print(mock_data[1:5, .(DAC_DT_BASE, FCT_DT_ADESAO, adm_cd2, gai_cd_grupo2, COT_CD_COTA, 
                       COT_CD_SEQ_COTA, FCT_QT_DUR_PLANO, FCT_ST_ATUAL)])

cat("\n=== Structure Verification ===\n")
cat("Expected structure: Each admin has", n_groups_per_admin, "groups, each group has", n_cotas_per_group, "cotas\n")
cat("Cotas per group verification:\n")
cotas_per_group_check <- mock_data[, uniqueN(COT_CD_COTA), by = .(adm_cd2, gai_cd_grupo2)]
cat("Min cotas per group:", min(cotas_per_group_check$V1), "\n")
cat("Max cotas per group:", max(cotas_per_group_check$V1), "\n")

cat("\n=== Mock data generation completed successfully! ===\n")
cat("You can now test both cleaning scripts on this data.\n")
