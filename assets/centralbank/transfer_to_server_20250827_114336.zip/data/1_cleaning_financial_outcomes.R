
# ---------------------------------------------- # 
#       Data cleaning - Financial Outcomes 
# ---------------------------------------------- # 

# Packages ---------------------------------------

library(dplyr)
library(ggplot2)
library(lubridate)


# Interest rate data -----------------------------

filename2 <- file.path(data_path, "seriessgs.csv")
juros_raw <- read.csv("D:/bases/seriessgs.csv", sep = ";", header = FALSE)

colnames(juros_raw) <- as.character(juros_raw[1,])
juros_raw <- juros_raw[-1,]

juros <- juros_raw %>% 
  slice(-n()) %>% 
  rename(
    selic = !!names(.)[2],
    cdi = !!names(.)[3]
  ) %>% 
  mutate(
    year = substr(Data, 4, 7) %>% as.numeric(),
    month = substr(Data, 1, 2) %>% as.numeric(),
    temp_date = make_date(year, month, 1),
    date_base = temp_date %m+% months(1) - days(1),
    selic = as.numeric(gsub(",", ".", selic)),
    cdi = as.numeric(gsub(",", ".", cdi))
  ) %>% 
  select(year, month, date_base, selic, cdi)


# Consórcios data -------------------------------

# Importing clean dataset (general)

df <- readRDS("D:/_main/data/treated_data/FCT_general_clean.rds")

# Create variable with positive entries (credit)

df <- df %>% 
  mutate(
    cash_positive = contemp_in_quarter * credit_contemp,
    cash_positive = ifelse(is.na(cash_positive), 0, cash_positive)
  )

# Create variable for negative entries

df <- df %>% 
  mutate(
    cumul_payments = fundo_comum_acumul + fundo_reserva_acumul + 
      tx_adm_acumul + juros_multas_acumul
  ) %>%
  group_by(adm_id, grupo_id, cota_id, cpf_fake_id) %>%
  mutate(
    variation_payments = cumul_payments - lag(cumul_payments, default = 0),
    cash_negative = ifelse(is.na(lag(cumul_payments)), cumul_payments, variation_payments)
  ) %>%
  ungroup()

# Create net flow

df <- df %>% 
  mutate(
    cash_net = cash_positive - cash_negative
  )

# Keep only active quotas

df <- df %>% 
  filter(sit_atual == 1)


# Exporting to .rds and .csv ------------------------------

saveRDS(df, "D:/_main/data/treated_data/FCT_financial_outcomes_clean.rds")
write.csv(df, "D:/_main/data/treated_data/FCT_financial_outcomes_clean.csv", row.names = FALSE)

