
# ---------------------------------------------- # 
#            Bid and Lotteries Analysis
# ---------------------------------------------- # 

# Packages ---------------------------------------

library(dplyr)
library(ggplot2)
library(lubridate)
library(tidyr)
library(ggplot2)

# Set paths, working directory and df ------------

data_path <- "D:/bases"
personal_path <- "C:/Users/depep.leonardozs/Documents/main"
import_path <- file.path(personal_path, "data", "treated_data")
results_path <- file.path(personal_path, "results", "graphs")

# Create results directory if it doesn't exist
if (!dir.exists(results_path)) {
  dir.create(results_path, recursive = TRUE)
}

# Importing dataset
filename <- file.path(import_path, "registro_cotas_clean.rds")
df <- readRDS(filename)


# 1. Overall allocation over the years ---------------

df <- mock_data

# Filter only contemplated quotas (auction or lottery)
contemplations <- df %>%
  filter(allocation_type %in% c("L", "S")) %>%  # Only contemplations
  mutate(
    year_month = sprintf("%04d-%02d", year, month)
  )

# Get group sizes
group_sizes <- df %>%
  group_by(grupo_id) %>%
  summarise(group_size = n_distinct(cota_id), .groups = "drop")

# Group by group, year-month, and allocation type (with segment info)
allocation_counts <- contemplations %>%
  group_by(grupo_id, codigo_seg, year_month, allocation_type) %>%
  summarise(n_contemplations = n(), .groups = "drop")

# Reshape to wide and compute share
shares <- allocation_counts %>%
  pivot_wider(
    names_from = allocation_type,
    values_from = n_contemplations,
    values_fill = 0
  ) %>%
  mutate(
    total = L + S,
    lottery_share = S / total
  ) %>%
  # Add group size information
  left_join(group_sizes, by = "grupo_id")

# Plot for specific group - evolution over time
selected_group <- 2

plot_group_evolution <- df %>%
  filter(grupo_id == selected_group) %>%
  group_by(date_base) %>%
  summarise(
    total_quotas = n_distinct(cota_id),
    total_contemplated = sum(!is.na(allocation_type), na.rm = TRUE),
    lottery_contemplated = sum(allocation_type == "S", na.rm = TRUE),
    auction_contemplated = sum(allocation_type == "L", na.rm = TRUE),
    .groups = "drop"
  ) %>%
  ggplot(aes(x = date_base)) +
  geom_line(aes(y = total_quotas), linetype = "dotted", color = "black", size = 1) +
  geom_line(aes(y = total_contemplated), linetype = "solid", color = "black", size = 1) +
  geom_line(aes(y = lottery_contemplated), linetype = "solid", color = "blue", size = 1) +
  geom_line(aes(y = auction_contemplated), linetype = "solid", color = "red", size = 1) +
  labs(
    title = paste("Group", selected_group, "- Evolution of Contemplations Over Time"),
    x = "Date",
    y = "Number of Quotas"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1)
  ) +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 6))

plot_group_evolution

# 2. Segment analysis with normalized time deciles ---------------

# Create normalized time analysis for segments
segment_normalized <- df %>%
  filter(allocation_type %in% c("L", "S")) %>%
  group_by(grupo_id) %>%
  mutate(
    # Use correct group lifecycle metrics
    group_start_date = min(date_adesao, na.rm = TRUE),  # Real group start date
    group_end_date = max(date_base, na.rm = TRUE),      # Last quarter of group
    group_duration_days = as.numeric(group_end_date - group_start_date),
    
    # Calculate when contemplation happened relative to group life
    contemp_days_since_start = as.numeric(date_contemp - group_start_date),
    
    # Normalized time as fraction of actual group life [0, 1]
    normalized_time = contemp_days_since_start / group_duration_days,
    
    # Ensure normalized_time is within [0, 1] bounds
    normalized_time = pmax(0, pmin(1, normalized_time)),
    
    # Create deciles (10% bins) based on when contemplation occurred
    time_decile = case_when(
      normalized_time <= 0.1 ~ "0-10%",
      normalized_time <= 0.2 ~ "10-20%",
      normalized_time <= 0.3 ~ "20-30%",
      normalized_time <= 0.4 ~ "30-40%",
      normalized_time <= 0.5 ~ "40-50%",
      normalized_time <= 0.6 ~ "50-60%",
      normalized_time <= 0.7 ~ "60-70%",
      normalized_time <= 0.8 ~ "70-80%",
      normalized_time <= 0.9 ~ "80-90%",
      TRUE ~ "90-100%"
    ),
    # Order factor for proper plotting
    time_decile = factor(time_decile, levels = c("0-10%", "10-20%", "20-30%", "30-40%", "40-50%", 
                                                 "50-60%", "60-70%", "70-80%", "80-90%", "90-100%"))
  ) %>%
  ungroup()

# Create segment-level aggregation by normalized time
segment_shares <- segment_normalized %>%
  group_by(codigo_seg, time_decile, allocation_type) %>%
  summarise(n_contemplations = n(), .groups = "drop") %>%
  pivot_wider(
    names_from = allocation_type,
    values_from = n_contemplations,
    values_fill = 0
  ) %>%
  mutate(
    total = L + S,
    lottery_share = S / total
  ) %>%
  # Add number of groups contributing to each decile
  left_join(
    segment_normalized %>%
      group_by(codigo_seg, time_decile) %>%
      summarise(n_groups_contributing = n_distinct(grupo_id), .groups = "drop"),
    by = c("codigo_seg", "time_decile")
  )

# 2.1. Segment evolution plot 

# Choose segment to analyze (change this value to analyze different segments)
selected_segment <- 11  # 11=Imóveis, 31=Veículos pesados, 41=Veículos leves

# Use existing segment_shares data for the selected segment
segment_plot_data <- segment_shares %>%
  filter(codigo_seg == selected_segment) %>%
  # Convert time_decile to numeric for plotting
  mutate(
    time_percent = case_when(
      time_decile == "0-10%" ~ 5,
      time_decile == "10-20%" ~ 15,
      time_decile == "20-30%" ~ 25,
      time_decile == "30-40%" ~ 35,
      time_decile == "40-50%" ~ 45,
      time_decile == "50-60%" ~ 55,
      time_decile == "60-70%" ~ 65,
      time_decile == "70-80%" ~ 75,
      time_decile == "80-90%" ~ 85,
      time_decile == "90-100%" ~ 95
    ),
    # Calculate total quotas available in each decile (for dotted line)
    # Estimate based on groups contributing
    total_quotas_decile = n_groups_contributing * 10  # Approximate
  ) %>%
  arrange(time_percent)

# Create the segment evolution plot using segment_shares
plot_segment_evolution <- ggplot(segment_plot_data, aes(x = time_percent)) +
  # Total quotas (dotted black line) - approximate baseline
  geom_line(aes(y = total_quotas_decile), 
            linetype = "dotted", color = "black", size = 1.2, alpha = 0.8) +
  # Total contemplated (solid black line)
  geom_line(aes(y = total), 
            linetype = "solid", color = "black", size = 1.2) +
  # Lottery contemplated (blue line)
  geom_line(aes(y = S), 
            linetype = "solid", color = "blue", size = 1.2) +
  # Auction contemplated (red line)
  geom_line(aes(y = L), 
            linetype = "solid", color = "red", size = 1.2) +
  # Add points for better visibility
  geom_point(aes(y = total_quotas_decile), color = "black", alpha = 0.6, size = 1) +
  geom_point(aes(y = total), color = "black", size = 1) +
  geom_point(aes(y = S), color = "blue", size = 1) +
  geom_point(aes(y = L), color = "red", size = 1) +
  # Labels and formatting
  labs(
    title = paste("Segment", selected_segment, "- Evolution of Contemplations Over Group Lifecycle"),
    subtitle = "Black dotted: Total quotas | Black solid: Total contemplated | Blue: Lottery | Red: Auction",
    x = "Group Duration (%)",
    y = "Number of Contemplations"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
    plot.subtitle = element_text(hjust = 0.5, size = 11, color = "gray40"),
    axis.text = element_text(size = 10),
    axis.title = element_text(size = 12),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_line(color = "gray90", size = 0.5),
    panel.grid.major.y = element_line(color = "gray90", size = 0.5)
  ) +
  scale_x_continuous(
    breaks = seq(0, 100, 10),
    labels = paste0(seq(0, 100, 10), "%"),
    limits = c(0, 100)
  ) +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 8))

# Display the plot
plot_segment_evolution

# Print summary statistics for the selected segment
cat("\n=== SEGMENT", selected_segment, "SUMMARY ===\n")
cat("Segment description:", 
    case_when(
      selected_segment == 11 ~ "Imóveis (R$ 300,000)",
      selected_segment == 31 ~ "Veículos pesados (R$ 50,000)", 
      selected_segment == 41 ~ "Veículos leves (R$ 15,000)",
      TRUE ~ "Unknown segment"
    ), "\n")

# Show data used in plot
print(segment_plot_data)

# Show overall segment statistics
segment_totals <- segment_shares %>%
  filter(codigo_seg == selected_segment) %>%
  summarise(
    total_contemplated = sum(total, na.rm = TRUE),
    total_lottery = sum(S, na.rm = TRUE),
    total_auction = sum(L, na.rm = TRUE),
    lottery_share = round(total_lottery / total_contemplated * 100, 1),
    .groups = "drop"
  )

cat("Total contemplated:", segment_totals$total_contemplated, "\n")
cat("Total lottery:", segment_totals$total_lottery, "\n")
cat("Total auction:", segment_totals$total_auction, "\n")
cat("Lottery share:", paste0(segment_totals$lottery_share, "%"), "\n")











# Plot temporal evolution by segment
plot_temporal <- ggplot(shares, aes(x = year_month, y = lottery_share, color = factor(codigo_seg))) +
  geom_line(aes(group = codigo_seg), size = 1) +
  geom_point(size = 2) +
  labs(
    title = "Evolution of Lottery Share Over Time by Segment",
    x = "Year-Month",
    y = "Lottery Share",
    color = "Segment Code"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "bottom"
  ) +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent) +
  scale_x_discrete(breaks = function(x) x[seq(1, length(x), by = 6)])  # Show every 6 months

# Save plot
figname_temporal <- file.path(results_path, "lottery_share_temporal.pdf")
ggsave(figname_temporal, plot_temporal, width = 14, height = 8, units = "in")


# 2. Within-group, over group lifetime ---------------

# Calculate shares for each group over their entire lifetime
group_shares <- df %>%
  filter(allocation_type %in% c("L", "S")) %>%  # Only contemplations
  group_by(codigo_seg, grupo_id) %>%
  summarise(
    auctions = sum(allocation_type == "L", na.rm = TRUE),
    lotteries = sum(allocation_type == "S", na.rm = TRUE),
    total = auctions + lotteries,
    lottery_share = lotteries / total,
    .groups = "drop"
  ) %>%
  filter(total > 0)  # Remove groups with no contemplations

# Plot distribution of lottery shares by segment
plot_distribution <- ggplot(group_shares, aes(x = lottery_share, fill = factor(codigo_seg))) +
  geom_histogram(bins = 20, alpha = 0.7, position = "identity") +
  facet_wrap(~ codigo_seg, labeller = labeller(codigo_seg = function(x) paste("Segment", x))) +
  labs(
    title = "Distribution of Lottery Shares Across Groups by Segment",
    x = "Lottery Share",
    y = "Number of Groups",
    fill = "Segment Code"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    legend.position = "none"
  ) +
  scale_x_continuous(labels = scales::percent)

# Save plot
figname_distribution <- file.path(results_path, "lottery_share_distribution.pdf")
ggsave(figname_distribution, plot_distribution, width = 12, height = 8, units = "in")



# 3. Flow analysis - Overall allocation over the years ---------------

# Identify actual contemplation events (using date_contemp)
flow_contemplations <- df %>%
  filter(!is.na(date_contemp) & allocation_type %in% c("L", "S")) %>%
  mutate(
    contemp_year_month = sprintf("%04d-%02d", year(date_contemp), month(date_contemp)),
    current_year_month = sprintf("%04d-%02d", year, month)
  ) %>%
  # Keep only observations where current month equals contemplation month
  filter(contemp_year_month == current_year_month)

# Group by segment, contemplation year-month, and allocation type
flow_allocation_counts <- flow_contemplations %>%
  group_by(codigo_seg, contemp_year_month, allocation_type) %>%
  summarise(n_contemplations = n(), .groups = "drop")

# Reshape to wide and compute share
flow_shares <- flow_allocation_counts %>%
  pivot_wider(
    names_from = allocation_type,
    values_from = n_contemplations,
    values_fill = 0
  ) %>%
  mutate(
    total = L + S,
    lottery_share = ifelse(total > 0, S / total, NA_real_)
  )

# Plot temporal evolution by segment (flow)
plot_temporal_flow <- ggplot(flow_shares, aes(x = contemp_year_month, y = lottery_share, color = factor(codigo_seg))) +
  geom_line(aes(group = codigo_seg), size = 1) +
  geom_point(size = 2) +
  labs(
    title = "Evolution of Lottery Share Over Time by Segment (Flow Analysis)",
    x = "Contemplation Year-Month",
    y = "Lottery Share",
    color = "Segment Code"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "bottom"
  ) +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent) +
  scale_x_discrete(breaks = function(x) x[seq(1, length(x), by = 6)])  # Show every 6 months

# Save plot
figname_temporal_flow <- file.path(results_path, "lottery_share_temporal_flow.pdf")
ggsave(figname_temporal_flow, plot_temporal_flow, width = 14, height = 8, units = "in")


# 4. Flow analysis - Within-group over group lifetime ---------------

# Calculate flow-based shares for each group
flow_group_shares <- df %>%
  filter(!is.na(date_contemp) & allocation_type %in% c("L", "S")) %>%
  mutate(
    contemp_year_month = sprintf("%04d-%02d", year(date_contemp), month(date_contemp)),
    current_year_month = sprintf("%04d-%02d", year, month)
  ) %>%
  # Keep only observations where current month equals contemplation month
  filter(contemp_year_month == current_year_month) %>%
  group_by(codigo_seg, grupo_id) %>%
  summarise(
    auctions = sum(allocation_type == "L", na.rm = TRUE),
    lotteries = sum(allocation_type == "S", na.rm = TRUE),
    total = auctions + lotteries,
    lottery_share = ifelse(total > 0, lotteries / total, NA_real_),
    .groups = "drop"
  ) %>%
  filter(total > 0)  # Remove groups with no contemplations

# Plot distribution of lottery shares by segment (flow)
plot_distribution_flow <- ggplot(flow_group_shares, aes(x = lottery_share, fill = factor(codigo_seg))) +
  geom_histogram(bins = 20, alpha = 0.7, position = "identity") +
  facet_wrap(~ codigo_seg, labeller = labeller(codigo_seg = function(x) paste("Segment", x))) +
  labs(
    title = "Distribution of Lottery Shares Across Groups by Segment (Flow Analysis)",
    x = "Lottery Share",
    y = "Number of Groups",
    fill = "Segment Code"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    legend.position = "none"
  ) +
  scale_x_continuous(labels = scales::percent)

# Save plot
figname_distribution_flow <- file.path(results_path, "lottery_share_distribution_flow.pdf")
ggsave(figname_distribution_flow, plot_distribution_flow, width = 12, height = 8, units = "in")


# 5. Normalized duration analysis - Overall allocation over group lifecycle ---------------

# Filter contemplations and calculate normalized time bins
normalized_contemplations <- df %>%
  filter(!is.na(date_contemp) & allocation_type %in% c("L", "S")) %>%
  mutate(
    contemp_year_month = sprintf("%04d-%02d", year(date_contemp), month(date_contemp)),
    current_year_month = sprintf("%04d-%02d", year, month)
  ) %>%
  # Keep only observations where current month equals contemplation month
  filter(contemp_year_month == current_year_month) %>%
  group_by(grupo_id) %>%
  mutate(
    # Calculate normalized time for each contemplation
    group_start_date = min(date_adesao, na.rm = TRUE),
    group_end_date = max(date_base, na.rm = TRUE),
    group_duration_days = as.numeric(group_end_date - group_start_date),
    contemp_days_since_start = as.numeric(date_contemp - group_start_date),
    normalized_time = pmax(0, pmin(1, contemp_days_since_start / group_duration_days)),
    
    # Create progress bins (same as time_decile)
    progress_bin = case_when(
      normalized_time <= 0.1 ~ "0-10%",
      normalized_time <= 0.2 ~ "10-20%",
      normalized_time <= 0.3 ~ "20-30%",
      normalized_time <= 0.4 ~ "30-40%",
      normalized_time <= 0.5 ~ "40-50%",
      normalized_time <= 0.6 ~ "50-60%",
      normalized_time <= 0.7 ~ "60-70%",
      normalized_time <= 0.8 ~ "70-80%",
      normalized_time <= 0.9 ~ "80-90%",
      TRUE ~ "90-100%"
    ),
    progress_bin = factor(progress_bin, levels = c("0-10%", "10-20%", "20-30%", "30-40%", "40-50%", 
                                                   "50-60%", "60-70%", "70-80%", "80-90%", "90-100%"))
  ) %>%
  ungroup()

# Group by segment, progress bin, and allocation type
normalized_allocation_counts <- normalized_contemplations %>%
  group_by(codigo_seg, progress_bin, allocation_type) %>%
  summarise(n_contemplations = n(), .groups = "drop")

# Reshape to wide and compute share
normalized_shares <- normalized_allocation_counts %>%
  pivot_wider(
    names_from = allocation_type,
    values_from = n_contemplations,
    values_fill = 0
  ) %>%
  mutate(
    total = L + S,
    lottery_share = ifelse(total > 0, S / total, NA_real_)
  )

# Plot evolution over normalized group lifecycle
plot_normalized <- ggplot(normalized_shares, aes(x = progress_bin, y = lottery_share, color = factor(codigo_seg), group = codigo_seg)) +
  geom_line(size = 1) +
  geom_point(size = 3) +
  labs(
    title = "Lottery Share Over Normalized Group Lifecycle",
    x = "Group Progress (% of Duration)",
    y = "Lottery Share",
    color = "Segment Code"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "bottom"
  ) +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent)

# Save plot
figname_normalized <- file.path(results_path, "lottery_share_normalized_lifecycle.pdf")
ggsave(figname_normalized, plot_normalized, width = 14, height = 8, units = "in")


# Export all results ---------------

# Export aggregated analysis results
outfile_temporal <- file.path(import_path, "allocation_shares_temporal.csv")
write.csv(shares, outfile_temporal, row.names = FALSE)

outfile_groups <- file.path(import_path, "allocation_shares_groups.csv")
write.csv(group_shares, outfile_groups, row.names = FALSE)

# Export flow analysis results
outfile_temporal_flow <- file.path(import_path, "allocation_shares_temporal_flow.csv")
write.csv(flow_shares, outfile_temporal_flow, row.names = FALSE)

outfile_groups_flow <- file.path(import_path, "allocation_shares_groups_flow.csv")
write.csv(flow_group_shares, outfile_groups_flow, row.names = FALSE)

# Export normalized duration analysis results
outfile_normalized <- file.path(import_path, "allocation_shares_normalized_lifecycle.csv")
write.csv(normalized_shares, outfile_normalized, row.names = FALSE)



