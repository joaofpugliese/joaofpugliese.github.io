# Central Bank session initialization script
# • Input: none (uses standard folder structure)  
# • Output: inbound folder analysis and overlap detection report

# Load utilities
setwd("data/code/centralbank/server")
source("utils/inbound_analyzer.R")

# Analyze inbound folder
result <- analyze_inbound(
  inbound_path = "inbound",
  base_path = ".."  # Go up to centralbank/ root
)

cat("\n=== INITIALIZATION COMPLETE ===\n")
cat("Files analyzed:", length(result$files_final), "\n")
cat("Overlaps found:", length(result$overlaps), "\n")
