# ---------------------------------------------- # 
# Data description
# ---------------------------------------------- # 

#' Generate consortium data summary statistics
#' 
#' Computes counts, rates, and temporal distributions for consortium database.
#' 
#' @param df Data.frame. Consortium data with standard columns
#' @param col_dict List. Maps standard names to actual column names (auto-detected if NULL)
#' The standard list defaults are:
#'   \itemize{
#'     \item cpf: "cpf_fake_id" (CPF/participant identifiers)
#'     \item cota: "cota_id" (basic quota identifiers)
#'     \\item cota_seq: "cota_full_id" (full quota identifiers with sequence)
#'     \\item grupo: "grupo_id" (group identifiers)
#'     \\item adm: "adm_id" (administrator identifiers)
#'     \\item segment: "codigo_seg" (segment identifiers)
#'     \\item year: "year" (year variable)
#' }
#' @param output_file Character. Path for .txt output (console if NULL)
#' @param dataset_name Character. Dataset name for report title
#' @return List with counts, rates, yearly distributions, and segment breakdowns
#' @examples
#' data_description(df)
#' data_description(df, output_file = "summary.txt")
#' @export

data_description <- function(df, col_dict = NULL, output_file = NULL, dataset_name = NULL) {
  
  # Load required packages
  if (!require("dplyr", quietly = TRUE)) {
    stop("Package 'dplyr' is required but not installed.")
  }
  if (!require("data.table", quietly = TRUE)) {
    stop("Package 'data.table' is required but not installed.")
  }
  
  # Set standard column names and auto-detect if needed
  if (is.null(col_dict)) {
    col_dict <- list(
      cpf = "cpf_fake_id",
      cota = "cota_id", 
      cota_seq = "cota_full_id",
      grupo = "grupo_id",
      adm = "adm_id",
      segment = "codigo_seg",
      year = "year"
    )
    
    # Auto-detect columns using candidate lists
    candidates <- list(
      cpf = c("cpf_fake_id", "CTC_CD_COTISTA2", "CTC_CD_COTISTA", "participant_id"),
      cota = c("cota_id", "COT_CD_COTA", "quota_id"),
      cota_seq = c("cota_full_id", "cota_id", "COT_CD_COTA", "quota_full_id"),
      grupo = c("grupo_id", "gai_cd_grupo2", "group_id"),
      adm = c("adm_id", "adm_cd2", "admin_id"),
      segment = c("codigo_seg", "FCT_CD_SEG", "segment_id", "segment"),
      year = c("year", "ano", "YEAR")
    )
    
    for (key in names(candidates)) {
      if (!(col_dict[[key]] %in% names(df))) {
        col_dict[[key]] <- candidates[[key]][candidates[[key]] %in% names(df)][1]
      }
    }
  }
  
  # Validate that required columns exist
  missing_cols <- character(0)
  for (key in names(col_dict)) {
    if (is.na(col_dict[[key]]) || !(col_dict[[key]] %in% names(df))) {
      missing_cols <- c(missing_cols, paste0(key, " (", col_dict[[key]], ")"))
    }
  }
  
  if (length(missing_cols) > 0) {
    stop("Missing required columns: ", paste(missing_cols, collapse = ", "))
  }
  
  # Convert to data.table for faster operations
  dt <- data.table::as.data.table(df)
  
  # Create shorter variable names for cleaner code
  cpf_col <- col_dict$cpf
  cota_col <- col_dict$cota
  cota_seq_col <- col_dict$cota_seq
  grupo_col <- col_dict$grupo
  adm_col <- col_dict$adm
  segment_col <- col_dict$segment
  year_col <- col_dict$year
  
  # Calculate unique counts using data.table (much faster than dplyr distinct operations)
  n_cpfs <- dt[!is.na(get(cpf_col)), uniqueN(get(cpf_col))]
  
  n_cotas <- dt[!is.na(get(cota_col)) & !is.na(get(grupo_col)) & 
                !is.na(get(adm_col)) & !is.na(get(segment_col)), 
                uniqueN(paste(get(cota_col), get(grupo_col), get(adm_col), get(segment_col)))]
  
  n_cotas_seq <- dt[!is.na(get(cota_seq_col)) & !is.na(get(grupo_col)) & 
                    !is.na(get(adm_col)) & !is.na(get(segment_col)), 
                    uniqueN(paste(get(cota_seq_col), get(grupo_col), get(adm_col), get(segment_col)))]
  
  n_grupos <- dt[!is.na(get(grupo_col)), uniqueN(get(grupo_col))]
  
  n_administradores <- dt[!is.na(get(adm_col)), uniqueN(get(adm_col))]
  
  # Calculate cotas-seq per year using data.table
  cotas_por_ano <- dt[!is.na(get(cota_seq_col)) & !is.na(get(year_col)) & 
                      !is.na(get(grupo_col)) & !is.na(get(adm_col)) & !is.na(get(segment_col)), 
                      .(n_cotas_unicas = uniqueN(paste(get(cota_seq_col), get(grupo_col), 
                                                      get(adm_col), get(segment_col)))), 
                      by = get(year_col)]
  data.table::setnames(cotas_por_ano, "get", "year")
  data.table::setorder(cotas_por_ano, year)
  cotas_por_ano <- as.data.frame(cotas_por_ano)  # Convert back to data.frame for compatibility
  
  # Calculate all rates at once
  rates <- list(
    cotas_per_group_avg = round(n_cotas / n_grupos, 3),
    unique_cotas_per_unique_cpf_avg = round(n_cotas_seq / n_cpfs, 3),
    seq_per_cota_avg = round(n_cotas_seq / n_cotas, 3),
    groups_per_admin_avg = round(n_grupos / n_administradores, 3),
    cotas_per_admin_avg = round(n_cotas / n_administradores, 3)
  )
  
  # Calculate CPFs per cota_full_id using data.table
  cpfs_per_cota_full_id <- dt[!is.na(get(cpf_col)) & !is.na(get(cota_seq_col)) & 
                              !is.na(get(grupo_col)) & !is.na(get(adm_col)) & !is.na(get(segment_col)), 
                              .(n_cpfs_in_cota = uniqueN(get(cpf_col))), 
                              by = .(get(cota_seq_col), get(grupo_col), get(adm_col), get(segment_col))][
                              , round(mean(n_cpfs_in_cota), 2)]
  
  # Calculate segment-level statistics using data.table
  groups_per_segment <- dt[!is.na(get(grupo_col)) & !is.na(get(segment_col)), 
                           .(n_groups = uniqueN(get(grupo_col))), 
                           by = get(segment_col)]
  data.table::setnames(groups_per_segment, "get", "segment")
  data.table::setorder(groups_per_segment, segment)
  groups_per_segment <- as.data.frame(groups_per_segment)  # Convert back to data.frame
  
  cotas_per_segment <- dt[!is.na(get(cota_col)) & !is.na(get(grupo_col)) & 
                          !is.na(get(adm_col)) & !is.na(get(segment_col)), 
                          .(n_cotas = uniqueN(paste(get(cota_col), get(grupo_col), 
                                                   get(adm_col), get(segment_col)))), 
                          by = get(segment_col)]
  data.table::setnames(cotas_per_segment, "get", "segment")
  data.table::setorder(cotas_per_segment, segment)
  cotas_per_segment <- as.data.frame(cotas_per_segment)  # Convert back to data.frame
  
  # Build output content efficiently
  if (is.null(dataset_name)) dataset_name <- "Consortium Dataset"
  current_time <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  
  # Helper function to format table rows
  format_table <- function(data, val_col) {
    sprintf("%s\t%s", data$segment, format(data[[val_col]], big.mark = ","))
  }
  
  # Build output sections
  header <- c(
    sprintf("=== %s DATA DESCRIPTION ===", toupper(dataset_name)),
    sprintf("Generated on: %s", current_time),
    "",
    sprintf("Total rows: %s", format(nrow(df), big.mark = ",")),
    ""
  )
  
  counts <- c(
    sprintf("Total unique CPFs/Participants: %s", format(n_cpfs, big.mark = ",")),
    sprintf("Total unique Cotas (cota_id within group-adm-segment): %s", format(n_cotas, big.mark = ",")),
    sprintf("Total unique Cotas-seq (cota_full_id within group-adm-segment): %s", format(n_cotas_seq, big.mark = ",")), 
    sprintf("Total unique Groups: %s", format(n_grupos, big.mark = ",")),
    sprintf("Total unique Administrators: %s", format(n_administradores, big.mark = ",")),
    ""
  )
  
  rate_section <- c(
    "=== AVERAGE RATES ===",
    sprintf("Cotas per group (avg.): %.2f", rates$cotas_per_group_avg),
    sprintf("Unique cotas per unique CPF (avg.): %.2f", rates$unique_cotas_per_unique_cpf_avg),
    sprintf("Seq per cota (avg.): %.2f", rates$seq_per_cota_avg),
    sprintf("Groups per admin (avg.): %.2f", rates$groups_per_admin_avg),
    sprintf("Cotas per admin (avg.): %.2f", rates$cotas_per_admin_avg),
    sprintf("Participants per cota-cota_seq (avg.): %.2f", cpfs_per_cota_full_id),
    ""
  )
  
  groups_section <- c(
    "=== GROUPS PER SEGMENT ===",
    "Segment\tGroups",
    "-------\t------",
    format_table(groups_per_segment, "n_groups"),
    ""
  )
  
  cotas_section <- c(
    "=== COTAS PER SEGMENT ===",
    "Segment\tCotas",
    "-------\t-----",
    format_table(cotas_per_segment, "n_cotas"),
    ""
  )
  
  yearly_section <- c(
    "=== UNIQUE COTAS-SEQ COMBINATIONS PER YEAR ===",
    "Year\tUnique Cotas-seq",
    "----\t----------------",
    sprintf("%d\t%s", cotas_por_ano$year, format(cotas_por_ano$n_cotas_unicas, big.mark = ",")),
    "",
    sprintf("Total across all years: %s", format(n_cotas_seq, big.mark = ","))
  )
  
  output_lines <- c(header, counts, rate_section, groups_section, cotas_section, yearly_section)
  
  # Output to file or console
  if (!is.null(output_file)) {
    # Write to .txt file
    writeLines(output_lines, output_file)
    cat(sprintf("Data description saved to: %s\n", output_file))
  } else {
    # Print to console
    cat(paste(output_lines, collapse = "\n"))
    cat("\n")
  }
  
  # Return comprehensive results
  return(c(
    list(
      n_cpfs = n_cpfs,
      n_cotas = n_cotas,
      n_cotas_seq = n_cotas_seq,
      n_grupos = n_grupos,
      n_administradores = n_administradores,
      cotas_por_ano = cotas_por_ano,
      cpfs_per_cota_full_id = cpfs_per_cota_full_id,
      groups_per_segment = groups_per_segment,
      cotas_per_segment = cotas_per_segment
    ),
    rates  # Unpack rates list to maintain backward compatibility
  ))
}