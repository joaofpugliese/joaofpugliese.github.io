"""
Author: Otavio Braga
Date: July 24, 2025
"""


########## SETUP ##########

# Setting up useful packages
import numpy as np
import pandas as pd
import os

# Set paths and working directory
data_path = "D:/bases"
personal_path = "C:/Users/depep.otaviomb2/Documents/main"
export_path = personal_path + "/data/treated_data/"

# Import filename
filename = export_path + "/registro_cotas_clean.pkl"
df = pd.read_pickle(filename)



########## BUILDING CASH FLOWS ##########

# Flag for quarter_adesao==quarter_min
df['earliest_date'] = df.groupby(['grupo_id','adm_id','cota_id','cota_sub_id','cpf_fake_id'])['date_base'].transform('min')
df['quarter_min'] = df['earliest_date'].dt.quarter
df['year_min'] = df['earliest_date'].dt.year
df['quarter_adesao'] = df['date_adesao'].dt.quarter
df['year_adesao'] = df['date_adesao'].dt.year
df['adesao_min_flag'] = ((df['quarter_adesao'] == df['quarter_min']) & (df['year_adesao'] == df['year_min'])).astype(int)
#df_full = df[df['adesao_min_flag']==1]

# Flag for quarter_contemp==quarter
df['quarter_contemp'] = df['date_contemp'].dt.quarter
df['year_contemp'] = df['date_contemp'].dt.year
df['contemp_in_quarter'] = ((df['quarter_contemp'] == df['quarter']) & (df['year_contemp'] == df['year'])).astype(int)

# Create variable with positive entries (credit)
df['cash_positive'] = df['contemp_in_quarter']*df['credit_contemp']
df['cash_positive'] = df['cash_positive'].fillna(0)

# Create variable for negative entries
df['cumul_payments'] = df['fundo_comum_acumul'] + df['fundo_reserva_acumul'] + df['tx_adm_acumul'] + df['juros_multas_acumul']
df['variation_payments'] = df.groupby(['adm_id','grupo_id','cota_id','cpf_fake_id'])['cumul_payments'].diff()
df['cash_negative'] = df['variation_payments']
df['cash_negative'] = df['cash_negative'].fillna(df['cumul_payments'])

# Create net flow
df['cash_net'] = df['cash_positive'] - df['cash_negative']

# Keep only active quotas
df = df[df['sit_atual']==1]

# Computing NPV
df['discount_rate'] = 0.0303
df['monthly_count'] = df.groupby(['adm_id','grupo_id','cota_id','cpf_fake_id']).cumcount() + 1
df['discounted_flow'] = df['cash_net']/((1+df['discount_rate'])**(df['monthly_count']))
df['npv'] = df.groupby(['adm_id','grupo_id','cota_id','cpf_fake_id'])['discounted_flow'].transform('sum')

# Collapse 
group_df = df.groupby(['adm_id','grupo_id','cota_id','cpf_fake_id'])[['npv','renda_cotista','credit_contemp']].mean().reset_index()
group_df['renda_cotista'] = np.log(group_df['renda_cotista'])
group_df['n_npv'] = group_df['npv']/group_df['credit_contemp']
group_df = group_df[group_df['npv']<0]

# Plot
import matplotlib.pyplot as plt
plt.figure(figsize=(8,6))
plt.scatter(group_df['renda_cotista'],group_df['n_npv'], color='blue')
plt.xlabel('Renda Cotista')
plt.ylabel('NPV')
plt.grid(True)
plt.tight_layout()
plt.show()

