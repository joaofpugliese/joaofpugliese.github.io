"""
Author: Otavio Braga
Date: July 24, 2025
"""


########## SETUP ##########

# Setting up useful packages
import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt

# Set paths and working directory
data_path = "D:/bases"
personal_path = "C:/Users/depep.otaviomb2/Documents/main"
import_path = personal_path + "/data/treated_data/"
results_path = personal_path + "/results/graphs/"

# Import filename
filename = import_path + "/registro_cotas_clean.pkl"
df = pd.read_pickle(filename)

# Defining group of interest
unit_cols = ['grupo_id','adm_id','cota_id','date_adesao_str']

########## CHECKING DATA QUALITY ##########

# Flag for quarter_adesao==quarter_min
#df['earliest_date'] = df.groupby(['grupo_id','adm_id','cota_id','cota_sub_id','cpf_fake_id'])['date_base'].transform('min')
df['earliest_date'] = df.groupby(unit_cols)['date_base'].transform('min')
df['quarter_min'] = df['earliest_date'].dt.quarter
df['year_min'] = df['earliest_date'].dt.year
df['quarter_adesao'] = df['date_adesao'].dt.quarter
df['year_adesao'] = df['date_adesao'].dt.year
df['adesao_min_flag'] = ((df['quarter_adesao'] == df['quarter_min']) & (df['year_adesao'] == df['year_min'])).astype(int)
#df_full = df[df['adesao_min_flag']==1]

# Flag for quarter_contemp==quarter
df['quarter_contemp'] = df['date_contemp'].dt.quarter
df['year_contemp'] = df['date_contemp'].dt.year
df['contemp_in_quarter'] = ((df['quarter_contemp'] == df['quarter']) & (df['year_contemp'] == df['year'])).astype(int)

# Build plot for adesão min flag over time
unit_df = df.sort_values('year_adesao').groupby(unit_cols, as_index=False).first()
summary_df = (unit_df.groupby(['codigo_seg','year_adesao']).agg(total_units=('adesao_min_flag','count'),adesao_flag_1=('adesao_min_flag',lambda x: (x==1).sum())).reset_index())
summary_df['share_flag_1'] = summary_df['adesao_flag_1'] / summary_df['total_units']

# Plot it
codigo_segs = summary_df['codigo_seg'].unique()
figname = results_path + "flag_adesao_first_obs.pdf"
plt.figure(figsize=(12,6))
for codigo in codigo_segs:
    data = summary_df[summary_df['codigo_seg'] == codigo]
    data = data.sort_values('year_adesao')
    plt.plot(data['year_adesao'],data['share_flag_1'],marker='o',label=f'codigo_seg: {codigo}')
plt.title("Share of Units with adesao_min_flag == 1 Over Time")
plt.ylabel("Share")
plt.xlabel("Starting Year")
plt.xticks(rotation=45)
plt.legend(title='codigo_seg')
plt.tight_layout()
plt.grid()
plt.savefig(figname)
plt.show()

# Flag for cancelamento
cancel_flag_df = (df.groupby(unit_cols)['date_cancel'].apply(lambda x: x.notna().any()).reset_index(name='flag_date_cancel'))
df = df.merge(cancel_flag_df, on=unit_cols, how='left')

# Build plot for adesão min flag over time
unit_cols = unit_cols
unit_df = df[df['flag_date_cancel']==0].sort_values('year_adesao').groupby(unit_cols, as_index=False).first()
summary_df = (unit_df.groupby(['codigo_seg','year_adesao']).agg(total_units=('adesao_min_flag','count'),adesao_flag_1=('adesao_min_flag',lambda x: (x==1).sum())).reset_index())
summary_df['share_flag_1'] = summary_df['adesao_flag_1'] / summary_df['total_units']

# Plot it
figname = results_path + "flag_adesao_first_obs_nocancel.pdf"
plt.figure(figsize=(12,6))
for codigo in codigo_segs:
    data = summary_df[summary_df['codigo_seg'] == codigo]
    data = data.sort_values('year_adesao')
    plt.plot(data['year_adesao'],data['share_flag_1'],marker='o',label=f'codigo_seg: {codigo}')
plt.title("Share of Units with adesao_min_flag == 1 Over Time")
plt.ylabel("Share")
plt.xlabel("Starting Year")
plt.xticks(rotation=45)
plt.legend(title='codigo_seg')
plt.tight_layout()
plt.grid()
plt.savefig(figname)
plt.show()
