
# ---------------------------------------------- # 
#                 Data cleaning 
# ---------------------------------------------- # 

# Packages ---------------------------------------

library(dplyr)
library(ggplot2)
library(lubridate)  # Para trabalhar com datas

# Set paths and working directory ----------------

data_path <- "D:/bases"
personal_path <- "C:/Users/depep.otaviomb2/Documents/main"
export_path <- file.path(personal_path, "data", "treated_data")

# Importing dataset ------------------------------

filename <- file.path(data_path, "exemplo_5_7agosto_rev.txt")
base_raw <- read.delim(filename, header=FALSE)
colnames(base_raw) <- as.character(base_raw[1,])
base_raw <- base_raw[-1,]

base <- base_raw

base %>% head(100) %>% View()

# Data cleaning ----------------------------------

# Treat data_base (year and month extraction)

base <- base %>% 
  mutate(
    year = substr(DAC_DT_BASE, 1, 4) %>% as.numeric(),
    month = substr(DAC_DT_BASE, 5, 6) %>% as.numeric()
  )

# Treat tokens --> make friendly versions as integers

base <- base %>% 
  mutate(
    codigo_seg = FCT_CD_SEG,
    adm_id = adm_cd2 %>% as.factor() %>% as.integer(),
    grupo_id = gai_cd_grupo2 %>% as.factor() %>% as.integer(),
    cpf_fake_id = CTC_CD_COTISTA2 %>% as.factor() %>% as.integer(),
    cota_id = COT_CD_COTA,
    cota_sub_id = COT_CD_SEQ_COTA,
    cota_full_id = paste(cota_id, cota_sub_id, sep = "-")
  )

# Converting dates

base <- base %>% 
  mutate(
    # Conversão de datas (formato original: mm/dd/yyyy)
    date_cancel = as.Date(FCT_DT_CAN_COTA, format = "%m/%d/%Y"),
    date_contemp = as.Date(FCT_DT_CONTEMP, format = "%m/%d/%Y"),
    date_adesao = as.Date(FCT_DT_ADESAO, format = "%m/%d/%Y"),
    
    # Criar data_base como último dia do mês
    temp_date = make_date(year, month, 1),  # primeiro dia do mês
    date_base = temp_date %m+% months(1) - days(1)  # último dia do mês
  ) %>%
  # Remover variável temporária
  select(-temp_date)

# Create date string versions and derived date variables

base <- base %>% 
  mutate(
    # Versões string das datas (formato: ddmmmyyyy em minúsculas)
    date_cancel_str = ifelse(is.na(date_cancel), NA_character_, 
                            format(date_cancel, "%d%b%Y") %>% tolower()),
    date_contemp_str = ifelse(is.na(date_contemp), NA_character_, 
                             format(date_contemp, "%d%b%Y") %>% tolower()),
    date_adesao_str = ifelse(is.na(date_adesao), NA_character_, 
                            format(date_adesao, "%d%b%Y") %>% tolower()),
    date_base_str = format(date_base, "%d%b%Y") %>% tolower(),
    
    # Variáveis derivadas das datas
    year_adesao = year(date_adesao),
    quarter = quarter(date_base)
  )


# Importing numerical values ----------------------

base <- base %>% 
  mutate(
    pct_lance = as.numeric(FCT_PC_LANCE),
    prazo = as.integer(FCT_QT_DUR_PLANO),
    tx_adm = as.numeric(FCT_PC_TX_ADM),
    tx_adm_antecip = as.numeric(FCT_PC_TAX_ADM_ANTEC),
    pct_amort_mensal = as.numeric(FCT_PC_AMO_MENSAL),
    valor_bem = as.numeric(FCT_VL_BEM),
    pct_amort_acumul = as.numeric(FCT_PC_ACU_AMORT),
    fundo_comum_acumul = as.numeric(FCT_VL_CON_ACU_FUN_COMUM),
    fundo_reserva_acumul = as.numeric(FCT_VL_CON_ACU_FUN_RESERVA),
    tx_adm_acumul = as.numeric(FCT_VL_CON_ACU_TX_ADM),
    juros_multas_acumul = as.numeric(FCT_VL_CON_ACU_JUR_MULTAS),
    credit_contemp = as.numeric(FCT_VL_CRE_DAT_CONTEMP),
    pct_atraso = as.numeric(FCT_PC_ATRASO),
    renda_cotista = as.numeric(FCT_VL_REN_FAT_MEN_COTISTA)
  )

# Identifying individuals (=1), firms (=0) or non-identified

base <- base %>% 
  mutate(
    pessoa_fisica = case_when(
      FCT_CD_TIP_COTISTA == 2 ~ 1,
      FCT_CD_TIP_COTISTA == 1 ~ 0,
      FCT_CD_TIP_COTISTA == 3 ~ NA_real_,
      TRUE ~ NA_real_
    )
  )

# Identifying auction (=1) and lottery (=1) mechanisms

base <- base %>% 
  mutate(
    auction = ifelse(FCT_IB_CONTEMP == "L", 1, NA_real_),
    lottery = ifelse(FCT_IB_CONTEMP == "S", 1, NA_real_)
  )

# Quota status

base <- base %>% 
  mutate(
    sit_atual = FCT_ST_ATUAL
  )

# Sort dataframe

base <- base %>% 
  arrange(adm_id, grupo_id, cota_id, year, month)

# Reorder columns (first columns in specific order)

first_cols <- c('sit_atual','quarter','year','month','date_base_str',
                'cpf_fake_id', 'cota_full_id', 'date_adesao_str', 'prazo', 
                'date_contemp_str', 'auction', 'lottery','date_cancel_str')

base <- base %>% 
  select(all_of(first_cols), everything())

# Exporting to .rds and .csv

outfile_rds <- file.path(export_path, "registro_cotas_clean.rds")
saveRDS(base, outfile_rds)

outfile_csv <- file.path(export_path, "registro_cotas_clean.csv")
write.csv(base, outfile_csv, row.names = FALSE)

