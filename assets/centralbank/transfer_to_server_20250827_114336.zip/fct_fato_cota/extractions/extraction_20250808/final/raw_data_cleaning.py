"""
Author: Otavio Braga
Date: July 24, 2025
"""


########## SETUP ##########

# Setting up useful packages
import numpy as np
import pandas as pd
import os

# Set paths and working directory
data_path = "D:/bases"
personal_path = "C:/Users/depep.otaviomb2/Documents/main"
export_path = personal_path + "/data/treated_data/"

# Import filename
filename = data_path + "/exemplo_5_7agosto_rev.txt"
df_raw = pd.read_csv(filename, delim_whitespace=True)
df = df_raw.copy()


########## DATA CLEANING ##########

# Treat data_base
df['DAC_DT_BASE'] = df_raw['DAC_DT_BASE'].astype(str)
df['year'] = df['DAC_DT_BASE'].str[:4].astype(int)
df['month'] = df['DAC_DT_BASE'].str[4:6].astype(int)
df = df[['year','month']]

# Treat tokens --> make friendly versions as integers
df['codigo_seg'] = df_raw['FCT_CD_SEG']
df['adm_id'] = df_raw['adm_cd2'].astype('category').cat.codes
df['adm_id'] += 1
df['grupo_id'] = df_raw['gai_cd_grupo2'].astype('category').cat.codes
df['grupo_id'] += 1
df['cpf_fake_id'] = df_raw['CTC_CD_COTISTA2'].astype('category').cat.codes
df['cpf_fake_id'] += 1
df['cota_id'] = df_raw['COT_CD_COTA']
df['cota_sub_id'] = df_raw['COT_CD_SEQ_COTA']
df['cota_full_id'] = df['cota_id'].astype(str) + "-" +  df['cota_sub_id'].astype(str)

# Converting dates
df['date_cancel'] = pd.to_datetime(df_raw['FCT_DT_CAN_COTA'], format='%m/%d/%Y', errors='coerce')
df['date_cancel_str'] = df['date_cancel'].dt.strftime('%d%b%Y').str.lower()
df['date_contemp'] = pd.to_datetime(df_raw['FCT_DT_CONTEMP'], format='%m/%d/%Y', errors='coerce')
df['date_contemp_str'] = df['date_contemp'].dt.strftime('%d%b%Y').str.lower()
df['date_adesao'] = pd.to_datetime(df_raw['FCT_DT_ADESAO'], format='%m/%d/%Y', errors='coerce')
df['date_adesao_str'] = df['date_adesao'].dt.strftime('%d%b%Y').str.lower()
df['year_adesao'] = df['date_adesao'].dt.year
df['temp_date'] = pd.to_datetime(dict(year=df['year'], month=df['month'], day=1))
df['date_base'] = df['temp_date'] + pd.offsets.MonthEnd(1)
df['date_base_str'] = df['date_base'].dt.strftime('%d%b%Y').str.lower()
df['quarter'] = df['date_base'].dt.quarter
df = df.drop(columns=['temp_date'])

# Importing numerical values
df['pct_lance'] = pd.to_numeric(df_raw['FCT_PC_LANCE'], errors='coerce')
df['prazo'] = df_raw['FCT_QT_DUR_PLANO'].astype(int)
df['tx_adm'] = df_raw['FCT_PC_TX_ADM'].astype(float)
df['tx_adm_antecip'] = df_raw['FCT_PC_TAX_ADM_ANTEC'].astype(float)
df['pct_amort_mensal'] = df_raw['FCT_PC_AMO_MENSAL'].astype(float)
df['valor_bem'] = df_raw['FCT_VL_BEM'].astype(float)
df['pct_amort_acumul'] = df_raw['FCT_PC_ACU_AMORT'].astype(float)
df['fundo_comum_acumul'] = df_raw['FCT_VL_CON_ACU_FUN_COMUM'].astype(float)
df['fundo_reserva_acumul'] = df_raw['FCT_VL_CON_ACU_FUN_RESERVA'].astype(float)
df['tx_adm_acumul'] = df_raw['FCT_VL_CON_ACU_TX_ADM'].astype(float)
df['juros_multas_acumul'] = df_raw['FCT_VL_CON_ACU_JUR_MULTAS'].astype(float)
df['credit_contemp'] = pd.to_numeric(df_raw['FCT_VL_CRE_DAT_CONTEMP'], errors='coerce')
df['pct_atraso'] = pd.to_numeric(df_raw['FCT_PC_ATRASO'], errors='coerce')
df['renda_cotista'] = pd.to_numeric(df_raw['FCT_VL_REN_FAT_MEN_COTISTA'], errors='coerce')

# Identifying individuals (=1), firms (=0) or non-identified
conditions = [df_raw['FCT_CD_TIP_COTISTA']==2, df_raw['FCT_CD_TIP_COTISTA']==1, df_raw['FCT_CD_TIP_COTISTA']==3]
choices = [1,0,np.nan]
df['pessoa_fisica'] = np.select(conditions,choices)

# Identifying individuals (=1), firms (=0) or non-identified
conditions = [df_raw['FCT_IB_CONTEMP']=="L", df_raw['FCT_IB_CONTEMP']!="L"]
choices = [1,np.nan]
df['auction'] = np.select(conditions,choices)
conditions = [df_raw['FCT_IB_CONTEMP']=="S", df_raw['FCT_IB_CONTEMP']!="S"]
choices = [1,np.nan]
df['lottery'] = np.select(conditions,choices)

# Quota status
df['sit_atual'] = df_raw['FCT_ST_ATUAL']

# Sort dataframe
df = df.sort_values(by=['adm_id', 'grupo_id', 'cota_id', 'year', 'month'])
first_cols = ['sit_atual','quarter','year','month','date_base_str','cpf_fake_id', 'cota_full_id', 'date_adesao_str', 'prazo', 'date_contemp_str', 'auction', 'lottery','date_cancel_str' ]
other_cols = [col for col in df.columns if col not in first_cols]
df = df[first_cols + other_cols]

# Exporting to .pkl and .csv
outfile = export_path + "/registro_cotas_clean.pkl"
df.to_pickle(outfile)
outfile = export_path + "/registro_cotas_clean.csv"
df.to_csv(outfile, index=False)
