
# ---------------------------------------------- # 
#                 Data cleaning 
# ---------------------------------------------- # 

# Packages ---------------------------------------

library(dplyr)
library(ggplot2)

# Importing dataset ------------------------------

base_raw <- read.delim("D:/bases/exemplo_5_7agosto_rev.txt", header=FALSE)
colnames(base_raw) <- as.character(base_raw[1,])
base_raw <- base_raw[-1,]

base <- base_raw

base %>% head(100) %>% View()

# Data cleaning ----------------------------------

base <- base %>% 
  mutate(year = substr(DAC_DT_BASE, 1, 4) %>% as.numeric(),
         month = substr(DAC_DT_BASE, 5, 6) %>% as.numeric(),
         codigo_seg = FCT_CD_SEG,
         adm_id = adm_cd2 %>% as.factor() %>% as.integer(),
         grupo_id = gai_cd_grupo2 %>% as.factor() %>% as.integer(),
         #cpf_fake_id = CTC_CD_COTISTA2 %>% as.factor() %>% as.integer(),
         cota_id = COT_CD_COTA,
         cota_sub_id = COT_CD_SEQ_COTA,
         cota_full_id = paste(cota_id, cota_sub_id, sep = "-"),
         date_cancel = as.Date(FCT_DT_CAN_COTA, format = "%m/%d/%Y"),
         date_contemp = as.Date(FCT_DT_CONTEMP, format = "%m/%d/%Y"),
         date_adesao = as.Date(FCT_DT_ADESAO, format = "%m/%d/%Y"),
         date_base = paste(month, "01", year, sep = "/") %>% as.Date(format = "%m/%d/%Y"))

str(base)
