
# ---------------------------------------------- # 
#               Cash Flow Analysis
# ---------------------------------------------- # 

# Packages ---------------------------------------

library(dplyr)
library(ggplot2)
library(lubridate)


# Set paths and working directory ----------------

data_path <- "D:/bases"
personal_path <- "C:/Users/depep.leonardozs/Documents/main"
export_path <- file.path(personal_path, "data", "treated_data")


# Importing dataset ------------------------------

# Consórcios data

filename <- file.path(export_path, "registro_cotas_clean.rds")
base <- readRDS(filename)

# Interest rate data

filename2 <- file.path(data_path, "seriessgs.csv")
juros_raw <- read.csv(filename2, sep = ";", header = FALSE)
colnames(juros_raw) <- as.character(juros_raw[1,])
juros_raw <- juros_raw[-1,]

juros <- juros_raw %>% 
  slice(-n()) %>% 
  rename(
    selic = !!names(.)[2],
    cdi = !!names(.)[3]
  ) %>% 
  mutate(
    year = substr(Data, 4, 7) %>% as.numeric(),
    month = substr(Data, 1, 2) %>% as.numeric(),
    temp_date = make_date(year, month, 1),
    date_base = temp_date %m+% months(1) - days(1),
    selic = as.numeric(gsub(",", ".", selic)),
    cdi = as.numeric(gsub(",", ".", cdi))
  ) %>% 
  select(year, month, date_base, selic, cdi)


# Building cash flows ----------------------------

# Flag for quarter_adesao==quarter_min

base <- base %>% 
  group_by(grupo_id, adm_id, cota_id, cpf_fake_id) %>%
  mutate(
    earliest_date = min(date_base, na.rm = TRUE),
    quarter_min = quarter(earliest_date),
    year_min = year(earliest_date)
  ) %>%
  ungroup() %>%
  mutate(
    quarter_adesao = quarter(date_adesao),
    year_adesao = year(date_adesao),
    adesao_min_flag = ifelse(
      (quarter_adesao == quarter_min) & (year_adesao == year_min), 
      1, 0
    )
  )

# Flag for quarter_contemp==quarter

base <- base %>% 
  mutate(
    quarter_contemp = quarter(date_contemp),
    year_contemp = year(date_contemp),
    contemp_in_quarter = ifelse(
      (quarter_contemp == quarter) & (year_contemp == year), 
      1, 0
    )
  )

# Create variable with positive entries (credit)

base <- base %>% 
  mutate(
    cash_positive = contemp_in_quarter * credit_contemp,
    cash_positive = ifelse(is.na(cash_positive), 0, cash_positive)
  )

# Create variable for negative entries

base <- base %>% 
  mutate(
    cumul_payments = fundo_comum_acumul + fundo_reserva_acumul + 
                    tx_adm_acumul + juros_multas_acumul
  ) %>%
  group_by(adm_id, grupo_id, cota_id, cpf_fake_id) %>%
  mutate(
    variation_payments = cumul_payments - lag(cumul_payments, default = 0),
    cash_negative = ifelse(is.na(lag(cumul_payments)), cumul_payments, variation_payments)
  ) %>%
  ungroup()

# Create net flow

base <- base %>% 
  mutate(
    cash_net = cash_positive - cash_negative
  )

# Keep only active quotas

base <- base %>% 
  filter(sit_atual == 1)


# Computing NPV ----------------------------------

base <- base %>% 
  mutate(
    discount_rate = 0.0303
  ) %>%
  group_by(adm_id, grupo_id, cota_id, cpf_fake_id) %>%
  mutate(
    monthly_count = row_number(),
    discounted_flow = cash_net / ((1 + discount_rate) ^ monthly_count)
  ) %>%
  mutate(
    npv = sum(discounted_flow, na.rm = TRUE)
  ) %>%
  ungroup()

# Collapse to group level ------------------------

group_df <- base %>% 
  group_by(adm_id, grupo_id, cota_id, cpf_fake_id) %>%
  summarise(
    npv = mean(npv, na.rm = TRUE),
    renda_cotista = mean(renda_cotista, na.rm = TRUE),
    credit_contemp = mean(credit_contemp, na.rm = TRUE),
    .groups = 'drop'
  ) %>%
  mutate(
    renda_cotista = log(renda_cotista),
    n_npv = npv / credit_contemp
  ) %>%
  filter(npv < 0)

# Plot results -----------------------------------

plot_npv <- ggplot(group_df, aes(x = renda_cotista, y = n_npv)) +
  geom_point(color = "blue", alpha = 0.6) +
  labs(
    x = "Renda Cotista (log)",
    y = "NPV Normalizado",
    title = "NPV vs Renda do Cotista"
  ) +
  theme_minimal() +
  theme(
    panel.grid = element_line(color = "grey90"),
    plot.title = element_text(hjust = 0.5)
  )

print(plot_npv)

# Export results ---------------------------------

outfile_rds <- file.path(export_path, "cash_flow_analysis.rds")
saveRDS(group_df, outfile_rds)

outfile_csv <- file.path(export_path, "cash_flow_analysis.csv")
write.csv(group_df, outfile_csv, row.names = FALSE)
