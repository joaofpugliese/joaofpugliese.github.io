
# ---------------------------------------------- # 
#              Data Quality Check
# ---------------------------------------------- # 

# Packages ---------------------------------------

library(dplyr)
library(ggplot2)
library(lubridate)


# Set paths, working directory and df ------------

data_path <- "D:/bases"
personal_path <- "C:/Users/depep.otaviomb2/Documents/main"
import_path <- file.path(personal_path, "data", "treated_data")
results_path <- file.path(personal_path, "results", "graphs")

# Create results directory if it doesn't exist
if (!dir.exists(results_path)) {
  dir.create(results_path, recursive = TRUE)
}

# Importing dataset
filename <- file.path(import_path, "registro_cotas_clean.rds")
df <- readRDS(filename)


# Define variables for analysis -----

# Group identifier for quality checks (already created in raw_data_cleaning)
unit_cols <- c('grupo_id', 'adm_id', 'cota_id', 'date_adesao_str')


# 1. How does the share of units with date_adesao = earliest_date behave over time? -----

# Build plot for adesão min flag over time

unit_df <- df %>%
  arrange(year_adesao) %>%
  group_by(across(all_of(unit_cols))) %>%
  slice_head(n = 1) %>%
  ungroup()

summary_df <- unit_df %>%
  group_by(codigo_seg, year_adesao) %>%
  summarise(
    total_units = n(),
    adesao_flag_1 = sum(adesao_min_flag == 1, na.rm = TRUE),
    .groups = 'drop'
  ) %>%
  mutate(
    share_flag_1 = adesao_flag_1 / total_units
  )

# Plot it

codigo_segs <- unique(summary_df$codigo_seg)
figname <- file.path(results_path, "flag_adesao_first_obs.pdf")

plot1 <- ggplot(summary_df, aes(x = year_adesao, y = share_flag_1, color = factor(codigo_seg))) +
  geom_line(size = 1) +
  geom_point(size = 2) +
  labs(
    title = "Share of Units with adesao_min_flag == 1 Over Time",
    x = "Starting Year",
    y = "Share",
    color = "codigo_seg"
  ) +
  theme_classic() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1),
    panel.grid = element_line(color = "grey90"),
    legend.position = "bottom"
  ) +
  scale_x_continuous(breaks = scales::pretty_breaks(n = 8))

print(plot1)
ggsave(figname, plot1, width = 12, height = 6, units = "in")


# 2. " if we drop cancelled quotas ---------------

# Build plot for adesão min flag over time (no cancel)

unit_df_nocancel <- df %>%
  filter(flag_date_cancel == 0) %>%
  arrange(year_adesao) %>%
  group_by(across(all_of(unit_cols))) %>%
  slice_head(n = 1) %>%
  ungroup()

summary_df_nocancel <- unit_df_nocancel %>%
  group_by(codigo_seg, year_adesao) %>%
  summarise(
    total_units = n(),
    adesao_flag_1 = sum(adesao_min_flag == 1, na.rm = TRUE),
    .groups = 'drop'
  ) %>%
  mutate(
    share_flag_1 = adesao_flag_1 / total_units
  )

# Plot it (no cancel)

figname_nocancel <- file.path(results_path, "flag_adesao_first_obs_nocancel.pdf")

plot2 <- ggplot(summary_df_nocancel, aes(x = year_adesao, y = share_flag_1, color = factor(codigo_seg))) +
  geom_line(size = 1) +
  geom_point(size = 2) +
  labs(
    title = "Share of Units with adesao_min_flag == 1 Over Time (No Cancellations)",
    x = "Starting Year",
    y = "Share",
    color = "codigo_seg"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1),
    panel.grid = element_line(color = "grey90"),
    legend.position = "bottom"
  ) +
  scale_x_continuous(breaks = scales::pretty_breaks(n = 8))

print(plot2)
ggsave(figname_nocancel, plot2, width = 12, height = 6, units = "in")


# 3. Flag variability analysis ---------------

# Install fixest if needed (uncomment if first time)
# install.packages("fixest")
library(fixest)

# Create bins within segment
df <- df %>%
  group_by(codigo_seg) %>%
  mutate(
    dec_val  = ntile(valor_bem, 10),  # deciles of value
    quin_dur = ntile(prazo, 5)        # quintiles of duration
  ) %>%
  ungroup()

# One-at-a-time regressions, split by segment
m_dec_g  <- feols(adesao_min_flag ~ i(dec_val,  ref = 5) | grupo_id,
                  data = df, split = ~ codigo_seg)
m_dec_a  <- feols(adesao_min_flag ~ i(dec_val,  ref = 5) | adm_id,
                  data = df, split = ~ codigo_seg)

m_quin_g <- feols(adesao_min_flag ~ i(quin_dur, ref = 3) | grupo_id,
                  data = df, split = ~ codigo_seg)
m_quin_a <- feols(adesao_min_flag ~ i(quin_dur, ref = 3) | adm_id,
                  data = df, split = ~ codigo_seg)

# R² by segment (named vectors)
r2_dec_g  <- r2(m_dec_g)
r2_dec_a  <- r2(m_dec_a)
r2_quin_g <- r2(m_quin_g)
r2_quin_a <- r2(m_quin_a)

# Create summary table of R²
r2_summary <- data.frame(
  Segment = names(r2_dec_g),
  R2_Value_Group = as.numeric(r2_dec_g),
  R2_Value_Admin = as.numeric(r2_dec_a),
  R2_Duration_Group = as.numeric(r2_quin_g),
  R2_Duration_Admin = as.numeric(r2_quin_a)
)

# Export R² summary
outfile_r2 <- file.path(import_path, "flag_variability_r2_summary.csv")
write.csv(r2_summary, outfile_r2, row.names = FALSE)


# Export summary data ----------------------------

outfile_summary <- file.path(import_path, "data_quality_summary.rds")
saveRDS(list(
  summary_all = summary_df,
  summary_nocancel = summary_df_nocancel,
  cancel_flags = cancel_flag_df
), outfile_summary)

outfile_summary_csv <- file.path(import_path, "data_quality_summary.csv")
write.csv(summary_df, outfile_summary_csv, row.names = FALSE)
