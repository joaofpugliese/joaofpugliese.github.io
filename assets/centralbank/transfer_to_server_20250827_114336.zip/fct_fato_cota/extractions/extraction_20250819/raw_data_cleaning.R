
# ---------------------------------------------- # 
#                 Data cleaning 
# ---------------------------------------------- # 

# Packages ---------------------------------------

library(dplyr)
library(ggplot2)
library(lubridate)


# Set paths and working directory ----------------

data_path <- "D:/bases"
personal_path <- "C:/Users/depep.leonardozs/Documents/main" # Change user and path
export_path <- file.path(personal_path, "data", "treated_data")


# Importing dataset ------------------------------

filename <- file.path(data_path, "exemplo_5_7agosto_rev.txt")
df_raw <- read.delim(filename, header=FALSE)

colnames(df_raw) <- as.character(df_raw[1,])
df_raw <- df_raw[-1,]

df <- df_raw


# Data cleaning ----------------------------------

# Treat data_base (year and month extraction)

df <- df %>% 
  mutate(
    year = substr(DAC_DT_BASE, 1, 4) %>% as.numeric(),
    month = substr(DAC_DT_BASE, 5, 6) %>% as.numeric()
  )

# Treat tokens --> make friendly versions as integers

df <- df %>% 
  mutate(
    codigo_seg = FCT_CD_SEG,
    adm_id = adm_cd2 %>% as.factor() %>% as.integer(),
    grupo_id = gai_cd_grupo2 %>% as.factor() %>% as.integer(),
    #cpf_fake_id = CTC_CD_COTISTA2 %>% as.factor() %>% as.integer(),
    cota_id = COT_CD_COTA,
    cota_sub_id = COT_CD_SEQ_COTA,
    cota_full_id = paste(cota_id, cota_sub_id, sep = "-")
  )

# Treat dates

df <- df %>% 
  mutate(
    # Converting dates (original format: chr)
    date_cancel = as.Date(FCT_DT_CAN_COTA, format = "%m/%d/%Y"),
    date_contemp = as.Date(FCT_DT_CONTEMP, format = "%m/%d/%Y"),
    date_adesao = as.Date(FCT_DT_ADESAO, format = "%m/%d/%Y"),
    
    # Creating date_base (last day of the month)
    temp_date = make_date(year, month, 1),
    date_base = temp_date %m+% months(1) - days(1)
  ) %>%
  select(-temp_date)

# Create date string versions and derived date variables

df <- df %>% 
  mutate(
    # String dates (ddmmmyyyy)
    date_cancel_str = ifelse(is.na(date_cancel), NA_character_, 
        format(date_cancel, "%d%b%Y") %>% tolower()),
    date_contemp_str = ifelse(is.na(date_contemp), NA_character_, 
        format(date_contemp, "%d%b%Y") %>% tolower()),
    date_adesao_str = ifelse(is.na(date_adesao), NA_character_, 
        format(date_adesao, "%d%b%Y") %>% tolower()),
    date_base_str = format(date_base, "%d%b%Y") %>% tolower(),
    
    # Year and quarter
    year_adesao = year(date_adesao),
    quarter = quarter(date_base)
  )


# Converting to numerical values

df <- df %>% 
  mutate(
    pct_lance = as.numeric(FCT_PC_LANCE),
    prazo = as.integer(FCT_QT_DUR_PLANO),
    tx_adm = as.numeric(FCT_PC_TX_ADM),
    tx_adm_antecip = as.numeric(FCT_PC_TAX_ADM_ANTEC),
    pct_amort_mensal = as.numeric(FCT_PC_AMO_MENSAL),
    valor_bem = as.numeric(FCT_VL_BEM),
    pct_amort_acumul = as.numeric(FCT_PC_ACU_AMORT),
    fundo_comum_acumul = as.numeric(FCT_VL_CON_ACU_FUN_COMUM),
    fundo_reserva_acumul = as.numeric(FCT_VL_CON_ACU_FUN_RESERVA),
    tx_adm_acumul = as.numeric(FCT_VL_CON_ACU_TX_ADM),
    juros_multas_acumul = as.numeric(FCT_VL_CON_ACU_JUR_MULTAS),
    credit_contemp = as.numeric(FCT_VL_CRE_DAT_CONTEMP),
    pct_atraso = as.numeric(FCT_PC_ATRASO),
    renda_cotista = as.numeric(FCT_VL_REN_FAT_MEN_COTISTA)
  )

# Identifying individuals (=1), firms (=0) or non-identified

df <- df %>% 
  mutate(
    pessoa_fisica = case_when(
      FCT_CD_TIP_COTISTA == 2 ~ 1,
      FCT_CD_TIP_COTISTA == 1 ~ 0,
      FCT_CD_TIP_COTISTA == 3 ~ NA_real_,
      TRUE ~ NA_real_
    )
  )

# Identifying auction (=1) and lottery (=1) mechanisms

df <- df %>% 
  mutate(
    auction = ifelse(FCT_IB_CONTEMP == "L", 1, NA_real_),
    lottery = ifelse(FCT_IB_CONTEMP == "S", 1, NA_real_),
    allocation_type = FCT_IB_CONTEMP
  )

# Quota status

df <- df %>% 
  mutate(
    sit_atual = FCT_ST_ATUAL
  )

# Create additional flags (for data_quality_check 1. and 2.)

# Define group of interest for quality checks
unit_cols <- c('grupo_id', 'adm_id', 'cota_id', 'date_adesao_str')

# Create all flags needed for quality analysis
df <- df %>%
  # Flag for quarter_adesao==quarter_min
  group_by(across(all_of(unit_cols))) %>%
  mutate(
    earliest_date = min(date_base, na.rm = TRUE),
    quarter_min = quarter(earliest_date),
    year_min = year(earliest_date)
  ) %>%
  ungroup() %>%
  mutate(
    quarter_adesao = quarter(date_adesao),
    adesao_min_flag = ifelse(
      (quarter_adesao == quarter_min) & (year_adesao == year_min), 
      1, 0
    ),
    # Flag for quarter_contemp==quarter
    quarter_contemp = quarter(date_contemp),
    year_contemp = year(date_contemp),
    contemp_in_quarter = ifelse(
      (quarter_contemp == quarter) & (year_contemp == year), 
      1, 0
    )
  )

df %>% head(1000) %>% View()

# Create cancellation flag and merge back
cancel_flag_df <- df %>%
  group_by(across(all_of(unit_cols))) %>%
  summarise(
    flag_date_cancel = ifelse(any(!is.na(date_cancel)), 1, 0),
    .groups = 'drop'
  )

df <- df %>%
  left_join(cancel_flag_df, by = unit_cols)

# Create bins within segment (for data_quality_check 3.)

df <- df %>%
  group_by(codigo_seg) %>%
  mutate(
    dec_val  = ntile(valor_bem, 10),  # deciles of value
    quin_dur = ntile(prazo, 5)        # quintiles of duration
  ) %>%
  ungroup()

# Sorting dataframe

df <- df %>% 
  arrange(adm_id, grupo_id, cota_id, year, month)

first_cols <- c("sit_atual","quarter","year","month","date_base_str",
  #"cpf_fake_id", 
  "cota_full_id", "date_adesao_str", "prazo", 
  "date_contemp_str", "auction", "lottery", "allocation_type", "date_cancel_str")

middle_cols <- c("codigo_seg", "adm_id", "grupo_id", "cota_id", "cota_sub_id", 
                 "date_cancel", "date_contemp", "date_adesao", "date_base",
                 "year_adesao", "pct_lance", "tx_adm", "tx_adm_antecip",
                 "pct_amort_mensal", "valor_bem", "pct_amort_acumul", 
                 "fundo_comum_acumul", "fundo_reserva_acumul", "tx_adm_acumul", 
                 "juros_multas_acumul", "credit_contemp", "pct_atraso", "renda_cotista",
                 "pessoa_fisica", "earliest_date", "quarter_min", "year_min", "quarter_adesao", 
                 "adesao_min_flag", "quarter_contemp", "year_contemp", 
                 "contemp_in_quarter", "flag_date_cancel", "dec_val", "quin_dur")

df <- df %>% 
  select(all_of(first_cols), all_of(middle_cols))

#df <- df %>% 
#  select(all_of(first_cols), everything())


# Exporting to .rds and .csv ------------------------------

outfile_rds <- file.path(export_path, "registro_cotas_clean.rds")
saveRDS(df, outfile_rds)

outfile_csv <- file.path(export_path, "registro_cotas_clean.csv")
write.csv(df, outfile_csv, row.names = FALSE)
