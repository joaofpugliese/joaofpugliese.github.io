
# ---------------------------------------------- # 
#            Bid and Lotteries Analysis
# ---------------------------------------------- # 

# Packages ---------------------------------------

library(dplyr)
library(ggplot2)
library(lubridate)
library(tidyr)


# Create simulated dataset for testing -----------

set.seed(123)  # For reproducibility

# Parameters
n_periods <- 4
n_segments <- 2
n_groups_per_segment <- 2
n_quotas_per_group <- 5

# Create base structure
df_sim <- expand_grid(
  codigo_seg = 1:n_segments,
  grupo_id = rep(1:(n_segments * n_groups_per_segment), each = n_quotas_per_group),
  cota_id = rep(1:n_quotas_per_group, times = n_segments * n_groups_per_segment),
  period = 1:n_periods
) %>%
  mutate(
    year = 2023,
    month = period,
    year_month = sprintf("%04d-%02d", year, month),
    allocation_type = NA_character_,
    date_contemp = as.Date(NA)  # Add contemplation date
  )

# Simulate some contemplations
# Group 1: Quota 1 contemplated in period 2 (lottery), Quota 2 in period 3 (auction)
# Group 2: Quota 3 contemplated in period 1 (lottery), Quota 4 in period 4 (auction)
# Group 3: Quota 1 contemplated in period 3 (lottery)
# Group 4: Quota 2 contemplated in period 2 (auction), Quota 5 in period 4 (lottery)

contemplation_events <- tribble(
  ~grupo_id, ~cota_id, ~contemp_period, ~type,
  1, 1, 2, "S",  # Group 1, Quota 1, Period 2, Lottery
  1, 2, 3, "L",  # Group 1, Quota 2, Period 3, Auction
  2, 3, 1, "S",  # Group 2, Quota 3, Period 1, Lottery
  2, 4, 4, "L",  # Group 2, Quota 4, Period 4, Auction
  3, 1, 3, "S",  # Group 3, Quota 1, Period 3, Lottery
  4, 2, 2, "L",  # Group 4, Quota 2, Period 2, Auction
  4, 5, 4, "S"   # Group 4, Quota 5, Period 4, Lottery
)

# Apply contemplations to dataframe
for(i in 1:nrow(contemplation_events)) {
  evento <- contemplation_events[i,]
  
  # Mark as contemplated from contemplation period onwards
  df_sim <- df_sim %>%
    mutate(
      allocation_type = ifelse(
        grupo_id == evento$grupo_id & 
        cota_id == evento$cota_id & 
        period >= evento$contemp_period,
        evento$type,
        allocation_type
      ),
      # Set contemplation date only in the actual contemplation period
      date_contemp = ifelse(
        grupo_id == evento$grupo_id & 
        cota_id == evento$cota_id & 
        period == evento$contemp_period,
        as.Date(sprintf("2023-%02d-15", evento$contemp_period)),
        date_contemp
      )
    ) %>%
    mutate(date_contemp = as.Date(date_contemp, origin = "1970-01-01"))  # Convert back to Date
}

# Replace main df with simulated one for testing
df <- df_sim


# Set paths, working directory and df ------------

data_path <- "D:/bases"
personal_path <- "C:/Users/depep.leonardozs/Documents/main"
import_path <- file.path(personal_path, "data", "treated_data")
results_path <- file.path(personal_path, "results", "graphs")

# Create results directory if it doesn't exist
if (!dir.exists(results_path)) {
  dir.create(results_path, recursive = TRUE)
}

# Importing dataset
filename <- file.path(import_path, "registro_cotas_clean.rds")
df <- readRDS(filename)


# 1. Overall allocation over the years ---------------

# Filter only contemplated quotas (auction or lottery)
contemplations <- df %>%
  filter(allocation_type %in% c("L", "S")) %>%  # Only contemplations
  mutate(
    year_month = sprintf("%04d-%02d", year, month)
  )

# Group by segment, year-month, and allocation type
allocation_counts <- contemplations %>%
  group_by(codigo_seg, year_month, allocation_type) %>%
  summarise(n_contemplations = n(), .groups = "drop")

# Reshape to wide and compute share
shares <- allocation_counts %>%
  pivot_wider(
    names_from = allocation_type,
    values_from = n_contemplations,
    values_fill = 0
  ) %>%
  mutate(
    total = L + S,
    lottery_share = S / total
  )

# Plot temporal evolution by segment
plot_temporal <- ggplot(shares, aes(x = year_month, y = lottery_share, color = factor(codigo_seg))) +
  geom_line(aes(group = codigo_seg), size = 1) +
  geom_point(size = 2) +
  labs(
    title = "Evolution of Lottery Share Over Time by Segment",
    x = "Year-Month",
    y = "Lottery Share",
    color = "Segment Code"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "bottom"
  ) +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent) +
  scale_x_discrete(breaks = function(x) x[seq(1, length(x), by = 6)])  # Show every 6 months

# Save plot
figname_temporal <- file.path(results_path, "lottery_share_temporal.pdf")
ggsave(figname_temporal, plot_temporal, width = 14, height = 8, units = "in")


# 2. Within-group, over group lifetime ---------------

# Calculate shares for each group over their entire lifetime
group_shares <- df %>%
  filter(allocation_type %in% c("L", "S")) %>%  # Only contemplations
  group_by(codigo_seg, grupo_id) %>%
  summarise(
    auctions = sum(allocation_type == "L", na.rm = TRUE),
    lotteries = sum(allocation_type == "S", na.rm = TRUE),
    total = auctions + lotteries,
    lottery_share = lotteries / total,
    .groups = "drop"
  ) %>%
  filter(total > 0)  # Remove groups with no contemplations

# Plot distribution of lottery shares by segment
plot_distribution <- ggplot(group_shares, aes(x = lottery_share, fill = factor(codigo_seg))) +
  geom_histogram(bins = 20, alpha = 0.7, position = "identity") +
  facet_wrap(~ codigo_seg, labeller = labeller(codigo_seg = function(x) paste("Segment", x))) +
  labs(
    title = "Distribution of Lottery Shares Across Groups by Segment",
    x = "Lottery Share",
    y = "Number of Groups",
    fill = "Segment Code"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    legend.position = "none"
  ) +
  scale_x_continuous(labels = scales::percent)

# Save plot
figname_distribution <- file.path(results_path, "lottery_share_distribution.pdf")
ggsave(figname_distribution, plot_distribution, width = 12, height = 8, units = "in")



# 3. Flow analysis - Overall allocation over the years ---------------

# Identify actual contemplation events (using date_contemp)
flow_contemplations <- df %>%
  filter(!is.na(date_contemp) & allocation_type %in% c("L", "S")) %>%
  mutate(
    contemp_year_month = sprintf("%04d-%02d", year(date_contemp), month(date_contemp)),
    current_year_month = sprintf("%04d-%02d", year, month)
  ) %>%
  # Keep only observations where current month equals contemplation month
  filter(contemp_year_month == current_year_month)

# Group by segment, contemplation year-month, and allocation type
flow_allocation_counts <- flow_contemplations %>%
  group_by(codigo_seg, contemp_year_month, allocation_type) %>%
  summarise(n_contemplations = n(), .groups = "drop")

# Reshape to wide and compute share
flow_shares <- flow_allocation_counts %>%
  pivot_wider(
    names_from = allocation_type,
    values_from = n_contemplations,
    values_fill = 0
  ) %>%
  mutate(
    total = L + S,
    lottery_share = ifelse(total > 0, S / total, NA_real_)
  )

# Plot temporal evolution by segment (flow)
plot_temporal_flow <- ggplot(flow_shares, aes(x = contemp_year_month, y = lottery_share, color = factor(codigo_seg))) +
  geom_line(aes(group = codigo_seg), size = 1) +
  geom_point(size = 2) +
  labs(
    title = "Evolution of Lottery Share Over Time by Segment (Flow Analysis)",
    x = "Contemplation Year-Month",
    y = "Lottery Share",
    color = "Segment Code"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "bottom"
  ) +
  scale_y_continuous(limits = c(0, 1), labels = scales::percent) +
  scale_x_discrete(breaks = function(x) x[seq(1, length(x), by = 6)])  # Show every 6 months

# Save plot
figname_temporal_flow <- file.path(results_path, "lottery_share_temporal_flow.pdf")
ggsave(figname_temporal_flow, plot_temporal_flow, width = 14, height = 8, units = "in")


# 4. Flow analysis - Within-group over group lifetime ---------------

# Calculate flow-based shares for each group
flow_group_shares <- df %>%
  filter(!is.na(date_contemp) & allocation_type %in% c("L", "S")) %>%
  mutate(
    contemp_year_month = sprintf("%04d-%02d", year(date_contemp), month(date_contemp)),
    current_year_month = sprintf("%04d-%02d", year, month)
  ) %>%
  # Keep only observations where current month equals contemplation month
  filter(contemp_year_month == current_year_month) %>%
  group_by(codigo_seg, grupo_id) %>%
  summarise(
    auctions = sum(allocation_type == "L", na.rm = TRUE),
    lotteries = sum(allocation_type == "S", na.rm = TRUE),
    total = auctions + lotteries,
    lottery_share = ifelse(total > 0, lotteries / total, NA_real_),
    .groups = "drop"
  ) %>%
  filter(total > 0)  # Remove groups with no contemplations

# Plot distribution of lottery shares by segment (flow)
plot_distribution_flow <- ggplot(flow_group_shares, aes(x = lottery_share, fill = factor(codigo_seg))) +
  geom_histogram(bins = 20, alpha = 0.7, position = "identity") +
  facet_wrap(~ codigo_seg, labeller = labeller(codigo_seg = function(x) paste("Segment", x))) +
  labs(
    title = "Distribution of Lottery Shares Across Groups by Segment (Flow Analysis)",
    x = "Lottery Share",
    y = "Number of Groups",
    fill = "Segment Code"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    legend.position = "none"
  ) +
  scale_x_continuous(labels = scales::percent)

# Save plot
figname_distribution_flow <- file.path(results_path, "lottery_share_distribution_flow.pdf")
ggsave(figname_distribution_flow, plot_distribution_flow, width = 12, height = 8, units = "in")


# Normalized duration analysis - Overall allocation ---------

dft <- df %>% 
  group_by(grupo_id) %>% 
  mutate(
    grupo_start_date = ifelse(
      any(adesao_min_flag == 1, na.rm = TRUE),
      min(date_base[adesao_min_flag == 1], na.rm = TRUE), 
      min(date_base, na.rm = TRUE)
    ),
    grupo_start_date = as.Date(grupo_start_date, origin = "1970-01-01"),
    
    grupo_months_elapsed = as.numeric(date_base - grupo_start_date) / 30.44,
    grupo_duration = first(prazo[!is.na(prazo)]),
    grupo_progress = pmax(0, pmin(1, grupo_months_elapsed / grupo_duration)),
    
    progress_bin = case_when(
      grupo_progress <= 0.05 ~ "0-5%",
      grupo_progress <= 0.1 ~ "5-10%",
      grupo_progress <= 0.15 ~ "10-15%",
      grupo_progress <= 0.2 ~ "15-20%",
      grupo_progress <= 0.25 ~ "20-25%",
      grupo_progress <= 0.3 ~ "25-30%",
      grupo_progress <= 0.35 ~ "30-35%",
      grupo_progress <= 0.4 ~ "35-40%",
      grupo_progress <= 0.45 ~ "40-45%",
      grupo_progress <= 0.5 ~ "45-50%",
      grupo_progress <= 0.55 ~ "50-55%",
      grupo_progress <= 0.6 ~ "55-60%",
      grupo_progress <= 0.65 ~ "60-65%",
      grupo_progress <= 0.7 ~ "65-70%",
      grupo_progress <= 0.75 ~ "70-75%",
      grupo_progress <= 0.8 ~ "75-80%",
      grupo_progress <= 0.85 ~ "80-85%",
      grupo_progress <= 0.9 ~ "85-90%",
      grupo_progress <= 0.95 ~ "90-95%",
      grupo_progress <= 1.00 ~ "95-100%",
      TRUE ~ "100%+"
    ),  
    
    progress_bin = factor(progress_bin, levels = c("0-5%", "5-10%", "10-15%", "15-20%", "20-25%", "25-30%", "30-35%", "35-40%",
                                                   "40-45%", "45-50%", "50-55%", "55-60%", "60-65%", "65-70%", "70-75%", "75-80%",
                                                   "80-85%", "85-90%", "90-95%", "95-100%", "100%+")),
    
    reliable_start = any(adesao_min_flag == 1, na.rm = TRUE)
  ) %>% 
  ungroup()




# Export all results ---------------

# Export aggregated analysis results
outfile_temporal <- file.path(import_path, "allocation_shares_temporal.csv")
write.csv(shares, outfile_temporal, row.names = FALSE)

outfile_groups <- file.path(import_path, "allocation_shares_groups.csv")
write.csv(group_shares, outfile_groups, row.names = FALSE)

# Export flow analysis results
outfile_temporal_flow <- file.path(import_path, "allocation_shares_temporal_flow.csv")
write.csv(flow_shares, outfile_temporal_flow, row.names = FALSE)

outfile_groups_flow <- file.path(import_path, "allocation_shares_groups_flow.csv")
write.csv(flow_group_shares, outfile_groups_flow, row.names = FALSE)



