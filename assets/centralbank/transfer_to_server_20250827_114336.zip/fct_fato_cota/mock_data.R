# ---------------------------------------------- # 
#              Mock Data Generation
# ---------------------------------------------- # 

library(dplyr)
library(lubridate)
library(tidyr)

rm(list = ls())
set.seed(42)

# Define parameters
segments <- c(11, 31, 41)
n_groups_per_segment <- c(10, 20, 30)
names(n_groups_per_segment) <- segments
start_date <- as.Date("2000-01-01")
end_date <- as.Date("2006-01-01")
base_start <- as.Date("2000-03-31")

# Create group-level information
groups_data <- data.frame()
for(seg in segments) {
  n_groups <- n_groups_per_segment[as.character(seg)]
  seg_groups <- data.frame(
    codigo_seg = seg,
    grupo_id = 1:n_groups,
    n_cotas = sample(8:12, n_groups, replace = TRUE),
    duracao_anos = sample(8:12, n_groups, replace = TRUE),
    grupo_start_date = sample(seq(start_date, end_date, by = "day"), n_groups, replace = TRUE)
  )
  groups_data <- rbind(groups_data, seg_groups)
}
groups_data$grupo_id <- 1:nrow(groups_data)

# Create quota-level base structure
quota_base <- data.frame()
for(i in 1:nrow(groups_data)) {
  group_info <- groups_data[i, ]
  group_quotas <- data.frame(
    codigo_seg = group_info$codigo_seg,
    grupo_id = group_info$grupo_id,
    cota_id = 1:group_info$n_cotas,
    cota_sub_id = 0,
    duracao_anos = group_info$duracao_anos,
    grupo_start_date = group_info$grupo_start_date
  )
  quota_base <- rbind(quota_base, group_quotas)
}

# Create quarterly date sequence (proper quarter ends)
start_year <- 2000
end_year <- 2030  # Extended to allow groups to complete their full duration
quarters <- expand_grid(
  year = start_year:end_year,
  quarter = 1:4
) %>%
  mutate(
    date_base = case_when(
      quarter == 1 ~ as.Date(paste(year, "03", "31", sep = "-")),
      quarter == 2 ~ as.Date(paste(year, "06", "30", sep = "-")),
      quarter == 3 ~ as.Date(paste(year, "09", "30", sep = "-")),
      quarter == 4 ~ as.Date(paste(year, "12", "31", sep = "-"))
    )
  ) %>%
  filter(date_base >= base_start) %>%
  arrange(date_base)

quarterly_dates <- quarters$date_base

# Expand to panel data (quota × time)
panel_data <- expand_grid(
  quota_index = 1:nrow(quota_base),
  quarter_index = 1:length(quarterly_dates)
) %>%
  left_join(
    quota_base %>% mutate(quota_index = row_number()),
    by = "quota_index"
  ) %>%
  mutate(
    date_base = quarterly_dates[quarter_index],
    group_end_date = grupo_start_date %m+% years(duracao_anos)
  ) %>%
  filter(
    date_base >= grupo_start_date,
    date_base <= group_end_date
  ) %>%
  select(-quota_index, -quarter_index, -group_end_date)

# Create time variables efficiently
panel_data <- panel_data %>%
  mutate(
    year = year(date_base),
    month = month(date_base),
    quarter = quarter(date_base),
    year_adesao = year(grupo_start_date),
    date_adesao = grupo_start_date
  )

# Create formatted strings efficiently
chunk_size <- 10000
n_chunks <- ceiling(nrow(panel_data) / chunk_size)

panel_data$date_base_str <- character(nrow(panel_data))
panel_data$date_adesao_str <- character(nrow(panel_data))

for(i in 1:n_chunks) {
  start_idx <- (i-1) * chunk_size + 1
  end_idx <- min(i * chunk_size, nrow(panel_data))
  
  panel_data$date_base_str[start_idx:end_idx] <- 
    tolower(format(panel_data$date_base[start_idx:end_idx], "%d%b%Y"))
  
  panel_data$date_adesao_str[start_idx:end_idx] <- 
    tolower(format(panel_data$date_adesao[start_idx:end_idx], "%d%b%Y"))
}

# Add other variables
panel_data <- panel_data %>%
  group_by(grupo_id) %>%
  mutate(
    # Calculate endogenous prazo based on actual group span in the data
    group_start_date_actual = min(date_base, na.rm = TRUE),
    group_end_date_actual = max(date_base, na.rm = TRUE),
    # Calculate prazo in months (approximately)
    prazo = round(as.numeric(group_end_date_actual - group_start_date_actual) / 30.44),
    # Ensure minimum prazo of 12 months
    prazo = pmax(prazo, 12)
  ) %>%
  ungroup() %>%
  mutate(
    adm_id = 1,
    cota_full_id = paste(cota_id, cota_sub_id, sep = "-"),
    sit_atual = 1,
    pessoa_fisica = 1,
    allocation_type = NA_character_,
    date_contemp = as.Date(NA),
    date_cancel = as.Date(NA),
    date_contemp_str = NA_character_,
    date_cancel_str = NA_character_,
    auction = NA_real_,
    lottery = NA_real_,
    valor_bem = case_when(
      codigo_seg == 11 ~ 300000,
      codigo_seg == 31 ~ 50000,
      codigo_seg == 41 ~ 15000
    ),
    pct_lance = 0,
    tx_adm = 10,
    tx_adm_antecip = 0,
    pct_amort_mensal = 2,
    pct_amort_acumul = 0,
    fundo_comum_acumul = 0,
    fundo_reserva_acumul = 0,
    tx_adm_acumul = 0,
    juros_multas_acumul = 0,
    credit_contemp = 0,
    pct_atraso = 0,
    renda_cotista = 5000
  ) %>%
  select(-grupo_start_date, -duracao_anos, -group_start_date_actual, -group_end_date_actual)

# Add contemplation logic
panel_data <- panel_data %>%
  group_by(grupo_id, cota_id) %>%
  mutate(
    # Calculate actual number of quarters available for this group
    n_quarters_group = n(),
    # Assign contemplation quarter randomly spread throughout group life
    # Ensure all quotas are contemplated between 20% and 100% of group life
    # With some bias toward later periods to better spread contemplations
    contemp_quarter_position = pmax(0.2, runif(1, min = 0.2, max = 1.0)),
    # Use actual group size for indexing (not theoretical prazo/4)
    contemp_quarter_index = ceiling(contemp_quarter_position * n_quarters_group),
    # Ensure index doesn't exceed available quarters
    contemp_quarter_index = pmin(contemp_quarter_index, n_quarters_group),
    # Get the actual contemplation date using relative indexing within group
    contemp_date = date_base[contemp_quarter_index],
    # Randomly assign contemplation type (60% lottery, 40% auction)
    contemp_type = sample(c("S", "L"), 1, prob = c(0.6, 0.4))
  ) %>%
  ungroup() %>%
  mutate(
    # Create contemplation variables based on whether cota is contemplated yet
    is_contemplated = date_base >= contemp_date,
    
    # Update allocation_type: NA before contemplation, L/S after
    allocation_type = ifelse(is_contemplated, contemp_type, NA_character_),
    
    # Update date_contemp: filled from contemplation quarter onwards
    date_contemp = ifelse(is_contemplated, contemp_date, as.Date(NA)),
    date_contemp = as.Date(date_contemp, origin = "1970-01-01"),
    
    # Update auction and lottery flags
    auction = case_when(
      is_contemplated & contemp_type == "L" ~ 1,
      TRUE ~ NA_real_
    ),
    lottery = case_when(
      is_contemplated & contemp_type == "S" ~ 1,
      TRUE ~ NA_real_
    ),
    
    # Update date_contemp_str
    date_contemp_str = ifelse(
      !is.na(date_contemp),
      tolower(format(date_contemp, "%d%b%Y")),
      NA_character_
    )
  ) %>%
  # Clean up temporary variables
  select(-n_quarters_group, -contemp_quarter_position, -contemp_quarter_index, 
         -contemp_date, -contemp_type, -is_contemplated)

# Sort and organize final dataset
mock_data <- panel_data %>%
  arrange(adm_id, grupo_id, cota_id, year, month)