# Central Bank session completion script
# • Input: none (uses standard folder structure)
# • Output: timestamped zip with all code files and folder structure report

# Load utilities
source("utils/outbound_packager.R")

# Package session for outbound transfer
result <- package_outbound(
  base_path = ".",  # Package from server/ folder only
  outbound_path = "../transfer_outbound"
)

cat("\n=== SESSION LOGOUT COMPLETE ===\n")
if (!is.null(result)) {
  cat("Export ready for transfer:", basename(result), "\n")
} else {
  cat("Export failed - check logs above\n")
}
