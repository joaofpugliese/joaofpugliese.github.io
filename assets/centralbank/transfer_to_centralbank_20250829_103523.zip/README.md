# Central Bank Server: Folder Structure & Workflow

## Core Scripts

### `init.R`
- **Purpose**: Session initialization and inbound file analysis
- **Input**: Uses `inbound/` folder contents  
- **Output**: Analysis report of new files and overlap detection with existing codebase
- **Usage**: Run at start of session to process incoming data files

### `logout.R` 
- **Purpose**: Session completion and outbound packaging
- **Input**: All R/Python code files in server directory
- **Output**: Timestamped zip archive in `outbound/` folder  
- **Usage**: Run at end of session to export all work

## Transfer Folders

### `inbound/`
- **Purpose**: Receives new data files and code from external sources
- **Contents**: Raw files, zip archives (auto-extracted by `init.R`)
- **Lifecycle**: 
  - Files deposited by external process
  - Analyzed and extracted during initialization
  - **Manual cleanup required** after processing

### `outbound/`
- **Purpose**: Stores packaged exports ready for external transfer
- **Contents**: Timestamped zip files (`transfer_from_server_YYYYMMDD_HHMMSS.zip`)
- **Lifecycle**:
  - Created by `logout.R` with all session code
  - **Manual cleanup recommended** after successful transfer
  - Old exports accumulate until manually removed

## Workflow

```
1. External data → inbound/
2. run init.R → analyze inbound/ → work on code
3. run logout.R → package to outbound/ → external transfer
```

## File Management
- **Inbound**: Clean manually after confirming successful import
- **Outbound**: Clean manually after confirming successful external transfer  
- **No automatic deletion** - manual oversight required for data safety
