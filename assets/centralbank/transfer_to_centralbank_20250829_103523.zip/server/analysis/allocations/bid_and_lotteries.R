# ---------------------------------------------- # 
#            Bid and Lotteries Analysis
# ---------------------------------------------- # 

# Packages ---------------------------------------

library(dplyr)
library(ggplot2)
library(lubridate)
library(tidyr)
library(ggplot2)

# Importing dataset

# Use fread for faster file reading (header = TRUE is default)
# Add grepl to check if the working directory is Dropbox (outside server) or not
if(grepl("Dropbox", getwd())) {
  df <- readRDS("data/code/centralbank/server/data/output/contemplacoes_cota_level.rds")
} else {
  df <- fread("D:/server/data/mock_data/clean_FCT.csv", stringsAsFactors = FALSE, showProgress = TRUE)
}

# Análise de contemplações por grupo ao longo do tempo
df <- df %>% filter(!is.na(date_contemp))


# 1. Análise a nível de grupo ---------------

# Para cada grupo: total de cotas e contemplações acumuladas até cada data
group_contemplation_analysis <- df %>%
  mutate(
    # Corrigir interpretação da data (formato ano-dia-mês para ano-mês-dia)
    date_contemp_corrected = as.Date(paste0(year(date_contemp), "-", day(date_contemp), "-", month(date_contemp))),
    year_quarter = paste0(year_contemp, "-Q", quarter(date_contemp_corrected))
  ) %>%
  group_by(grupo_id) %>%
  mutate(total_cotas_grupo = n()) %>%
  ungroup() %>%
  group_by(grupo_id, year_quarter) %>%
  summarise(
    total_cotas_grupo = first(total_cotas_grupo),
    cotas_contempladas_periodo = n(),
    cotas_lance_periodo = sum(allocation_type == "L"),
    cotas_sorteio_periodo = sum(allocation_type == "S"),
    .groups = "drop"
  ) %>%
  arrange(grupo_id, year_quarter) %>%
  group_by(grupo_id) %>%
  mutate(
    cotas_contempladas_acum = cumsum(cotas_contempladas_periodo),
    cotas_lance_acum = cumsum(cotas_lance_periodo),
    cotas_sorteio_acum = cumsum(cotas_sorteio_periodo),
    pct_contempladas_acum = round(cotas_contempladas_acum / total_cotas_grupo * 100, 1),
    pct_lance_acum = round(cotas_lance_acum / cotas_contempladas_acum * 100, 1),
    pct_sorteio_acum = round(cotas_sorteio_acum / cotas_contempladas_acum * 100, 1)
  ) %>%
  ungroup()


# Evolução do grupo - Acumulado

selected_group <- 1

plot_group_evolution <- group_contemplation_analysis %>%
  filter(grupo_id == selected_group) %>%
  mutate(
    # Converter year_quarter para data para o eixo x
    quarter_date = as.Date(paste0(
      substr(year_quarter, 1, 4), "-", 
      sprintf("%02d", (as.numeric(substr(year_quarter, 7, 7)) - 1) * 3 + 1), 
      "-01"
    ))
  ) %>%
  ggplot(aes(x = quarter_date)) +
  geom_hline(aes(yintercept = total_cotas_grupo), linetype = "dashed", color = "black", size = 1) +
  geom_line(aes(y = cotas_contempladas_acum, color = "Total Contempladas"), size = 1) +
  geom_line(aes(y = cotas_lance_acum, color = "Lance"), size = 1) +
  geom_line(aes(y = cotas_sorteio_acum, color = "Sorteio"), size = 1) +
  labs(
    title = paste("Grupo", selected_group, "- Evolução das Contemplações ao Longo do Tempo"),
    x = "Data",
    y = "Número de Cotas",
    color = "Tipo"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "bottom"
  ) +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 6)) +
  scale_x_date(date_labels = "%Y-Q%q", date_breaks = "1 year") +
  scale_color_manual(values = c("Total Contempladas" = "black", "Lance" = "blue", "Sorteio" = "red"))

plot_group_evolution


# Evolução do grupo - Fluxo

selected_group <- 1

plot_group_flow <- group_contemplation_analysis %>%
  filter(grupo_id == selected_group) %>%
  mutate(
    # Converter year_quarter para data para o eixo x
    quarter_date = as.Date(paste0(
      substr(year_quarter, 1, 4), "-", 
      sprintf("%02d", (as.numeric(substr(year_quarter, 7, 7)) - 1) * 3 + 1), 
      "-01"
    ))
  ) %>%
  pivot_longer(
    cols = c(cotas_lance_periodo, cotas_sorteio_periodo),
    names_to = "tipo",
    values_to = "cotas"
  ) %>%
  mutate(
    tipo = case_when(
      tipo == "cotas_lance_periodo" ~ "Lance",
      tipo == "cotas_sorteio_periodo" ~ "Sorteio"
    )
  ) %>%
  ggplot(aes(x = quarter_date, y = cotas, fill = tipo)) +
  geom_col() +
  labs(
    title = paste("Grupo", selected_group, "- Fluxo de Contemplações por Período"),
    x = "Data",
    y = "Número de Cotas (por período)",
    fill = "Tipo"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "bottom"
  ) +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 6)) +
  scale_x_date(date_labels = "%Y-Q%q", date_breaks = "1 year") +
  scale_fill_manual(values = c("Lance" = "blue", "Sorteio" = "red"))

plot_group_flow


# 2. Análise a nível de segmento ---------------

# Análise por segmento com tempo padronizado (0-1)
segment_contemplation_analysis <- df %>%
  mutate(
    # Corrigir interpretação da data (formato ano-dia-mês para ano-mês-dia)
    date_contemp_corrected = as.Date(paste0(year(date_contemp), "-", day(date_contemp), "-", month(date_contemp)))
  ) %>%
  group_by(grupo_id) %>%
  mutate(
    min_date_grupo = min(date_contemp_corrected),
    max_date_grupo = max(date_contemp_corrected),
    # Calcular posição temporal normalizada (0 = início, 1 = fim do grupo)
    tempo_normalizado = as.numeric(date_contemp_corrected - min_date_grupo) / 
                       as.numeric(max_date_grupo - min_date_grupo),
    # Criar períodos de 5% (0-0.05, 0.05-0.10, ..., 0.95-1.00)
    periodo_5pct = floor(tempo_normalizado * 20) / 20,
    # Garantir que a última observação seja 1.00 (não 0.95)
    periodo_5pct = ifelse(tempo_normalizado == 1, 0.95, periodo_5pct)
  ) %>%
  ungroup() %>%
  group_by(codigo_seg) %>%
  mutate(total_cotas_segmento = n()) %>%
  ungroup() %>%
  group_by(codigo_seg, periodo_5pct) %>%
  summarise(
    total_cotas_segmento = first(total_cotas_segmento),
    n_grupos = n_distinct(grupo_id),
    cotas_contempladas_periodo = n(),
    cotas_lance_periodo = sum(allocation_type == "L"),
    cotas_sorteio_periodo = sum(allocation_type == "S"),
    .groups = "drop"
  ) %>%
  arrange(codigo_seg, periodo_5pct) %>%
  group_by(codigo_seg) %>%
  mutate(
    cotas_contempladas_acum = cumsum(cotas_contempladas_periodo),
    cotas_lance_acum = cumsum(cotas_lance_periodo),
    cotas_sorteio_acum = cumsum(cotas_sorteio_periodo),
    pct_lance_acum = round(cotas_lance_acum / cotas_contempladas_acum * 100, 1),
    pct_sorteio_acum = round(cotas_sorteio_acum / cotas_contempladas_acum * 100, 1),
    pct_contempladas_lance = round(cotas_lance_acum / total_cotas_segmento * 100, 1)
  ) %>%
  ungroup()


# Evolução do segmento - Acumulado

selected_segment <- "SEG1"

plot_segment_evolution <- segment_contemplation_analysis %>%
  filter(codigo_seg == selected_segment) %>%
  ggplot(aes(x = periodo_5pct)) +
  geom_hline(aes(yintercept = total_cotas_segmento), linetype = "dashed", color = "black", size = 1) +
  geom_line(aes(y = cotas_contempladas_acum, color = "Total Contempladas"), size = 1) +
  geom_line(aes(y = cotas_lance_acum, color = "Lance"), size = 1) +
  geom_line(aes(y = cotas_sorteio_acum, color = "Sorteio"), size = 1) +
  labs(
    title = paste("Segmento", selected_segment, "- Evolução das Contemplações (Tempo Normalizado)"),
    x = "Tempo de Vida do Grupo (0 = Início, 1 = Final)",
    y = "Número de Cotas",
    color = "Tipo"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "bottom"
  ) +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 6)) +
  scale_x_continuous(breaks = seq(0, 1, 0.1), labels = scales::percent_format()) +
  scale_color_manual(values = c("Total Contempladas" = "black", "Lance" = "blue", "Sorteio" = "red"))

plot_segment_evolution

# Evolução do segmento - Fluxo

selected_segment <- "SEG1"

plot_segment_flow <- segment_contemplation_analysis %>%
  filter(codigo_seg == selected_segment) %>%
  pivot_longer(
    cols = c(cotas_lance_periodo, cotas_sorteio_periodo),
    names_to = "tipo",
    values_to = "cotas"
  ) %>%
  mutate(
    tipo = case_when(
      tipo == "cotas_lance_periodo" ~ "Lance",
      tipo == "cotas_sorteio_periodo" ~ "Sorteio"
    )
  ) %>%
  ggplot(aes(x = periodo_5pct, y = cotas, fill = tipo)) +
  geom_col() +
  labs(
    title = paste("Segmento", selected_segment, "- Fluxo de Contemplações por Período (Tempo Normalizado)"),
    x = "Tempo de Vida do Grupo (0 = Início, 1 = Final)",
    y = "Número de Cotas (por período)",
    fill = "Tipo"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "bottom"
  ) +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 6)) +
  scale_x_continuous(breaks = seq(0, 1, 0.1), labels = scales::percent_format()) +
  scale_fill_manual(values = c("Lance" = "blue", "Sorteio" = "red"))

plot_segment_flow


# Gráfico comparativo: % de contemplações por lance para todos os segmentos
plot_segments_lance_comparison <- segment_contemplation_analysis %>%
  ggplot(aes(x = periodo_5pct, y = pct_contempladas_lance, color = codigo_seg)) +
  geom_line(size = 1.2) +
  labs(
    title = "Comparação entre Segmentos: % de Cotas Contempladas por Lance",
    x = "Tempo de Vida do Grupo (0 = Início, 1 = Final)",
    y = "% de Cotas Contempladas por Lance",
    color = "Segmento"
  ) +
  theme_bw() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "bottom"
  ) +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 6)) +
  scale_x_continuous(breaks = seq(0, 1, 0.1), labels = scales::percent_format()) +
  scale_color_brewer(type = "qual", palette = "Set1")

plot_segments_lance_comparison



