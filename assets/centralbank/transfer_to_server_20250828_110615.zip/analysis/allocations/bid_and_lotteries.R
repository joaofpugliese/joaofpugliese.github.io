
# ---------------------------------------------- # 
#            Bid and Lotteries Analysis
# ---------------------------------------------- # 

# Packages ---------------------------------------

library(dplyr)
library(ggplot2)
library(lubridate)
library(tidyr)
library(ggplot2)

# Set paths, working directory and df ------------

# Importing dataset
df <- read.csv("D:/server/data/mock_data/clean_FCT.csv")


# 1. Overall allocation over the years ---------------

# Filter only contemplated quotas (auction or lottery)
contemplations <- df %>%
  filter(allocation_type %in% c("L", "S")) %>%  # Only contemplations
  mutate(
    year_month = sprintf("%04d-%02d", year, month)
  )

# Get group sizes
group_sizes <- df %>%
  group_by(grupo_id) %>%
  summarise(group_size = n_distinct(cota_id), .groups = "drop")

# Group by group, year-month, and allocation type (with segment info)
allocation_counts <- contemplations %>%
  group_by(grupo_id, codigo_seg, year_month, allocation_type) %>%
  summarise(n_contemplations = n(), .groups = "drop")

# Reshape to wide and compute share
shares <- allocation_counts %>%
  pivot_wider(
    names_from = allocation_type,
    values_from = n_contemplations,
    values_fill = 0
  ) %>%
  mutate(
    total = L + S,
    lottery_share = S / total
  ) %>%
  # Add group size information
  left_join(group_sizes, by = "grupo_id")

# Plot for specific group - evolution over time
selected_group <- 100

plot_group_evolution <- df %>%
  filter(grupo_id == selected_group) %>%
  group_by(date_base) %>%
  summarise(
    total_quotas = n_distinct(cota_id),
    total_contemplated = sum(!is.na(allocation_type), na.rm = TRUE),
    lottery_contemplated = sum(allocation_type == "S", na.rm = TRUE),
    auction_contemplated = sum(allocation_type == "L", na.rm = TRUE),
    .groups = "drop"
  ) %>%
  ggplot(aes(x = date_base)) +
  geom_line(aes(y = total_quotas), linetype = "dotted", color = "black", size = 1) +
  geom_line(aes(y = total_contemplated), linetype = "solid", color = "black", size = 1) +
  geom_line(aes(y = lottery_contemplated), linetype = "solid", color = "blue", size = 1) +
  geom_line(aes(y = auction_contemplated), linetype = "solid", color = "red", size = 1) +
  labs(
    title = paste("Group", selected_group, "- Evolution of Contemplations Over Time"),
    x = "Date",
    y = "Number of Quotas"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1)
  ) +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 6))

plot_group_evolution

# 2. Segment analysis with normalized time deciles ---------------
 
# Print summary statistics for the selected segment
cat("\n=== SEGMENT", selected_segment, "SUMMARY ===\n")
cat("Segment description:", 
    case_when(
      selected_segment == 11 ~ "Imóveis (R$ 300,000)",
      selected_segment == 31 ~ "Veículos pesados (R$ 50,000)", 
      selected_segment == 41 ~ "Veículos leves (R$ 15,000)",
      TRUE ~ "Unknown segment"
    ), "\n")

# Show data used in plot
print(segment_plot_data)

# Show overall segment statistics
segment_totals <- segment_shares %>%
  filter(codigo_seg == selected_segment) %>%
  summarise(
    total_contemplated = sum(total, na.rm = TRUE),
    total_lottery = sum(S, na.rm = TRUE),
    total_auction = sum(L, na.rm = TRUE),
    lottery_share = round(total_lottery / total_contemplated * 100, 1),
    .groups = "drop"
  )

cat("Total contemplated:", segment_totals$total_contemplated, "\n")
cat("Total lottery:", segment_totals$total_lottery, "\n")
cat("Total auction:", segment_totals$total_auction, "\n")
cat("Lottery share:", paste0(segment_totals$lottery_share, "%"), "\n")


# Export all results ---------------

# Export aggregated analysis results
outfile_temporal <- file.path(import_path, "allocation_shares_temporal.csv")
write.csv(shares, outfile_temporal, row.names = FALSE)

outfile_groups <- file.path(import_path, "allocation_shares_groups.csv")
write.csv(group_shares, outfile_groups, row.names = FALSE)

# Export flow analysis results
outfile_temporal_flow <- file.path(import_path, "allocation_shares_temporal_flow.csv")
write.csv(flow_shares, outfile_temporal_flow, row.names = FALSE)

outfile_groups_flow <- file.path(import_path, "allocation_shares_groups_flow.csv")
write.csv(flow_group_shares, outfile_groups_flow, row.names = FALSE)

# Export normalized duration analysis results
outfile_normalized <- file.path(import_path, "allocation_shares_normalized_lifecycle.csv")
write.csv(normalized_shares, outfile_normalized, row.names = FALSE)



