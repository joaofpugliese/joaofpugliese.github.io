# ---------------------------------------------- # 
#          Data cleaning - Contemplações (Aggregated Dataset)
# ---------------------------------------------- # 
#
# This script cleans the aggregated contemplações dataset created by cotas_21_8.sql
# Unlike 0_cleaning_FCT.R, this is NOT a panel - each row is a unique cota
# with summary statistics aggregated over time
#
# Performance optimizations implemented:
# - data.table for faster operations (vs dplyr)
# - fread() for faster file import
# - Combined operations with := for modify-by-reference
# - Efficient type conversions and date parsing
# - Early memory cleanup and garbage collection
# ---------------------------------------------- #

# Packages ---------------------------------------

library(data.table)
library(lubridate)

# Importing dataset ------------------------------
if (getwd() != "data/code/centralbank/server/data") {
  setwd("data/code/centralbank/server/data")
}

# Use fread for faster file reading (header = TRUE is default)
df <- fread("D:/bases/cotas_21_8.txt", stringsAsFactors = FALSE, showProgress = TRUE)


# Data cleaning ----------------------------------

# Convert to data.table for faster operations
setDT(df)

# Create clean identifier variables (consistent with 0_cleaning_FCT.R naming)
df[, `:=`(
  # Core identifiers - consistent naming with main dataset
  cota_id = cot_cd_cota,
  cota_sub_id = cot_cd_seq_cota,
  codigo_seg = fct_cd_seg,
  cpf_fake_id = cpf2,  # Add cpf_fake_id for consistency with main dataset
  
  # Factor conversion for admin and group IDs (consistent with main cleaning)
  adm_id = as.integer(as.factor(adm_cd2)),
  grupo_id = as.integer(as.factor(gai_cd_grupo2))
)]

# Create composite ID (consistent with main dataset)
df[, cota_full_id := paste(cota_id, cota_sub_id, sep = "-")]

# Clean up original ID columns
id_cols_to_remove <- c("cot_cd_cota", "cot_cd_seq_cota", "fct_cd_seg", 
                       "cpf2", "adm_cd2", "gai_cd_grupo2")
df[, (id_cols_to_remove) := NULL]
gc()

# Convert time diagnostic variables to integers
time_diagnostic_cols <- c("n_rows" = "n_observations", 
                         "n_dates" = "n_periods")

df[, (time_diagnostic_cols) := lapply(.SD, as.integer), .SDcols = names(time_diagnostic_cols)]

# Clean up original time diagnostic columns
df[, (names(time_diagnostic_cols)) := NULL]
gc()

# Convert date variables - handle base date format (YYYYMM)
df[, `:=`(
  # Convert base dates from YYYYMM format to proper dates (last day of month)
  min_date_base = as.Date(paste0(substr(min_dac_dt_base, 1, 4), "-", 
                                substr(min_dac_dt_base, 5, 6), "-01")) + months(1) - days(1),
  max_date_base = as.Date(paste0(substr(max_dac_dt_base, 1, 4), "-", 
                                substr(max_dac_dt_base, 5, 6), "-01")) + months(1) - days(1),
  
  # Convert contemplation dates (assuming MM/DD/YYYY format like main dataset)
  min_date_contemp = as.Date(fct_dt_contemp_min, format = "%m/%d/%Y"),
  max_date_contemp = as.Date(fct_dt_contemp_max, format = "%m/%d/%Y")
)]

# Clean up original date columns
date_cols_to_remove <- c("min_dac_dt_base", "max_dac_dt_base", 
                        "fct_dt_contemp_min", "fct_dt_contemp_max")
df[, (date_cols_to_remove) := NULL]
gc()

# Convert numeric aggregate variables (duration and value statistics)
numeric_agg_cols <- c("max_sd_fct_qt_dur_plano" = "max_prazo",
                      "min_sd_fct_qt_dur_plano" = "min_prazo", 
                      "max_sd_fct_vl_bem" = "max_valor_bem",
                      "min_sd_fct_vl_bem" = "min_valor_bem",
                      "min_fct_qt_dur_plano" = "min_prazo_obs",
                      "max_fct_qt_dur_plano" = "max_prazo_obs",
                      "min_fct_vl_bem" = "min_valor_bem_obs",
                      "max_fct_vl_bem" = "max_valor_bem_obs")

df[, (numeric_agg_cols) := lapply(.SD, as.numeric), .SDcols = names(numeric_agg_cols)]

# Clean up original numeric columns
df[, (names(numeric_agg_cols)) := NULL]
gc()

# Convert categorical diagnostic variables to integers
categorical_agg_cols <- c("dcount_fct_cd_tip_cotista" = "n_distinct_tip_cotista",
                         "dcount_fct_st_atual" = "n_distinct_status",
                         "dcount_fct_ib_contemp" = "n_distinct_allocation")

df[, (categorical_agg_cols) := lapply(.SD, as.integer), .SDcols = names(categorical_agg_cols)]

# Clean up original categorical diagnostic columns
df[, (names(categorical_agg_cols)) := NULL]
gc()

# Convert representative categorical values
categorical_rep_cols <- c("min_fct_cd_tip_cotista" = "min_tip_cotista",
                         "max_fct_cd_tip_cotista" = "max_tip_cotista",
                         "min_fct_st_atual" = "min_status",
                         "max_fct_st_atual" = "max_status")

df[, (categorical_rep_cols) := lapply(.SD, as.integer), .SDcols = names(categorical_rep_cols)]

# Clean up original categorical representative columns
df[, (names(categorical_rep_cols)) := NULL]
gc()

# Process allocation type variables (character/factor)
df[, `:=`(
  min_allocation_type = min_fct_ib_contemp,
  max_allocation_type = max_fct_ib_contemp
)]

# Create consistent allocation_type when min equals max (invariant across time)
df[, allocation_type := fifelse(
  min_allocation_type == max_allocation_type, 
  min_allocation_type, 
  NA_character_
)]

# Create consistent date_contemp when min equals max (consistent with 0_cleaning_FCT naming)
df[, date_contemp := fifelse(
  min_date_contemp == max_date_contemp, 
  min_date_contemp, 
  as.Date(NA)
)]

# Create auction and lottery mechanisms (only when allocation type is consistent)
df[, `:=`(
  # Auction and lottery mechanisms
  auction = fifelse(min_allocation_type == max_allocation_type & max_allocation_type == "L", 1, NA_real_),
  lottery = fifelse(min_allocation_type == max_allocation_type & max_allocation_type == "S", 1, NA_real_),
  allocation_type_factor = as.factor(fifelse(min_allocation_type == max_allocation_type, max_allocation_type, NA_character_))
)]

# Clean up original allocation columns
allocation_cols_to_remove <- c("min_fct_ib_contemp", "max_fct_ib_contemp")
df[, (allocation_cols_to_remove) := NULL]
gc()

# Create derived time variables (consistent with main dataset approach)
df[, `:=`(
  # Time span variables
  time_span_months = as.numeric(max_date_base - min_date_base) / 30.44, # approximate months
  time_span_days = as.numeric(max_date_base - min_date_base),
  
  # Year variables for first and last periods
  year_min = year(min_date_base),
  year_max = year(max_date_base),
  
  # Data quality flags
  invariant_dt_contemp = fifelse(min_date_contemp == max_date_contemp, 1, 0),
  invariant_prazo = fifelse(min_prazo_obs == max_prazo_obs, 1, 0),
  invariant_valor_bem = fifelse(min_valor_bem_obs == max_valor_bem_obs, 1, 0),
  invariant_tip_cotista = fifelse(n_distinct_tip_cotista == 1, 1, 0),
  invariant_status = fifelse(n_distinct_status == 1, 1, 0),
  invariant_allocation = fifelse(n_distinct_allocation == 1, 1, 0)
)]

# Create pessoa_fisica flag (consistent with main dataset)
df[, pessoa_fisica := fcase(
  min_tip_cotista == 2 & max_tip_cotista == 2, 1,  # Always individual
  min_tip_cotista == 1 & max_tip_cotista == 1, 0,  # Always firm
  min_tip_cotista == 3 & max_tip_cotista == 3, NA_real_, # Always unidentified
  default = NA_real_  # Mixed or other cases
)]

# Sorting dataframe for consistency
setorder(df, adm_id, grupo_id, cota_id, cpf_fake_id, cota_full_id)

# Data Quality Summary and Dataset Description ------------------------------

# Load data description function
source("../utils/data_description.R")

# Quick invariant variables table
invariant_flags <- c("invariant_dt_contemp", "invariant_prazo", "invariant_valor_bem", 
                     "invariant_tip_cotista", "invariant_status", "invariant_allocation")
invariant_summary <- sapply(invariant_flags, function(x) table(df[[x]]))
print(invariant_summary)

# Run dataset description
data_description(df, dataset_name = "Contemplações")

# Exporting to .rds and .csv ------------------------------

# Fast export using data.table  
saveRDS(df, "contemplacoes_clean.rds")
fwrite(df, "contemplacoes_clean.csv")