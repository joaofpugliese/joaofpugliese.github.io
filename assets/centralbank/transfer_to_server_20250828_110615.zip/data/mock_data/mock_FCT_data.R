# ---------------------------------------------- # 
#          Mock FCT Data Generation
# ---------------------------------------------- # 
#
# Creates realistic mock data for testing both cleaning scripts
# with 1 million observations to compare performance and results
# ---------------------------------------------- #

#%% Packages ---------------------------------------
library(rprojroot)
root <- find_root_file("util.R", criterion = has_file("util.R"))
source(root) # Util functions

#%% Set seed for reproducibility -------------------
set.seed(123)

#%% Parameters ------------------------------------

# Realistic structure: 10 admins x 10 groups per admin x ~100 cotas per group
n_admins <- 10
n_groups_per_admin <- 10
n_cotas_per_group <- 200
n_cotas <- n_admins * n_groups_per_admin * n_cotas_per_group  # = 20,000 cotas

# Dates
earliest_date <- "201503"
latest_date <- "202503"

# Value distributions
mean_valor_bem <- 150000
sd_valor_bem <- 10000
inflation_rate_semestre <- 0.025

# Cancellation fee
cancellation_fee <- 0.05
share_group <- 0
share_admin <- 1

#%% Helper functions -------------------
generate_dates <- function(n, start_date, end_date) {
  dates <- sample(seq(as.Date(start_date), as.Date(end_date), by = "day"), n, replace = TRUE)
  format(dates, "%m/%d/%Y")
}

generate_trimester_dates <- function(years, months = c(3, 6, 9, 12)) {
  paste0(years, sprintf("%02d", months))
}

# Step 1: Generate group start dates from trimesters (201503 to 202503)
# Create all possible trimester dates
generate_trimester_sequence <- function(start_year = 2015, end_year = 2025) {
  trimester_dates <- c()
  
  for(year in start_year:end_year) {
    for(month in c(3, 6, 9, 12)) {
      # Stop at 202503 (March 2025)
      if(year == 2025 && month > 3) break
      
      trimester_dates <- c(trimester_dates, paste0(year, sprintf("%02d", month)))
    }
  }
  
  return(trimester_dates)
}
trimester_to_sequence <- function(trimester_str, base_year = as.numeric(substr(earliest_date, 1, 4))) {
  year <- as.numeric(substr(trimester_str, 1, 4))
  month <- as.numeric(substr(trimester_str, 5, 6))
  
  # Convert month to quarter: 03=1, 06=2, 09=3, 12=4
  quarter <- ifelse(month == 3, 1, 
                   ifelse(month == 6, 2,
                         ifelse(month == 9, 3, 4)))
  
  # Calculate sequential trimester number (starting from 2015Q1 = 1)
  (year - base_year) * 4 + quarter
}

# Function to convert sequence number back to trimester
sequence_to_trimester <- function(s, base_year = as.numeric(substr(earliest_date, 1, 4))) {
  sprintf("%04d%02d", base_year + (s-1L)%/%4L, c(3,6,9,12)[(s-1L)%%4L + 1L])
}

#%% Generating groups and cotas

# Step 1:Randomly assign each group to a trimester start date
n_groups_total <- n_admins * n_groups_per_admin
group_start_dates <- data.table(
  adm_cd2 = rep(paste0("ADM", sprintf("%03d", 1:n_admins)), each = n_groups_per_admin),
  gai_cd_grupo2 = paste0("GRP", sprintf("%04d", 1:n_groups_total)),
  group_start_trimester = sample(generate_trimester_sequence(2015, 2025), n_groups_total, replace = TRUE)
)

# Step 2: Generate cotas with realistic group joining patterns
# Calculate how many trimesters each group has been active (until 202503)
group_start_dates[, `:=`(
  # Calculate trimesters active (simplified - assumes each trimester is 3 months apart)
  start_year = as.numeric(substr(group_start_trimester, 1, 4)),
  start_month = as.numeric(substr(group_start_trimester, 5, 6)),
  end_year = 2025,
  end_month = 3
)]

# Calculate how many cotas each group can actually have based on time available
group_start_dates[, trimesters_active := {
  start_seq <- trimester_to_sequence(group_start_trimester)
  end_seq <- trimester_to_sequence(latest_date)  # 202503 = 2025Q1
  
  # Number of trimesters from start to end (inclusive)
  pmax(1, end_seq - start_seq + 1)
}]

# Calculate expected cotas per group based on time active
group_start_dates[, cotas := {
  # Cota joining pattern: 140, +30, +10, +5, +5, +5, +5 = 200 after 7 trimesters
  pmin(200, pmax(0, 
    ifelse(trimesters_active >= 1, 140, 0) +
    ifelse(trimesters_active >= 2, 30, 0) +  
    ifelse(trimesters_active >= 3, 10, 0) +
    ifelse(trimesters_active >= 4, pmin(20, (trimesters_active - 3) * 5), 0)  # 5 per trimester after 3rd
  ))
}]

# Add group-level duration (each group gets a base duration)
group_start_dates[, group_duration := sample(c(48, 60, 72, 84, 96, 120), .N, replace = TRUE)]

# Calculate group end dates based on start date and duration
group_start_dates[, group_end_trimester := add_trimesters(group_start_trimester, group_duration %/% 3)]

# Function to add trimesters to a base trimester
add_trimesters <- function(base_trimester, offset) {
  year <- as.numeric(substr(base_trimester, 1, 4))
  month <- as.numeric(substr(base_trimester, 5, 6))
  
  # Convert to sequential quarter
  quarter <- ifelse(month == 3, 1, ifelse(month == 6, 2, ifelse(month == 9, 3, 4)))
  
  # Add offset trimesters
  total_quarters <- (year - 2015) * 4 + quarter + offset
  
  # Convert back to year and quarter
  new_year <- 2015 + floor((total_quarters - 1) / 4)
  new_quarter <- ((total_quarters - 1) %% 4) + 1
  
  # Convert quarter back to month
  new_month <- ifelse(new_quarter == 1, 3, ifelse(new_quarter == 2, 6, ifelse(new_quarter == 3, 9, 12)))
  
  return(paste0(new_year, sprintf("%02d", new_month)))
}

# Helper function to generate contemplation date for any sequence
generate_contemplation_date <- function(join_trimester, bem_value, alpha = 0.5, duration_months) {
  # Calculate months from join to contemplation based on u^(1/alpha) logic
  u <- runif(length(join_trimester))  # Generate one random number per sequence
  
  # Handle both single and vectorized alpha values
  # Scale by actual cota duration (respects each cota's specific duration)
  months_to_contemplation <- round((u^(1/alpha)) * duration_months, 0)
  
  # Add months to join trimester
  contemplation_trimester <- add_trimesters(join_trimester, months_to_contemplation %/% 3)
  
  # Convert to date format (first day of trimester)
  year <- substr(contemplation_trimester, 1, 4)
  month <- substr(contemplation_trimester, 5, 6)
  format(as.Date(paste0(year, "-", month, "-01")), "%d/%m/%Y")
}

# Generate cotas with join timing based on group patterns
generate_cotas_with_timing <- function(group_data) {
  all_cotas <- data.table()
  cota_counter <- 1
  
  for(i in 1:nrow(group_data)) {
    group_info <- group_data[i]
    n_cotas_this_group <- group_info$cotas  # Now always 200
    
    # Determine when each cota joins within this group
    cota_join_offsets <- c()
    cotas_remaining <- n_cotas_this_group
    trimester_offset <- 0
    
    # Trimester 1: 140 cotas (join at group start)
    if(cotas_remaining > 0) {
      batch_size <- min(140, cotas_remaining)
      cota_join_offsets <- c(cota_join_offsets, rep(trimester_offset, batch_size))
      cotas_remaining <- cotas_remaining - batch_size
      trimester_offset <- trimester_offset + 1
    }
    
    # Trimester 2: 30 cotas  
    if(cotas_remaining > 0) {
      batch_size <- min(30, cotas_remaining)
      cota_join_offsets <- c(cota_join_offsets, rep(trimester_offset, batch_size))
      cotas_remaining <- cotas_remaining - batch_size
      trimester_offset <- trimester_offset + 1
    }
    
    # Trimester 3: 10 cotas
    if(cotas_remaining > 0) {
      batch_size <- min(10, cotas_remaining)
      cota_join_offsets <- c(cota_join_offsets, rep(trimester_offset, batch_size))
      cotas_remaining <- cotas_remaining - batch_size
      trimester_offset <- trimester_offset + 1
    }
    
    # Remaining trimesters: 5 cotas each
    while(cotas_remaining > 0) {
      batch_size <- min(5, cotas_remaining)
      cota_join_offsets <- c(cota_join_offsets, rep(trimester_offset, batch_size))
      cotas_remaining <- cotas_remaining - batch_size
      trimester_offset <- trimester_offset + 1
    }
    
    # Calculate actual join trimesters for each cota
    cota_join_trimesters <- sapply(cota_join_offsets, function(offset) {
      add_trimesters(group_info$group_start_trimester, offset)
    })
    
         # Create cotas for this group
     group_cotas <- data.table(
       COT_CD_COTA = paste0("COT", sprintf("%06d", cota_counter:(cota_counter + n_cotas_this_group - 1))),
       adm_cd2 = group_info$adm_cd2,
       gai_cd_grupo2 = group_info$gai_cd_grupo2,
       group_start_trimester = group_info$group_start_trimester,
       cota_join_trimester = cota_join_trimesters,
       cota_join_offset = cota_join_offsets,
       FCT_CD_SEG = sample(paste0("SEG", 1:5), n_cotas_this_group, replace = TRUE),
       group_duration = group_info$group_duration
     )
    
    all_cotas <- rbind(all_cotas, group_cotas)
    cota_counter <- cota_counter + n_cotas_this_group
  }
  
  return(all_cotas)
}

#%% Generate all cotas with timing
base_cotas <- generate_cotas_with_timing(group_start_dates)
n_cotas <- nrow(base_cotas)

# Merge group end date information into base cotas
base_cotas <- merge(base_cotas, 
                    group_start_dates[, .(adm_cd2, gai_cd_grupo2, group_end_trimester)], 
                    by = c("adm_cd2", "gai_cd_grupo2"), 
                    all.x = TRUE)

# Add group-level duration to base_cotas
base_cotas[, FCT_QT_DUR_PLANO := {
  # 80% have exact group duration, 10% have -12 months, 10% have -24 months
  if(runif(1) < 0.8) {
    group_duration
  } else if(runif(1) < 0.5) {
    pmax(48, group_duration - 12)  # Minimum 48 months
  } else {
    pmax(48, group_duration - 24)  # Minimum 48 months
  }
}]

# Add remaining fixed characteristics to base_cotas
base_cotas[, c("FCT_VL_BEM",
               "FCT_VL_REN_FAT_MEN_COTISTA",
               "FCT_PC_LANCE",
               "FCT_PC_TX_ADM",
               "FCT_PC_TAX_ADM_ANTEC",
               "FCT_CD_TIP_COTISTA",
               "FCT_IB_CONTEMP") :=
{
  bem   <- round(runif(.N, 50000, 500000), 0)
  lance <- ifelse(runif(.N) < 0.4, 0, 100*round(runif(.N, 0.3, 0.6), 2))
  list(
    bem,
    runif(.N, 0.1, 0.2) * bem,
    lance,
    round(runif(.N, 0.1, 0.2), 2),
    0,
    sample(1:2, .N, replace = TRUE, prob = c(0.2, 0.8)),
    ifelse(lance == 0, "S", "L")
  )
}]

# Generate unique CPF-like identifiers (11 digits without replacement)
# Start with base cotas getting unique CPFs
base_cotas[, cpf2 := sample(10000000000:99999999999, .N, replace = FALSE)]

# Convert cota_join_trimester to proper adesao date (first day of trimester)
base_cotas[, FCT_DT_ADESAO := {
  year <- substr(cota_join_trimester, 1, 4)
  month <- substr(cota_join_trimester, 5, 6)
  # First day of the trimester month
  format(as.Date(paste0(year, "-", month, "-01")), "%d/%m/%Y")
}]

# Add contemplation date using our helper function
base_cotas[FCT_IB_CONTEMP != "", FCT_DT_CONTEMP := {
  # Use different alpha values for auction vs lottery
  alpha_values <- ifelse(FCT_IB_CONTEMP == "L", 0.5, 2.0)  # L → early, S → late
  generate_contemplation_date(cota_join_trimester, FCT_VL_BEM, alpha_values, FCT_QT_DUR_PLANO)
}]

cat("Generated", n_cotas, "cotas across", n_groups_total, "groups\n")

#%% Simulate cancellation chain and create new sequences
cat("Simulating cancellation chain and creating new sequences...\n")

# Phase 1: Determine which cotas get cancelled and how many sequences they'll have
base_cotas[, `:=`(
  # Cancellation probability based on value: 0.2 + 0.2 * (1 - FCT_VL_BEM / 500000)
  cancel_prob = 0.2 + 0.2 * (1 - FCT_VL_BEM / 500000),
  sequence_count = 1L
)]

# Simulate first cancellation and generate dates
base_cotas[, will_cancel := runif(.N) < cancel_prob]

# Initialize FCT_DT_CAN_COTA column for all base cotas (empty by default)
base_cotas[, FCT_DT_CAN_COTA := ""]

# Generate cancellation dates for base cotas that will cancel (random in first 6 trimesters)
base_cotas[will_cancel == TRUE, FCT_DT_CAN_COTA := {
  # Random trimester offset from join (1 to 6 trimesters)
  cancel_offset <- sample(1:6, .N, replace = TRUE)  # .N for vectorized operation
  cancel_trimester <- add_trimesters(cota_join_trimester, cancel_offset)
  year <- substr(cancel_trimester, 1, 4)
  month <- substr(cancel_trimester, 5, 6)
  format(as.Date(paste0(year, "-", month, "-01")), "%d/%m/%Y")
}]

# Override cancellation if contemplation happens before cancellation for base cotas
base_cotas[will_cancel == TRUE & FCT_DT_CONTEMP != "" & FCT_DT_CAN_COTA != "", `:=`(
  contemp_date = as.Date(FCT_DT_CONTEMP, format = "%d/%m/%Y"),
  cancel_date = as.Date(FCT_DT_CAN_COTA, format = "%d/%m/%Y")
)]

# Remove cancellation if contemplation happens before cancellation
base_cotas[will_cancel == TRUE & !is.na(contemp_date) & !is.na(cancel_date) & contemp_date < cancel_date, `:=`(
  FCT_DT_CAN_COTA = "",
  will_cancel = FALSE  # Update the flag
)]

# Clean up temporary columns
base_cotas[, `:=`(contemp_date = NULL, cancel_date = NULL)]

# For cancelled cotas, determine timing for potential second sequence
base_cotas[will_cancel == TRUE, `:=`(
  second_timing = ifelse(runif(.N) < 0.75, 1, 2),  # 75% next semester, 25% two later
  third_timing = ifelse(runif(.N) < 0.75, 1, 2)    # Timing for potential third sequence
)]

# Sequence count will be determined dynamically as we create sequences

# Phase 2: Create new sequences for cancelled cotas
new_sequences <- data.table()

for(i in 1:nrow(base_cotas)) {
  cota_info <- base_cotas[i]
  
  if(cota_info$will_cancel) {
    # Decide if this cancelled cota gets a second sequence (40% chance)
    gets_second <- runif(1) < 0.75
    
    if(gets_second) {
      # Calculate timing offset (in trimesters)
      timing_offset <- cota_info$second_timing
      
      # Calculate new join trimester
      new_join_trimester <- add_trimesters(cota_info$cota_join_trimester, timing_offset)
      
      # Calculate months lost from group start to new sequence start
      group_start_seq <- trimester_to_sequence(cota_info$group_start_trimester)
      new_join_seq <- trimester_to_sequence(new_join_trimester)
      months_lost <- (new_join_seq - group_start_seq) * 3
      
      # New duration = group duration - months lost
      new_duration <- pmax(48, cota_info$group_duration - months_lost)
      
             # Create second sequence with independent characteristics
       bem_value <- round(runif(1, 50000, 500000), 0)
       second_seq <- data.table(
         COT_CD_COTA = cota_info$COT_CD_COTA,
         COT_CD_SEQ_COTA = 1L,
         adm_cd2 = cota_info$adm_cd2,
         gai_cd_grupo2 = cota_info$gai_cd_grupo2,
         group_start_trimester = cota_info$group_start_trimester,
         group_end_trimester = cota_info$group_end_trimester,
         cota_join_trimester = new_join_trimester,
         cota_join_offset = timing_offset,
         FCT_CD_SEG = cota_info$FCT_CD_SEG,
         group_duration = cota_info$group_duration,
         FCT_QT_DUR_PLANO = new_duration,
         # Independent random draws for new sequence
         FCT_VL_BEM = bem_value,
         FCT_VL_REN_FAT_MEN_COTISTA = runif(1, 0.1, 0.2) * bem_value,
         FCT_PC_LANCE = ifelse(runif(1) < 0.4, 0, round(runif(1, 0.01, 50), 2)),
         FCT_PC_TX_ADM = round(runif(1, 0.1, 0.2), 2),
         FCT_PC_TAX_ADM_ANTEC = 0,
         FCT_CD_TIP_COTISTA = sample(1:2, 1, replace = TRUE, prob = c(0.2, 0.8)),
         FCT_IB_CONTEMP = ifelse(runif(1) < 0.4, "L", "S"),  # Allow both auction and lottery
         sequence_count = 2L,
          cpf2 = sample(10000000000:99999999999, 1)  # New unique CPF for second sequence
       )
       
       # Generate contemplation date for second sequence
       alpha_second <- ifelse(second_seq$FCT_IB_CONTEMP == "L", 0.5, 2.0)
       second_seq[, FCT_DT_CONTEMP := generate_contemplation_date(new_join_trimester, bem_value, alpha_second, new_duration)]
       
       # Always create FCT_DT_CAN_COTA column (empty by default)
       second_seq[, FCT_DT_CAN_COTA := ""]
       
       # Now decide if the second sequence cancels (using its own FCT_VL_BEM)
       second_cancel_prob <- 0.2 + 0.2 * (1 - bem_value / 500000)
       second_will_cancel <- runif(1) < second_cancel_prob
       
       # Generate cancellation date for second sequence if it cancels (random in first 6 trimesters)
       if(second_will_cancel) {
         cancel_offset <- sample(1:6, 1)
         cancel_trimester <- add_trimesters(new_join_trimester, cancel_offset)
         year <- substr(cancel_trimester, 1, 4)
         month <- substr(cancel_trimester, 5, 6)
         second_seq[, FCT_DT_CAN_COTA := format(as.Date(paste0(year, "-", month, "-01")), "%d/%m/%Y")]
         
         # Override cancellation if contemplation happens before cancellation
         contemp_date <- as.Date(second_seq$FCT_DT_CONTEMP, format = "%d/%m/%Y")
         cancel_date <- as.Date(second_seq$FCT_DT_CAN_COTA, format = "%d/%m/%Y")
         if(contemp_date < cancel_date) {
           second_seq[, FCT_DT_CAN_COTA := ""]  # Remove cancellation
           second_will_cancel <- FALSE  # Update the flag
         }
       }
       new_sequences <- rbind(new_sequences, second_seq)
      
      # Create third sequence if the second sequence cancels
      if(second_will_cancel) {
        # Decide if this second cancelled sequence gets a third sequence (40% chance)
        gets_third <- runif(1) < 0.75
        
        if(gets_third) {
          # Calculate timing offset for third sequence (from second sequence's join)
          third_timing_offset <- cota_info$third_timing
        
        # Calculate new join trimester for third sequence (from second sequence's join)
        third_join_trimester <- add_trimesters(new_join_trimester, third_timing_offset)
        
        # Calculate months lost for third sequence
        third_join_seq <- trimester_to_sequence(third_join_trimester)
        third_months_lost <- (third_join_seq - group_start_seq) * 3
        
        # New duration for third sequence
        third_duration <- pmax(48, cota_info$group_duration - third_months_lost)
        
                 # Create third sequence
         third_bem_value <- round(runif(1, 50000, 500000), 0)
         third_seq <- data.table(
           COT_CD_COTA = cota_info$COT_CD_COTA,
           COT_CD_SEQ_COTA = 2L,
           adm_cd2 = cota_info$adm_cd2,
           gai_cd_grupo2 = cota_info$gai_cd_grupo2,
           group_start_trimester = cota_info$group_start_trimester,
           group_end_trimester = cota_info$group_end_trimester,
           cota_join_trimester = third_join_trimester,
           cota_join_offset = third_timing_offset,
           FCT_CD_SEG = cota_info$FCT_CD_SEG,
           group_duration = cota_info$group_duration,
           FCT_QT_DUR_PLANO = third_duration,
           # Independent random draws for third sequence
           FCT_VL_BEM = third_bem_value,
           FCT_VL_REN_FAT_MEN_COTISTA = runif(1, 0.1, 0.2) * third_bem_value,
           FCT_PC_LANCE = ifelse(runif(1) < 0.4, 0, round(runif(1, 0.01, 50), 2)),
           FCT_PC_TX_ADM = round(runif(1, 0.1, 0.2), 2),
           FCT_PC_TAX_ADM_ANTEC = 0,
           FCT_CD_TIP_COTISTA = sample(1:2, 1, replace = TRUE, prob = c(0.2, 0.8)),
           FCT_IB_CONTEMP = ifelse(runif(1) < 0.4, "L", "S"),  # Allow both auction and lottery
           sequence_count = 3L,
            cpf2 = ifelse(runif(1) < 0.5, 
                                cota_info$cpf2,  # 50% chance: reuse original CPF
                                sample(10000000000:99999999999, 1))  # 50% chance: new unique CPF
         )
         
         # Generate contemplation date for third sequence
         alpha_third <- ifelse(third_seq$FCT_IB_CONTEMP == "L", 0.5, 2.0)
         third_seq[, FCT_DT_CONTEMP := generate_contemplation_date(third_join_trimester, third_bem_value, alpha_third, third_duration)]
         
         # Always create FCT_DT_CAN_COTA column (empty by default)
         third_seq[, FCT_DT_CAN_COTA := ""]
         
         # Third sequence also has a chance to cancel (but no fourth sequence)
         third_cancel_prob <- 0.2 + 0.2 * (1 - third_bem_value / 500000)
         third_will_cancel <- runif(1) < third_cancel_prob
         
         # Generate cancellation date for third sequence if it cancels (random in first 6 trimesters)
         if(third_will_cancel) {
           cancel_offset <- sample(1:6, 1)
           cancel_trimester <- add_trimesters(third_join_trimester, cancel_offset)
           year <- substr(cancel_trimester, 1, 4)
           month <- substr(cancel_trimester, 5, 6)
           third_seq[, FCT_DT_CAN_COTA := format(as.Date(paste0(year, "-", month, "-01")), "%d/%m/%Y")]
           
           # Override cancellation if contemplation happens before cancellation
           contemp_date <- as.Date(third_seq$FCT_DT_CONTEMP, format = "%d/%m/%Y")
           cancel_date <- as.Date(third_seq$FCT_DT_CAN_COTA, format = "%d/%m/%Y")
           if(contemp_date < cancel_date) {
             third_seq[, FCT_DT_CAN_COTA := ""]  # Remove cancellation
             third_will_cancel <- FALSE  # Update the flag
           }
         }
         new_sequences <- rbind(new_sequences, third_seq)
        }
      }
    }
  }
}

# Phase 3: Combine original cotas with new sequences
# Set sequence number for original cotas
base_cotas[, COT_CD_SEQ_COTA := 0L]

# Combine all cotas
all_cotas <- rbindlist(list(base_cotas, new_sequences), fill = TRUE)

# Add missing variables at the cota level (before panel expansion)
all_cotas[, `:=`(
  # State code: randomly 41 or 42
  fct_cd_uf_cota = sample(c("41", "42"), .N, replace = TRUE),
  
  # Cancellation fees (only for cancelled cotas)
  FCT_PC_MUL_RES_GRUPO = ifelse(sequence_count > 1, 
                                 round(FCT_VL_BEM * cancellation_fee * share_group, 2), 0),  # 5% cancellation fee, 70% to group
  FCT_PC_MUL_RES_ADM = ifelse(sequence_count > 1, 
                               round(FCT_VL_BEM * cancellation_fee * share_admin, 2), 0)     # 5% cancellation fee, 30% to admin
)]

# Checking
if(table(all_cotas$FCT_DT_CONTEMP < all_cotas$FCT_DT_CAN_COTA, all_cotas$FCT_DT_CAN_COTA == "")

# Update total count
n_cotas <- nrow(all_cotas)

cat("Created", nrow(new_sequences), "new sequences\n")
cat("Total cotas after sequences:", n_cotas, "\n")
cat("Sequence distribution:\n")
print(all_cotas[, .N, by = sequence_count])

# Clean up temporary variables
all_cotas[, `:=`(
  cancel_prob = NULL,
  will_cancel = NULL,
  gets_second = NULL,
  second_timing = NULL,
  gets_third = NULL,
  third_timing = NULL
)]

# Add adesao dates for all cotas (including new sequences)
all_cotas[, FCT_DT_ADESAO := {
  year <- substr(cota_join_trimester, 1, 4)
  month <- substr(cota_join_trimester, 5, 6)
  # First day of the trimester month
  format(as.Date(paste0(year, "-", month, "-01")), "%d/%m/%Y")
}]

#%% Expand to panel structure
print("Expanding to panel structure...")

bc <- as.data.table(all_cotas)[
  , `:=`(
      join_seq = trimester_to_sequence(cota_join_trimester),
      end_seq  = pmin(trimester_to_sequence(latest_date), trimester_to_sequence(cota_join_trimester) + ceiling(FCT_QT_DUR_PLANO/3) - 1L)
)]
bc[, `:=`(n = pmax(0L, end_seq - join_seq + 1L))]
bc <- bc[n > 0]

# Create index per cota, expand by repeating rows n times, then build the per-row trimester sequence
bc[, id := .I]
idx <- rep.int(bc$id, times = bc$n)        # integer, no NA, length > 0
panel <- bc[idx][, id := NULL]
panel[, T := sequence(.N) - 1L, by = COT_CD_COTA]
panel[, trimester_seq := join_seq + T]
panel[, trimester := sequence_to_trimester(trimester_seq)]
panel[, trimester_start := as.Date(paste0(substr(trimester,1,4), "-", substr(trimester,5,6), "-01"))]

#%% Filling up the panel with realistic payment features
# Calculate months since join for each observation
panel[, months_since_join := (T * 3)]  # T is trimester number, so *3 for months

# Calculate base monthly payment components
panel[, `:=`(
  # Base monthly payment = (Value + Admin Fee) / Duration
  base_monthly_payment = (FCT_VL_BEM * (1 + FCT_PC_TX_ADM)) / FCT_QT_DUR_PLANO,
  
  # Monthly components
  monthly_fund_common = FCT_VL_BEM / FCT_QT_DUR_PLANO,
  monthly_admin_fee = (FCT_PC_TX_ADM * FCT_VL_BEM) / FCT_QT_DUR_PLANO,
  monthly_reserve = 0.005 * FCT_VL_BEM / FCT_QT_DUR_PLANO
)]

# Apply semestral inflation adjustment (every 2 trimesters = 6 months)
panel[, semester := ceiling(T / 2)]
panel[, inflation_factor := (1 + inflation_rate_semestre) ^ semester]

# Adjust payments for inflation
panel[, `:=`(
  adjusted_monthly_payment = base_monthly_payment * inflation_factor,
  adjusted_fund_common = monthly_fund_common * inflation_factor,
  adjusted_admin_fee = monthly_admin_fee * inflation_factor,
  adjusted_reserve = monthly_reserve * inflation_factor
)]

# Calculate accumulated values (monthly component * months since join)
panel[, `:=`(
  FCT_PC_AMO_MENSAL = round(adjusted_monthly_payment, 2),
  FCT_PC_ACU_AMORT = pmin(100, round((months_since_join / FCT_QT_DUR_PLANO) * 100, 2)),
  FCT_VL_CON_ACU_FUN_COMUM = round(adjusted_fund_common * months_since_join, 2),
  FCT_VL_CON_ACU_FUN_RESERVA = round(adjusted_reserve * months_since_join, 2),
  FCT_VL_CON_ACU_TX_ADM = round(adjusted_admin_fee * months_since_join, 2),
  FCT_VL_CON_ACU_JUR_MULTAS = ifelse(runif(.N) < 0.5, 0, 
                                     round(0.01 * FCT_VL_BEM / FCT_QT_DUR_PLANO * months_since_join, 2)),
  FCT_PC_ATRASO = 0
)]



# Calculate contemplated credit value with inflation adjustment and cancellation fee deduction
panel[, FCT_VL_CRE_DAT_CONTEMP := fifelse(FCT_IB_CONTEMP != "", {
  base_credit <- round(FCT_VL_BEM * inflation_factor, 2)
  
  # For cancelled cotas, deduct cancellation fees
  fifelse(sequence_count > 1, 
          base_credit - FCT_PC_MUL_RES_GRUPO - FCT_PC_MUL_RES_ADM,
          base_credit)
}, 0)]

#%% Panel structure
print("Adding sequence number and DAC_DT_BASE...")

# Add DAC_DT_BASE column for compatibility
panel[, DAC_DT_BASE := trimester]

# Add status variable: 1 before cancellation, 2 after cancellation
panel[, FCT_ST_ATUAL := ifelse(sequence_count > 1, 2, 1)]

# Clean up temporary variables (but keep sequence_count for now)
panel[, `:=`(
  months_since_join = NULL,
  base_monthly_payment = NULL,
  monthly_fund_common = NULL,
  monthly_admin_fee = NULL,
  monthly_reserve = NULL,
  semester = NULL,
  inflation_factor = NULL,
  adjusted_monthly_payment = NULL,
  adjusted_fund_common = NULL,
  adjusted_admin_fee = NULL,
  adjusted_reserve = NULL,
  trimester_start = NULL,
  trimester_seq = NULL,
  T = NULL,
  join_seq = NULL,
  end_seq = NULL,
  n = NULL,
  group_start_trimester = NULL,
  cota_join_trimester = NULL,
  cota_join_offset = NULL
)]

# Rename panel to mock_data for consistency
mock_data <- panel

#%%

# Update status logic: 1 before cancellation, 2 after cancellation
mock_data[, FCT_ST_ATUAL := fifelse(FCT_DT_CAN_COTA != "", {
  # Check if current date_base is before or after cancellation
  current_date <- as.Date(paste0(DAC_DT_BASE, "01"), format = "%Y%m%d")
  cancel_date <- as.Date(FCT_DT_CAN_COTA, format = "%d/%m/%Y")
  
  fifelse(current_date <= cancel_date, 1, 2)
}, 1)]  # Never cancelled

# Override cancellations if contemplation happens before cancellation
mock_data[FCT_DT_CAN_COTA != "" & FCT_DT_CONTEMP != "", `:=`(
  contemp_date = as.Date(FCT_DT_CONTEMP, format = "%d/%m/%Y"),
  cancel_date = as.Date(FCT_DT_CAN_COTA, format = "%d/%m/%Y")
)]

# Remove cancellation if contemplation happens before cancellation
mock_data[FCT_DT_CAN_COTA != "" & FCT_DT_CONTEMP != "" & contemp_date < cancel_date, 
          FCT_DT_CAN_COTA := ""]

# Clean up temporary columns
mock_data[, `:=`(contemp_date = NULL, cancel_date = NULL)]

# Recalculate status after cancellation overrides
mock_data[, FCT_ST_ATUAL := fifelse(FCT_DT_CAN_COTA != "", {
  # Check if current date_base is before or after cancellation
  current_date <- as.Date(paste0(DAC_DT_BASE, "01"), format = "%Y%m%d")
  cancel_date <- as.Date(FCT_DT_CAN_COTA, format = "%d/%m/%Y")
  
  fifelse(current_date <= cancel_date, 1, 2)
}, 1)]  # Never cancelled

# Adjust contemplation dates for cancelled cotas to be in final two trimesters of their group
mock_data[FCT_DT_CAN_COTA != "", `:=`(
  # Convert group end trimester to date
  group_end_date = as.Date(paste0(group_end_trimester, "01"), format = "%Y%m%d"),
  # Calculate final two trimesters (6 months before end)
  final_period_start = as.Date(paste0(group_end_trimester, "01"), format = "%Y%m%d") - months(6)
)]

# For cancelled cotas, set contemplation date to a random date in the final two trimesters
mock_data[FCT_DT_CAN_COTA != "", FCT_DT_CONTEMP := {
  # Random date between final_period_start and group_end_date
  random_days <- sample(0:180, 1)  # 0 to 180 days
  final_contemp_date <- final_period_start + days(random_days)
  format(final_contemp_date, "%d/%m/%Y")
}]

# Clean up temporary columns
mock_data[, `:=`(group_end_date = NULL, final_period_start = NULL)]

# Now clean up sequence_count since we're done with it
mock_data[, sequence_count := NULL]

#%% Export mock data in multiple formats ------------------------------
print("Exporting mock data in multiple formats...")

# Save as .csv
fwrite(mock_data, "mock_data/mock_FCT_data.csv", sep = ",", na = "")

# Save as .rds (R native format - much faster to load)
saveRDS(mock_data, "mock_data/mock_FCT_data.rds")

# Create summary statistics ----------------------
cat("\n=== Mock Data Generation Summary ===\n")
cat("Total observations:", nrow(mock_data), "\n")
cat("Total columns:", ncol(mock_data), "\n")
cat("File size:", round(file.size("mock_data/mock_FCT_data.rds") / 1024^2, 2), "MB\n")
cat("File location: mock_data/mock_FCT_data.rds\n")

# Data quality checks
cat("\n=== Data Quality Checks ===\n")
cat("Unique adm_ids:", mock_data[, uniqueN(adm_cd2)], "\n")
cat("Unique grupo_ids:", mock_data[, uniqueN(gai_cd_grupo2)], "\n")
cat("Unique cota_ids:", mock_data[, uniqueN(COT_CD_COTA)], "\n")
cat("Total cota-sequence combinations:", mock_data[, uniqueN(paste(COT_CD_COTA, COT_CD_SEQ_COTA))], "\n")
cat("Active records (status 1):", mock_data[FCT_ST_ATUAL == 1, .N], "\n")
cat("Cancelled records (status 2):", mock_data[FCT_ST_ATUAL == 2, .N], "\n")

# Check date_adesao vs date_base relationship
cat("\n=== Date Relationship Checks ===\n")
mock_data[, `:=`(
  date_adesao_calc = as.Date(FCT_DT_ADESAO, format = "%d/%m/%Y"),
  date_base_calc = as.Date(paste0(DAC_DT_BASE, "01"), format = "%Y%m%d")
)]

adesao_before_base_pct <- round(100 * mock_data[, mean(date_adesao_calc <= date_base_calc)], 1)
cat("Records where date_adesao <= date_base:", adesao_before_base_pct, "%\n")

# Check first appearances
first_appearances <- mock_data[, .(
  first_date_base = min(date_base_calc),
  date_adesao = first(date_adesao_calc)
), by = .(COT_CD_COTA, COT_CD_SEQ_COTA)]

immediate_entry_pct <- round(100 * first_appearances[, mean(date_adesao == first_date_base)], 1)
cat("Cotas entering immediately (date_adesao = first_date_base):", immediate_entry_pct, "%\n")

# Panel structure
cat("\n=== Panel Structure ===\n")
obs_per_cota <- mock_data[, .N, by = .(COT_CD_COTA, COT_CD_SEQ_COTA)]
cat("Avg observations per cota-sequence:", round(mean(obs_per_cota$N), 1), "\n")
cat("Min observations per cota-sequence:", min(obs_per_cota$N), "\n")
cat("Max observations per cota-sequence:", max(obs_per_cota$N), "\n")

# Clean up temporary variables
mock_data[, `:=`(date_adesao_calc = NULL, date_base_calc = NULL)]

# Show sample of data
cat("\n=== Sample Data (first 5 rows) ===\n")
print(mock_data[1:5, .(DAC_DT_BASE, FCT_DT_ADESAO, adm_cd2, gai_cd_grupo2, COT_CD_COTA, 
                       COT_CD_SEQ_COTA, FCT_QT_DUR_PLANO, FCT_ST_ATUAL)])

cat("\n=== Structure Verification ===\n")
cat("Expected structure: Each admin has", n_groups_per_admin, "groups, each group has", n_cotas_per_group, "cotas\n")
cat("Cotas per group verification:\n")
cotas_per_group_check <- mock_data[, uniqueN(COT_CD_COTA), by = .(adm_cd2, gai_cd_grupo2)]
cat("Min cotas per group:", min(cotas_per_group_check$V1), "\n")
cat("Max cotas per group:", max(cotas_per_group_check$V1), "\n")

cat("\n=== Mock data generation completed successfully! ===\n")