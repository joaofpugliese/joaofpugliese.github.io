
# ---------------------------------------------- # 
#       Data cleaning - Financial Outcomes 
# ---------------------------------------------- # 

#%% Packages ---------------------------------------
library(data.table)
library(dplyr)
library(ggplot2)
library(lubridate)
library(zoo)  # For rollapply function
library(here)
# We're already in the correct working directory

#%% Interest rate data -----------------------------

# Detect seriessgs data
if (file.exists("D:/bases/seriessgs.csv")) {
  filename2 <- file.path(data_path, "seriessgs.csv")
  juros_raw <- read.csv("D:/bases/seriessgs.csv", sep = ";", header = FALSE)

  colnames(juros_raw) <- as.character(juros_raw[1,])
  juros_raw <- juros_raw[-1,]

  juros <- juros_raw %>% 
    slice(-n()) %>% 
    rename(
      selic = !!names(.)[2],
      cdi = !!names(.)[3]
    ) %>% 
    mutate(
      year = substr(Data, 4, 7) %>% as.numeric(),
      month = substr(Data, 1, 2) %>% as.numeric(),
      temp_date = make_date(year, month, 1),
      date_base = temp_date %m+% months(1) - days(1),
      selic = as.numeric(gsub(",", ".", selic)),
      cdi = as.numeric(gsub(",", ".", cdi))
    ) %>% 
    mutate(
      ipca = ipca/100,
      selic = selic/100,
      ipca_3m = rollapply(1 + ipca, width = 3, FUN = prod, align = "right", fill = NA) - 1,
      ipca_12m = rollapply(1 + ipca, width = 12, FUN = prod, align = "right", fill = NA) - 1
    ) %>% 
    select(year, month, date_base, selic, cdi)
} else {
  juros <- read.csv("../../../../output/centralbank/interest and inflation time series.csv") %>% select(ref.date, ipca, selic)

  juros <- juros %>%
  arrange(ref.date) %>%
  mutate(
    ipca = ipca/100,
    selic = selic/100,
    ipca_3m = rollapply(1 + ipca, width = 3, FUN = prod, align = "right", fill = NA) - 1,
    ipca_12m = rollapply(1 + ipca, width = 12, FUN = prod, align = "right", fill = NA) - 1,
    selic_3m = rollapply(1 + selic, width = 3, FUN = prod, align = "right", fill = NA) - 1,
    selic_12m = rollapply(1 + selic, width = 12, FUN = prod, align = "right", fill = NA) - 1,
    date_base = as.Date(ref.date)  # Standardize column name
  ) %>%
  select(date_base, selic, ipca, ipca_3m, ipca_12m, selic_3m, selic_12m)
}
#%% Consórcios data -------------------------------

# Importing clean dataset (general)
#df <- readRDS("D:/_main/data/treated_data/FCT_general_clean.rds")
df <- readRDS("mock_data/FCT_general_datatable_clean.rds")

# Remove groups with only 1 observation
df <- df[, if(.N > 1) .SD, by = .(adm_id, grupo_id, cota_full_id, cpf_fake_id)]

# Keep only variables needed for financial outcomes analysis
df <- df[, .(
  # Identifiers
  adm_id, grupo_id, cota_id, cota_full_id, cpf_fake_id,
  # Dates and time variables  
  date_base, date_adesao, date_contemp, year, quarter,
  year_adesao, quarter_adesao, year_min, quarter_min, data_frequency,
  # Payment and cash flow variables
  fundo_comum_acumul, fundo_reserva_acumul, tx_adm_acumul, juros_multas_acumul,
  credit_contemp, contemp_in_quarter, adesao_min_flag,
  # Analysis variables
  renda_cotista, lottery, auction, sit_atual
)]

# Merge interest rates
setDT(juros)
df <- juros[df, on = "date_base", roll = "nearest"]

#%% Create cash flows ------------------------------

# Convert to data.table if not already
if (!is.data.table(df)) setDT(df)

# Create cash flow variables using data.table
df[, `:=`(
  # Positive cash flow (credit from contemplation)
  cash_positive = fifelse(is.na(contemp_in_quarter * credit_contemp), 0, contemp_in_quarter * credit_contemp),
  
  # Total cumulative payments
  cumul_payments = fundo_comum_acumul + fundo_reserva_acumul + tx_adm_acumul + juros_multas_acumul
)]

# Calculate payment variations by group (using data.table grouping)
# This computes period-to-period cash outflows by taking the difference between 
# current and previous cumulative payments for each cota sequence
df[, variation_payments := cumul_payments - shift(cumul_payments, fill = 0), 
   by = .(adm_id, grupo_id, cota_full_id, cpf_fake_id)]

# Create cash_negative using the calculated variation_payments
df[, cash_negative := fifelse(is.na(shift(cumul_payments)), cumul_payments, variation_payments),
   by = .(adm_id, grupo_id, cota_full_id, cpf_fake_id)]

# Create net cash flow
df[, cash_net := cash_positive - cash_negative]

# Adjusting cash flows for adesao timing
# ATTENTION!

# Calculate gap between adesao and first appearance
df[, `:=`(
  gap_adesao_quarters = (year_min - year_adesao) * 4 + (quarter_min - quarter_adesao),
  gap_adesao_months = ((year_min - year_adesao) * 4 + (quarter_min - quarter_adesao)) * 3
)]

# Expand panel to include gap dates


#%% Computing NPV ----------------------------------

# Pre-merge discount rates to main dataset (do this once, not per group)
setDT(juros)
df <- juros[df, on = "date_base", roll = "nearest"]

# Pure NPV function (modular, no data manipulation)
npv_calculate <- function(cash_flows, discount_rates, periods = NULL) {
  if(is.null(periods)) periods <- seq_len(length(cash_flows))
  pv <- cash_flows / ((1 + discount_rates) ^ periods)
  return(sum(pv, na.rm = TRUE))
}

# Data handling wrapper function (operates on panel data for each cota)
compute_group_npv <- function(dt_subset, gap_periods = 0) {
  # Extract vectors once for efficiency
  cash_flows <- dt_subset[["cash_net"]]
  data_freq <- dt_subset[["data_frequency"]][1]
  selic_monthly <- dt_subset[["selic"]]
  selic_3m <- dt_subset[["selic_3m"]]
  
  # Select appropriate discount rate vector
  discount_rates <- if(data_freq == "monthly") selic_monthly else selic_3m
  
  # Handle gaps in periods
  periods <- seq_len(length(cash_flows))
  if(gap_periods > 0 && !is.na(gap_periods)) {
    period_adjust <- ifelse(data_freq == "monthly", gap_periods, gap_periods * 3)
    periods <- periods + period_adjust
  }
  
  # Call pure NPV function (one NPV per cota across all time periods)
  return(npv_calculate(cash_flows, discount_rates, periods))
}

# Apply NPV calculation by group using modular functions
df[, npv := compute_group_npv(.SD, gap_adesao_months[1]), 
   by = .(adm_id, grupo_id, cota_full_id, cpf_fake_id)]

#%% Keep only active quotas
df <- df %>% 
  filter(sit_atual == 1)

#%% Create analysis-ready variables -----------------
# Normalized NPV for analysis
df <- df %>% 
  mutate(
    n_npv = npv / credit_contemp,
    renda_cotista_log = log(renda_cotista)
  )

# Exporting to .rds and .csv ------------------------------

saveRDS(df, "D:/_main/data/treated_data/FCT_financial_outcomes_clean.rds")
write.csv(df, "D:/_main/data/treated_data/FCT_financial_outcomes_clean.csv", row.names = FALSE)

