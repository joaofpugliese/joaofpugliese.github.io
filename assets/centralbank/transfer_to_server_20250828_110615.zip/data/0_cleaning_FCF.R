# ---------------------------------------------- # 
#          Data cleaning - General (Optimized for 4M+ observations)
# ---------------------------------------------- #
#
# Performance optimizations implemented:
# - data.table for faster operations (vs dplyr)
# - fread() for faster file import (vs read.delim)
# - Combined operations with := for modify-by-reference
# - Efficient date parsing and calculations
# - fcase() and fifelse() for faster conditionals
# - Early memory cleanup and garbage collection
# - fwrite() for faster CSV export
#
# Additional tips for very large datasets:
# - Consider reading in chunks if memory is limited
# - Use setkey() for indexed operations if doing joins/merges
# - Monitor memory usage with gc() and object.size()
# ---------------------------------------------- #

# Packages ---------------------------------------

library(data.table)
library(dplyr)
library(lubridate)
library(here)
# library(dplyr)  # Removed for data.table optimization
# library(ggplot2)  # Not used in cleaning script

if (getwd() != paste0(here(), "/data/code/centralbank/server/data")) {
  setwd(paste0(here(), "/data/code/centralbank/server/data"))
}

# Use fread for faster file reading with large datasets
df <- fread("D:/bases/exemplo_5_7agosto_rev.txt", header = FALSE, 
                stringsAsFactors = FALSE, showProgress = TRUE)

# Set column names and remove header row
setnames(df, as.character(df[1,]))
df <- df[-1,]

# Data cleaning ----------------------------------

# Convert to data.table for faster operations
setDT(df)

# Combined operations using data.table's modify-by-reference for efficiency
df[, `:=`(
  # Date extraction
  year = as.numeric(substr(DAC_DT_BASE, 1, 4)),
  month = as.numeric(substr(DAC_DT_BASE, 5, 6)),
  
  # Token processing - more efficient factor conversion
  codigo_seg = FCT_CD_SEG,
  adm_id = as.integer(as.factor(adm_cd2)),
  grupo_id = as.integer(as.factor(gai_cd_grupo2)),
  cota_id = COT_CD_COTA,
  cota_sub_id = COT_CD_SEQ_COTA,
  cpf_fake_id = cpf2
)]

# Create composite ID after other columns exist
df[, cota_full_id := paste(cota_id, cota_sub_id, sep = "-")]

# Treat dates - optimized for large datasets
df[, `:=`(
  # Fast date conversion using data.table
  date_cancel = as.Date(FCT_DT_CAN_COTA, format = "%d/%m/%Y"),
  date_contemp = as.Date(FCT_DT_CONTEMP, format = "%d/%m/%Y"),
  date_adesao = as.Date(FCT_DT_ADESAO, format = "%d/%m/%Y"),
  
  # Efficient date_base calculation
  date_base = as.Date(paste0(year, "-", month, "-01")) + months(1) - days(1)
)]

# Add quarter after date_base is created
df[, quarter := quarter(date_base)]

# Clean up intermediate and original raw columns efficiently
cols_to_remove <- c("FCT_DT_CAN_COTA", "FCT_DT_CONTEMP", 
                    "FCT_DT_ADESAO", "DAC_DT_BASE", 
                    "COT_CD_COTA", "COT_CD_SEQ_COTA")
df[, (cols_to_remove) := NULL]
gc()

# Create string date versions (used in multiple analyses)
df[, `:=`(
  #date_cancel_str = fifelse(is.na(date_cancel), NA_character_, 
  #                         tolower(format(date_cancel, "%d%b%Y"))),
  #date_contemp_str = fifelse(is.na(date_contemp), NA_character_, 
  #                          tolower(format(date_contemp, "%d%b%Y"))),
  #date_adesao_str = fifelse(is.na(date_adesao), NA_character_, 
  #                         tolower(format(date_adesao, "%d%b%Y"))),
  #date_base_str = tolower(format(date_base, "%d%b%Y")),
  
  # Year variables (commonly referenced)
  year_adesao = year(date_adesao),
  
  # Basic quarter variables
  quarter_adesao = quarter(date_adesao),
  quarter_contemp = quarter(date_contemp),
  year_contemp = year(date_contemp)
)]


# Converting to numerical values - vectorized approach for efficiency
# Define column mappings (old_name = new_name)
numeric_cols <- c("FCT_PC_LANCE" = "pct_lance", "FCT_PC_TX_ADM" = "tx_adm", 
                  "FCT_PC_TAX_ADM_ANTEC" = "tx_adm_antecip", "FCT_PC_AMO_MENSAL" = "pct_amort_mensal",
                  "FCT_VL_BEM" = "valor_bem", "FCT_PC_ACU_AMORT" = "pct_amort_acumul",
                  "FCT_VL_CON_ACU_FUN_COMUM" = "fundo_comum_acumul", "FCT_VL_CON_ACU_FUN_RESERVA" = "fundo_reserva_acumul",
                  "FCT_VL_CON_ACU_TX_ADM" = "tx_adm_acumul", "FCT_VL_CON_ACU_JUR_MULTAS" = "juros_multas_acumul",
                  "FCT_VL_CRE_DAT_CONTEMP" = "credit_contemp", "FCT_PC_ATRASO" = "pct_atraso",
                  "FCT_VL_REN_FAT_MEN_COTISTA" = "renda_cotista")

integer_cols <- c("FCT_QT_DUR_PLANO" = "prazo")

# Convert all numeric columns at once
df[, (numeric_cols) := lapply(.SD, as.numeric), .SDcols = names(numeric_cols)]
df[, (integer_cols) := lapply(.SD, as.integer), .SDcols = names(integer_cols)]

# Clean up original numeric columns efficiently using defined vectors
df[, (c(names(numeric_cols), names(integer_cols))) := NULL]
gc()

# Categorical variables - efficient assignment
df[, `:=`(
  # Identifying individuals (=1), firms (=0) or non-identified
  pessoa_fisica = fcase(
    FCT_CD_TIP_COTISTA == 2, 1,
    FCT_CD_TIP_COTISTA == 1, 0,
    FCT_CD_TIP_COTISTA == 3, NA_real_,
    default = NA_real_
  ),
  
  # Auction and lottery mechanisms
  auction = fifelse(FCT_IB_CONTEMP == "L", 1, 0),
  lottery = fifelse(FCT_IB_CONTEMP == "S", 1, 0),
  allocation_type = as.factor(FCT_IB_CONTEMP),
  
  # Quota status
  sit_atual = FCT_ST_ATUAL
)]

# Clean up original categorical columns efficiently
categorical_cols_to_remove <- c("FCT_CD_TIP_COTISTA", "FCT_IB_CONTEMP", "FCT_ST_ATUAL")
df[, (categorical_cols_to_remove) := NULL]
gc()

# Create time relationship variables (used across quality + financial analysis)
df[, `:=`(
  earliest_date = min(date_base, na.rm = TRUE),
  quarter_min = quarter(min(date_base, na.rm = TRUE)),
  year_min = year(min(date_base, na.rm = TRUE))
), by = .(grupo_id, adm_id, cota_full_id, date_adesao)]

# Create adesao timing flag (used in financial analysis)
df[, adesao_min_flag := fifelse(
  (quarter_adesao == quarter_min) & (year_adesao == year_min), 
  1, 0
)]

# Create basic flags (used in multiple contexts)
df[, contemp_in_quarter := fifelse(
  !is.na(quarter_contemp) & !is.na(year_contemp) & 
  (quarter_contemp == quarter) & (year_contemp == year), 
  1, 0
)]

# Detecting monthly or trimester date by difference between two consecutive date_base
df[, data_frequency := fifelse(
  (date_base - lag(date_base)) <= 31, "monthly", "trimester"
), by = .(cota_full_id, grupo_id, adm_id, codigo_seg)]

# Fill missing frequency values (first observation in each group)
df[, data_frequency := fifelse(is.na(data_frequency), 
                               shift(data_frequency, type = "lead"), 
                               data_frequency), 
   by = .(cota_full_id, grupo_id, adm_id, codigo_seg)]

#%% Create binning variables for relative comparisons of values (EFFICIENT VERSION)
# Key insight: Only calculate quintiles for periods when people actually join

# Step 1: Identify first periods and capture initial values
df[, `:=`(
  first_date = min(date_base),
  valor_bem_initial = first(valor_bem),
  prazo_initial = first(prazo)
), by = .(cota_full_id, grupo_id, adm_id, codigo_seg)]

# Step 2: Simple, robust approach - separate calculation from assignment

# Create separate dataset with just first periods for quartile calculation  
first_periods <- df[date_base == first_date]

# Calculate group quartiles using random ranking method to break ties
# This ensures approximately equal counts per quartile within each group
first_periods[, quart_val_group := {
  r <- rank(valor_bem, ties.method = "random")
  dplyr::ntile(r, 4)
}, by = .(grupo_id, adm_id, codigo_seg, first_date)]

# Calculate segment quartiles using same method
first_periods[, `:=`(
  quart_val_seg = {
    r <- rank(valor_bem, ties.method = "random")
    dplyr::ntile(r, 4)
  },
  quart_dur_seg = {
    r <- rank(prazo, ties.method = "random")
    dplyr::ntile(r, 4)
  }
), by = .(codigo_seg, first_date)]

# Calculate max/min credit value indicators within groups
first_periods[, `:=`(
  max_credit_val = fifelse(credit_contemp == max(credit_contemp, na.rm = TRUE), 1, 0),
  min_credit_val = fifelse(credit_contemp == min(credit_contemp, na.rm = TRUE), 1, 0)
), by = .(grupo_id, adm_id, codigo_seg, first_date)]

# Simple, clean join back to main dataset - quartiles and credit indicators
quartile_lookup <- first_periods[, .(cota_full_id, quart_val_group, quart_val_seg, quart_dur_seg, 
                                     max_credit_val, min_credit_val)]

df[quartile_lookup, `:=`(
  quart_val_group = i.quart_val_group,
  quart_val_seg = i.quart_val_seg,
  quart_dur_seg = i.quart_dur_seg,
  max_credit_val = i.max_credit_val,
  min_credit_val = i.min_credit_val
), on = .(cota_full_id)]

#%% Sorting dataframe - data.table is much faster for large datasets
setorder(df, adm_id, grupo_id, cota_id, cota_full_id, date_base)

#%% Exporting to .rds and .csv ------------------------------

# Fast export using data.table
saveRDS(df, "mock_data/FCT_general_datatable_clean.rds")
fwrite(df, "mock_data/FCT_general_datatable_clean.csv")  # Much faster than write.csv

# Print summary for verification
cat("Data cleaning completed successfully!\n")
cat("Final dataset dimensions:", dim(df), "\n")
cat("Memory usage:", format(object.size(df), units = "MB"), "\n")
