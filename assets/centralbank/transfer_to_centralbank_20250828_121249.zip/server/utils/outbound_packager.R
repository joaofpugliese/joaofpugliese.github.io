# Outbound packaging utilities for session completion
# • Input: base directory, outbound folder path
# • Output: timestamped zip file with code and folder structure report

#' Package code files and folder structure for outbound transfer
#' 
#' Creates zip archive with all R/Python code and folder structure summary.
#' 
#' @param base_path Character. Base directory to package (default: current directory)
#' @param outbound_path Character. Outbound directory for zip file
#' @param exclude_patterns Character. Patterns to exclude from packaging
#' @return Character. Path to created zip file
#' @examples
#' package_outbound(".", "outbound")
package_outbound <- function(base_path = ".", 
                           outbound_path = "outbound", 
                           exclude_patterns = c("inbound/", "outbound/")) {
  
  cat("=== OUTBOUND PACKAGING ===\n")
  cat("Timestamp:", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")
  
  # Ensure outbound directory exists
  if (!dir.exists(outbound_path)) {
    dir.create(outbound_path, recursive = TRUE)
    cat("Created outbound directory:", outbound_path, "\n")
  }
  
  # Find all R and Python files
  r_files <- list.files(base_path, pattern = "\\.[rR]$", full.names = TRUE, recursive = TRUE)
  py_files <- list.files(base_path, pattern = "\\.py$", full.names = TRUE, recursive = TRUE)
  sql_files <- list.files(base_path, pattern = "\\.sql$", full.names = TRUE, recursive = TRUE)
  all_code_files <- c(r_files, py_files, sql_files)
  
  # Filter out excluded patterns
  for (pattern in exclude_patterns) {
    all_code_files <- all_code_files[!grepl(pattern, all_code_files, fixed = TRUE)]
  }
  
  cat("CODE FILES TO PACKAGE:\n")
  if (length(all_code_files) == 0) {
    cat("  (no code files found)\n")
    return(invisible(NULL))
  } else {
    relative_files <- gsub(paste0("^", base_path, "/"), "", all_code_files)
    cat(paste("  +", relative_files), sep = "\n")
  }
  cat("\n")
  
  # Generate folder structure report
  folder_structure_paths <- c(
    "utils/folder_structure.R",           # If running from server directory
    "server/utils/folder_structure.R"    # If running from centralbank directory
  )
  
  folder_structure_file <- NULL
  for (path in folder_structure_paths) {
    if (file.exists(path)) {
      folder_structure_file <- path
      break
    }
  }
  
  if (!is.null(folder_structure_file)) {
    source(folder_structure_file)
    cat("Generating folder structure report...\n")
    structure_file <- "temp_folder_structure.txt"
    generate_folder_structure(base_path, structure_file)
    cat("✓ Folder structure report created\n\n")
  } else {
    structure_file <- NULL
    cat("⚠️ folder_structure.R not found, skipping structure report\n\n")
  }
  
  # Create timestamped zip filename with direction-aware naming
  timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
  current_folder <- basename(getwd())
  
  # Logic: if we're packaging from server directory, we're sending TO central bank
  # if we're in centralbank directory packaging server content, we're also sending TO central bank
  if (tolower(current_folder) %in% c("server", "centralbank")) {
    zip_filename <- paste0("transfer_to_centralbank_", timestamp, ".zip")
  } else {
    zip_filename <- paste0("transfer_from_server_", timestamp, ".zip")
  }
  zip_path <- file.path(outbound_path, zip_filename)
  
  # Prepare files for zipping
  files_to_zip <- all_code_files
  if (!is.null(structure_file) && file.exists(structure_file)) {
    files_to_zip <- c(files_to_zip, structure_file)
  }
  
  # Create zip archive
  cat("Creating zip archive:", zip_filename, "\n")
  tryCatch({
    zip_result <- zip(zip_path, files_to_zip)
    if (zip_result == 0) {
      cat("✓ Zip archive created successfully\n")
    } else {
      cat("✗ Zip creation failed with code:", zip_result, "\n")
      return(invisible(NULL))
    }
  }, error = function(e) {
    cat("✗ Zip creation error:", e$message, "\n")
    return(invisible(NULL))
  })
  
  # Clean up temporary structure file
  if (!is.null(structure_file) && file.exists(structure_file)) {
    file.remove(structure_file)
    cat("✓ Temporary structure file cleaned up\n")
  }
  
  cat("\n=== PACKAGING COMPLETE ===\n")
  cat("Archive:", zip_path, "\n")
  cat("Files packaged:", length(files_to_zip), "\n")
  
  return(invisible(zip_path))
}

#' List contents of most recent outbound package
#' 
#' Shows what was included in the latest zip export.
#' 
#' @param outbound_path Character. Outbound directory to check
#' @return Character. Vector of file contents in latest zip
list_latest_export <- function(outbound_path = "outbound") {
  
  if (!dir.exists(outbound_path)) {
    cat("Outbound directory not found:", outbound_path, "\n")
    return(invisible(character(0)))
  }
  
  zip_files <- list.files(outbound_path, pattern = "transfer_(to|from)_server_.*\\.zip$", full.names = TRUE)
  
  if (length(zip_files) == 0) {
    cat("No export archives found in", outbound_path, "\n")
    return(invisible(character(0)))
  }
  
  # Get most recent zip
  latest_zip <- zip_files[which.max(file.info(zip_files)$mtime)]
  
  cat("Latest export:", basename(latest_zip), "\n")
  cat("Contents:\n")
  
  contents <- unzip(latest_zip, list = TRUE)$Name
  cat(paste("  -", contents), sep = "\n")
  
  return(invisible(contents))
}
