# Central Bank session initialization script  
# • Input: none (uses standard folder structure)
# • Output: inbound folder analysis, overlap detection, and version control report

# Load utilities
setwd("data/code/centralbank/server")
source("utils/inbound_analyzer.R")
source("utils/file_comparator.R")

# Step 1: Analyze inbound folder structure and unzip files
cat("STEP 1: Analyzing inbound folder...\n")
result <- analyze_inbound(
  inbound_path = "inbound",
  base_path = ".."  # Go up to centralbank/ root
)

# Step 2: Compare files for version control
cat("\nSTEP 2: Comparing files for changes...\n")
comparison <- compare_directories(
  inbound_path = "inbound",
  server_path = ".",
  ignore_patterns = c("\\.Rhistory$", "\\.RData$", "~\\$", "\\.tmp$", "\\.zip$")
)

cat("\n=== INITIALIZATION COMPLETE ===\n")
cat("Files analyzed:", length(result$files_final), "\n")
cat("Overlaps found:", length(result$overlaps), "\n")

if (!is.null(comparison$summary)) {
  cat("Version control status:\n")
  cat("  New files:", comparison$summary$new_count, "\n")
  cat("  Updated files:", comparison$summary$updated_count, "\n")
  cat("  Files needing attention:", comparison$summary$new_count + comparison$summary$updated_count, "\n")
}
