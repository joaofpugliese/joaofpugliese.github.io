# Central Bank session initialization script  
# • Input: none (uses standard folder structure)
# • Output: inbound folder analysis, overlap detection, and version control report

# Load utilities
setwd("data/code/centralbank/")
source("server/utils/inbound_analyzer.R")
source("server/utils/file_comparator.R")

# Step 1: Analyze inbound folder structure and unzip files
cat("STEP 1: Analyzing inbound folder...\n")
result <- analyze_inbound(
  inbound_path = "inbound",
  base_path = "."
)

# Step 2: Compare files for version control
cat("\nSTEP 2: Comparing files for changes...\n")
changed_files <- compare_directories(
  inbound_path = "inbound",
  server_path = "server",
  ignore_patterns = c("\\.Rhistory$", "\\.RData$", "~\\$", "\\.tmp$", "\\.zip$"),
  save_report = TRUE,
  report_dir = "."
)

cat("\n=== INITIALIZATION COMPLETE ===\n")
cat("Files analyzed:", length(result$files_final), "\n")
cat("Overlaps found:", length(result$overlaps), "\n")
cat("Changed files found:", length(changed_files), "\n")