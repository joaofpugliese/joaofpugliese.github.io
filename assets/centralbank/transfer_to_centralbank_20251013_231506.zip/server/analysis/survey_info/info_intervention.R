# ---------------------------------------------- # 
#            Survey Information Analysis
# ---------------------------------------------- # 

# Packages ---------------------------------------

library(dplyr)
library(ggplot2)
library(lubridate)
library(tidyr)
library(RColorBrewer)
library(data.table)

# Helper functions ---------------------------------------

#' Create ECDF Functions by Groups
#'
#' @description
#' Creates empirical cumulative distribution functions (ECDFs) for a target
#' variable, grouped by specified variables.
#'
#' @param data Data.frame. Input dataset.
#' @param group_vars Character vector. Names of variables to group by.
#' @param target_var Character. Name of target variable for ECDF calculation.
#'
#' @return
#' Data.frame with columns for grouping variables, ecdf_function (list-column
#' with ecdf objects), n_quotas (count), and ecdf_call (callable function).
#'
#' @examples
#' create_ecdf(avg_time_credit, c("codigo_seg", "group_duration"), "month_contemp")
create_ecdf <- function(data, group_vars, target_var) {
  data %>%
    group_by(across(all_of(group_vars))) %>%
    summarise(
      ecdf_function = list(ecdf(.data[[target_var]])),
      n_quotas = n(),
      .groups = "drop"
    ) %>%
    mutate(
      ecdf_call = map(ecdf_function, ~ function(x) .x(x))
    )
}

#' Summarize Variable by Groups
#'
#' @description
#' Calculates count, mean, 25th and 75th percentiles for a target variable,
#' grouped by specified variables.
#'
#' @param data Data.frame. Input dataset.
#' @param group_vars Character vector. Names of variables to group by.
#' @param target_var Character. Name of target variable for summary statistics.
#'
#' @return
#' Data.frame with columns for grouping variables, n_quotas, avg_{target_var},
#' p25_{target_var}, and p75_{target_var}.
#'
#' @examples
#' summarize_by_groups(avg_time_credit, c("codigo_seg", "group_duration"), "month_contemp")
summarize_by_groups <- function(data, group_vars, target_var) {
  data %>%
    group_by(across(all_of(group_vars))) %>%
    summarise(
      n_quotas = n(),
      "avg_{target_var}" := round(mean(.data[[target_var]]), 2),
      "p25_{target_var}" := round(quantile(.data[[target_var]], 0.25), 2),
      "p75_{target_var}" := round(quantile(.data[[target_var]], 0.75), 2),
      .groups = "drop"
    )
}

# Importing dataset

# Use fread for faster file reading (header = TRUE is default)
# Add grepl to check if the working directory is Dropbox (outside server) or not
if(grepl("Dropbox", getwd())) {
  df <- readRDS("data/code/centralbank/server/data/output/contemplacoes_cota_level.rds")
} else {
  df <- fread("D:/server/data/output/contemplacoes_cota_level.csv", stringsAsFactors = FALSE, showProgress = TRUE)
}

# Helper functions

# Data cleaning - Common operations ----------------------------------------

# Convert to data.table for better performance and date handling
setDT(df)

# Base dataset with group-level calculations
# Groups by segment-group-administrator to ensure proper ID uniqueness
df_clean <- df[, .(
  # Calculate group start date (first contemplation in the group)
  first_contemp = min(date_contemp, na.rm = TRUE),
  # Calculate group most recent date (last contemplation in the group)
  most_recent_contemp = max(date_contemp, na.rm = TRUE),
  # Calculate actual group lifetime in years
  group_life_years = as.numeric(max(date_contemp, na.rm = TRUE) - min(date_contemp, na.rm = TRUE)) / 365.25,
  # Calculate group duration using mode of observed terms
  # First: determine which variable has more consistent values
  group_duration_raw = ifelse(
    # If modes of max and min are the same, use max_prazo_obs mode
    names(sort(table(max_prazo_obs), decreasing = TRUE))[1] == names(sort(table(min_prazo_obs), decreasing = TRUE))[1],
    as.numeric(names(sort(table(max_prazo_obs), decreasing = TRUE))[1]),
    # Otherwise, use min_prazo_obs mode
    as.numeric(names(sort(table(min_prazo_obs), decreasing = TRUE))[1])
  ),
  # Keep all original variables
  cota_id, cota_sub_id, codigo_seg, cpf_id, adm_id, grupo_id, cota_full_id,
  n_observations, n_periods, min_date_base, max_date_base, min_date_contemp,
  max_date_contemp, min_date_adesao, max_date_adesao, max_prazo, min_prazo,
  max_valor_bem, min_valor_bem, min_prazo_obs, max_prazo_obs, min_valor_bem_obs,
  max_valor_bem_obs, min_perc_lance, max_perc_lance, n_distinct_tip_cotista,
  n_distinct_status, n_distinct_allocation, min_tip_cotista, max_tip_cotista,
  min_status, max_status, min_allocation_type, max_allocation_type,
  allocation_type, date_contemp, date_adesao, time_span_months, time_span_days,
  year_min, year_max, year_contemp, year_adesao, invariant_dt_contemp,
  invariant_prazo, invariant_valor_bem, invariant_tip_cotista, invariant_status,
  invariant_allocation, invariant_dt_adesao, invariant_perc_lance, pessoa_fisica,
  date_cancel
), by = .(codigo_seg, grupo_id, adm_id)]

# Add rounded group duration - round to nearest multiple of 12
df_clean[, group_duration := round(group_duration_raw / 12) * 12]

# Remove temporary variable
df_clean[, group_duration_raw := NULL]

# Analysis datasets --------------------------------------------------------

# 1. Dataset: avg_time_credit - Average time to credit award by lottery
# Purpose: Calculate time from group start to individual contemplation for lottery awards
# Filter: Groups that ended by mid-2024, only lottery allocations (SORTEIO)

avg_time_credit <- df_clean[!is.na(date_contemp) & allocation_type == "S" & most_recent_contemp <= as.Date("2024-06-01"), 
  .(cota_id, codigo_seg, grupo_id, adm_id, group_duration, 
    month_contemp = round(as.numeric(date_contemp - first_contemp) / 30.44, 1),
    first_contemp, most_recent_contemp)]

# 1b. Dataset: avg_time_credit_no_cancelled - Average time to credit for non-cancelled quotas
# Purpose: Same as avg_time_credit but only for quotas that were NOT cancelled
# Filter: Same as above PLUS is.na(date_cancel)

avg_time_credit_no_cancelled <- df_clean[!is.na(date_contemp) & allocation_type == "S" & 
                                        most_recent_contemp <= as.Date("2024-06-01") &
                                        max_status==1, # max_status = 1 , never appeared as cancelled
  .(cota_id, codigo_seg, grupo_id, adm_id, group_duration, 
    month_contemp = round(as.numeric(date_contemp - first_contemp) / 30.44, 1),
    first_contemp, most_recent_contemp)]

# Summary datasets from avg_time_credit -------------------------------------

# 1. Summary by segment and group duration
avg_time_by_segment_duration <- summarize_by_groups(
  avg_time_credit,
  c("codigo_seg", "group_duration"),
  "month_contemp"
)

# 2. Summary by segment and year of first contemplation
avg_time_by_segment_year <- avg_time_credit %>%
  mutate(year_first_contemp = year(first_contemp)) %>%
  summarize_by_groups(c("codigo_seg", "group_duration", "year_first_contemp"), "month_contemp")

# Summary datasets from avg_time_credit_no_cancelled ---------------------------

# 1. Summary by segment and group duration (non-cancelled quotas)
avg_time_by_segment_duration_no_cancelled <- summarize_by_groups(
  avg_time_credit_no_cancelled,
  c("codigo_seg", "group_duration"),
  "month_contemp"
)

# 2. Summary by segment and year (non-cancelled quotas)
avg_time_by_segment_year_no_cancelled <- avg_time_credit_no_cancelled %>%
  mutate(year_first_contemp = year(first_contemp)) %>%
  summarize_by_groups(c("codigo_seg", "group_duration", "year_first_contemp"), "month_contemp")

# ECDF functions for each group ---------------------------------------------

# 1. ECDF by segment and group duration
ecdf_by_segment_duration <- create_ecdf(
  avg_time_credit, 
  c("codigo_seg", "group_duration"), 
  "month_contemp"
)

# 2. ECDF by segment, group duration, and year
ecdf_by_segment_duration_year <- avg_time_credit %>%
  mutate(year_first_contemp = year(first_contemp)) %>%
  create_ecdf(c("codigo_seg", "group_duration", "year_first_contemp"), "month_contemp")

# 3. ECDF by segment and group duration (non-cancelled quotas)
ecdf_by_segment_duration_no_cancelled <- create_ecdf(
  avg_time_credit_no_cancelled,
  c("codigo_seg", "group_duration"),
  "month_contemp"
)

# 4. ECDF by segment, group duration, and year (non-cancelled quotas)
ecdf_by_segment_duration_year_no_cancelled <- avg_time_credit_no_cancelled %>%
  mutate(year_first_contemp = year(first_contemp)) %>%
  create_ecdf(c("codigo_seg", "group_duration", "year_first_contemp"), "month_contemp")

# Example usage:
# To get ECDF value for 12 months in first group:
# ecdf_by_segment_duration$ecdf_call[[1]](12)
# 
# To get ECDF for specific segment and duration:
# target_ecdf <- ecdf_by_segment_duration %>%
#   filter(codigo_seg == "SEG1", group_duration == 36) %>%
#   pull(ecdf_call) %>% .[[1]]
# target_ecdf(12)  # Returns P(X <= 12)

# 2. Dataset: lances_distribution - Distribution of winning bid percentages
# Purpose: Analyze bid percentages for groups with 2-4 years of life, started from 2021
# Filter: Recent groups with sufficient maturity for meaningful bid analysis

lances_distribution <- df_clean %>%
  filter(!is.na(date_contemp) & allocation_type=="L") %>%
  filter(
    # Groups with at least 2 years of life (mature enough for analysis)
    group_life_years >= 2,
    # Groups with at most 4 years of life (not too old, still relevant)
    group_life_years <= 4
  ) %>%
  mutate(
    # Calculate bid percentage: use max if consistent, otherwise average
    # This handles cases where bid percentage varies within the same cota
    perc_lance = if_else(max_perc_lance == min_perc_lance, 
                        max_perc_lance,  # Use single value if consistent
                        (max_perc_lance + min_perc_lance) / 2)  # Average if varies
  ) %>%
  # Keep essential variables for bid distribution analysis
  select(cota_id, codigo_seg, grupo_id, adm_id, group_duration, perc_lance, first_contemp, most_recent_contemp, group_life_years)

# Summary datasets from lances_distribution --------------------------------

# 1. Summary by segment and group duration
lance_summary_by_segment_duration <- summarize_by_groups(
  lances_distribution,
  c("codigo_seg", "group_duration"),
  "perc_lance"
)

# 2. ECDF by segment and group duration
ecdf_lance_by_segment_duration <- create_ecdf(
  lances_distribution,
  c("codigo_seg", "group_duration"),
  "perc_lance"
)

# Example usage for lance ECDFs:
# To get ECDF value for 15% bid in first group:
# ecdf_lance_by_segment_duration$ecdf_call[[1]](15)
# 
# To get ECDF for specific segment and duration:
# target_ecdf <- ecdf_lance_by_segment_duration %>%
#   filter(codigo_seg == "SEG1", group_duration == 36) %>%
#   pull(ecdf_call) %>% .[[1]]
# target_ecdf(15)  # Returns P(X <= 15%)

# 3. Dataset: cancellation_stats - Cancellation rates by group
# Purpose: Calculate number of cancelled quotas vs total quotas for groups started before 2022
# Filter: Groups that have at least 2 years of life.
cancellation_stats <- df_clean %>%
  # Filter for groups that have at least 2 years of life
  filter(group_life_years >= 2) %>%
  group_by(codigo_seg, grupo_id, adm_id) %>%
  summarise(
    # Total number of quotas in the group
    total_quotas = n(),
    # Number of quotas with cancellation date (not NA)
    cancelled_quotas = sum(!is.na(date_cancel)),
    # Cancellation rate as percentage
    cancellation_rate = round(cancelled_quotas / total_quotas * 100, 2),
    # Group characteristics for context
    group_duration = first(group_duration),
    first_contemp = first(first_contemp),
    most_recent_contemp = first(most_recent_contemp),
    group_life_years = first(group_life_years),
    .groups = "drop"
  )

# Summary dataset from cancellation_stats ------------------------------------

# Summary by segment and group duration
cancellation_summary_by_segment_duration <- cancellation_stats %>%
  group_by(codigo_seg, group_duration) %>%
  summarise(
    n_groups = n(),
    avg_total_quotas = round(mean(total_quotas), 1),
    avg_cancelled_quotas = round(mean(cancelled_quotas), 1),
    avg_cancellation_rate = round(mean(cancellation_rate), 2),
    total_quotas_all_groups = sum(total_quotas),
    total_cancelled_quotas_all_groups = sum(cancelled_quotas),
    overall_cancellation_rate = round(sum(cancelled_quotas) / sum(total_quotas) * 100, 2),
    .groups = "drop"
  )

# Save datasets --------------------------------------------------------------

# Create output directory
output_dir <- ifelse(grepl("Dropbox", getwd()), 
                     "data/code/centralbank/server/analysis/survey_information/output/", 
                     "D:/server/analysis/survey_information/output/")

if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# Save datasets with functions as .rds (cannot be saved as .csv)
saveRDS(ecdf_by_segment_duration, paste0(output_dir, "ecdf_by_segment_duration.rds"))
saveRDS(ecdf_by_segment_duration_year, paste0(output_dir, "ecdf_by_segment_duration_year.rds"))
saveRDS(ecdf_by_segment_duration_no_cancelled, paste0(output_dir, "ecdf_by_segment_duration_no_cancelled.rds"))
saveRDS(ecdf_by_segment_duration_year_no_cancelled, paste0(output_dir, "ecdf_by_segment_duration_year_no_cancelled.rds"))
saveRDS(ecdf_lance_by_segment_duration, paste0(output_dir, "ecdf_lance_by_segment_duration.rds"))

# Save summary datasets as .csv (easier to work with in other tools)
write.csv(avg_time_by_segment_duration, paste0(output_dir, "avg_time_by_segment_duration.csv"), row.names = FALSE)
write.csv(avg_time_by_segment_year, paste0(output_dir, "avg_time_by_segment_year.csv"), row.names = FALSE)
write.csv(avg_time_by_segment_duration_no_cancelled, paste0(output_dir, "avg_time_by_segment_duration_no_cancelled.csv"), row.names = FALSE)
write.csv(avg_time_by_segment_year_no_cancelled, paste0(output_dir, "avg_time_by_segment_year_no_cancelled.csv"), row.names = FALSE)
write.csv(lance_summary_by_segment_duration, paste0(output_dir, "lance_summary_by_segment_duration.csv"), row.names = FALSE)
write.csv(cancellation_summary_by_segment_duration, paste0(output_dir, "cancellation_summary_by_segment_duration.csv"), row.names = FALSE)

# Save detailed datasets as .csv
write.csv(avg_time_credit, paste0(output_dir, "avg_time_credit.csv"), row.names = FALSE)
write.csv(avg_time_credit_no_cancelled, paste0(output_dir, "avg_time_credit_no_cancelled.csv"), row.names = FALSE)
write.csv(lances_distribution, paste0(output_dir, "lances_distribution.csv"), row.names = FALSE)
write.csv(cancellation_stats, paste0(output_dir, "cancellation_stats.csv"), row.names = FALSE)

cat("All datasets saved to:", output_dir, "\n")
cat("ECDF datasets saved as .rds files (contain functions)\n")
cat("Summary and detailed datasets saved as .csv files\n")