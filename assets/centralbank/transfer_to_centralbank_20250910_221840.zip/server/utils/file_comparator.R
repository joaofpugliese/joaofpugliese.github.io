# Simple file comparator for manual version control
# • Input: transfer_inbound and server directory paths
# • Output: list of files with detected changes

#' Compare files between transfer_inbound and server directories
#' 
#' Simple text-based comparison that identifies files with content changes.
#' 
#' @param inbound_path Character. Path to transfer_inbound directory (default: "../transfer_inbound")
#' @param server_path Character. Path to server directory (default: ".")
#' @param ignore_patterns Character. File patterns to ignore
#' @param save_report Logical. Whether to save report to file (default: FALSE)
#' @param report_dir Character. Directory to save report (default: current working directory)
#' @return Character vector. Relative paths of files with changes
#' @examples
#' changed_files <- compare_directories()
#' changed_files <- compare_directories(save_report = TRUE)
compare_directories <- function(inbound_path = "../transfer_inbound", 
                               server_path = ".", 
                               ignore_patterns = c("\\.Rhistory$", "\\.RData$", "~\\$", "\\.tmp$", "\\.zip$"),
                               save_report = FALSE,
                               report_dir = ".") {
  
  # Initialize report capture
  report_lines <- character(0)
  
  # Helper function to both print and capture
  add_line <- function(text) {
    cat(text, "\n")
    report_lines <<- c(report_lines, text)
  }
  
  add_line("=== SIMPLE VERSION CONTROL CHECK ===")
  add_line(paste("Timestamp:", format(Sys.time(), "%Y-%m-%d %H:%M:%S")))
  add_line(paste("Comparing:", inbound_path, "→", server_path))
  add_line("")
  
  # Check if directories exist
  if (!dir.exists(inbound_path)) {
    add_line(paste("❌ Transfer_inbound directory not found:", inbound_path))
    if (save_report) save_report_file(report_lines, report_dir)
    return(character(0))
  }
  
  # Get all files from inbound
  inbound_files <- list.files(inbound_path, full.names = TRUE, recursive = TRUE)
  
  # Apply ignore patterns
  if (length(ignore_patterns) > 0) {
    for (pattern in ignore_patterns) {
      inbound_files <- inbound_files[!grepl(pattern, inbound_files)]
    }
  }
  
  if (length(inbound_files) == 0) {
    add_line("No files found in transfer_inbound")
    if (save_report) save_report_file(report_lines, report_dir)
    return(character(0))
  }
  
  # Convert to relative paths properly
  inbound_base <- normalizePath(inbound_path, winslash = "/")
  inbound_relative <- character(length(inbound_files))
  
  for (i in seq_along(inbound_files)) {
    full_path <- normalizePath(inbound_files[i], winslash = "/")
    inbound_relative[i] <- sub(paste0("^", inbound_base, "/"), "", full_path)
  }
  
  changed_files <- character(0)
  new_files <- character(0)
  
  add_line(paste("Checking", length(inbound_files), "files..."))
  
  for (i in seq_along(inbound_files)) {
    inbound_file <- inbound_files[i]
    relative_path <- inbound_relative[i]
    server_file <- file.path(normalizePath(server_path, winslash = "/"), relative_path)
    server_file <- gsub("\\\\", "/", server_file)  # Normalize slashes
    
    # Check if corresponding server file exists
    if (!file.exists(server_file)) {
      add_line(paste("🆕 NEW:", relative_path))
      changed_files <- c(changed_files, relative_path)
      new_files <- c(new_files, relative_path)
    } else {
      # Compare content
      if (!files_identical(inbound_file, server_file)) {
        add_line(paste("🔄 CHANGED:", relative_path))
        changed_files <- c(changed_files, relative_path)
      }
    }
  }
  
  add_line("")
  if (length(changed_files) == 0) {
    add_line("✅ No changes detected")
  } else {
    add_line(paste("📋 SUMMARY:", length(changed_files), "file(s) with changes"))
    add_line(paste("  - New files:", length(new_files)))
    add_line(paste("  - Changed files:", length(changed_files) - length(new_files)))
  }
  
  # Save report if requested
  if (save_report) {
    report_file <- save_report_file(report_lines, report_dir)
    add_line("")
    add_line(paste("📄 Report saved to:", report_file))
  }
  
  return(changed_files)
}

#' Save report to timestamped file
#' 
#' Creates a timestamped report file.
#' 
#' @param report_lines Character. Vector of report lines
#' @param report_dir Character. Directory to save report
#' @return Character. Path to saved report file
save_report_file <- function(report_lines, report_dir) {
  
  # Create timestamped filename: inbound_report_DDMM_HHMM.txt
  timestamp <- format(Sys.time(), "%d%m_%H%M")
  filename <- paste0("inbound_report_", timestamp, ".txt")
  filepath <- file.path(report_dir, filename)
  
  # Write report to file
  writeLines(report_lines, filepath)
  
  return(filepath)
}

#' Check if two files have identical content
#' 
#' Simple text-based comparison.
#' 
#' @param file1 Character. Path to first file
#' @param file2 Character. Path to second file
#' @return Logical. TRUE if files are identical
files_identical <- function(file1, file2) {
  
  # Quick size check first
  size1 <- file.info(file1)$size
  size2 <- file.info(file2)$size
  if (size1 != size2) return(FALSE)
  
  # Read as plain text and compare
  tryCatch({
    content1 <- readLines(file1, warn = FALSE)
    content2 <- readLines(file2, warn = FALSE)
    return(identical(content1, content2))
  }, error = function(e) {
    # If reading fails, assume different
    return(FALSE)
  })
}
