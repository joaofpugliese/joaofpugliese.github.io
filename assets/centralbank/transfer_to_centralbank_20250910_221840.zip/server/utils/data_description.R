# ---------------------------------------------- # 
# Data description
# ---------------------------------------------- # 

#' Generate consortium data summary statistics with error handling
#' 
#' Computes counts, rates, and temporal distributions for consortium database.
#' Missing columns are handled gracefully - statistics requiring unavailable 
#' columns are skipped with warnings rather than errors.
#' 
#' @param df Data.frame. Consortium data with standard columns
#' @param col_dict List. Maps standard names to actual column names (auto-detected if NULL)
#' The standard list defaults are:
#'   \itemize{
#'     \item cpf: "cpf_fake_id" (CPF/participant identifiers)
#'     \item cota: "cota_id" (basic quota identifiers)
#'     \\item cota_seq: "cota_full_id" (full quota identifiers with sequence)
#'     \\item grupo: "grupo_id" (group identifiers)
#'     \\item adm: "adm_id" (administrator identifiers)
#'     \\item segment: "codigo_seg" (segment identifiers)
#'     \\item year: "year" (year variable)
#' }
#' @param output_file Character. Path for .txt output (console if NULL)
#' @param dataset_name Character. Dataset name for report title
#' @return List with counts, rates, yearly distributions, and segment breakdowns.
#'   Values are NA when required columns are missing.
#' @examples
#' data_description(df)
#' data_description(df, output_file = "summary.txt")
#' @export

data_description <- function(df, col_dict = NULL, output_file = NULL, dataset_name = NULL) {
  
  # Load required packages
  if (!require("dplyr", quietly = TRUE)) {
    stop("Package 'dplyr' is required but not installed.")
  }
  if (!require("data.table", quietly = TRUE)) {
    stop("Package 'data.table' is required but not installed.")
  }
  
  # Set standard column names and auto-detect if needed
  if (is.null(col_dict)) {
    col_dict <- list(
      cpf = "cpf_fake_id",
      cota = "cota_id", 
      cota_seq = "cota_full_id",
      grupo = "grupo_id",
      adm = "adm_id",
      segment = "codigo_seg",
      year = "year"
    )
    
    # Auto-detect columns using candidate lists
    candidates <- list(
      cpf = c("cpf_fake_id", "CTC_CD_COTISTA2", "CTC_CD_COTISTA", "participant_id"),
      cota = c("cota_id", "COT_CD_COTA", "quota_id"),
      cota_seq = c("cota_full_id", "cota_id", "COT_CD_COTA", "quota_full_id"),
      grupo = c("grupo_id", "gai_cd_grupo2", "group_id"),
      adm = c("adm_id", "adm_cd2", "admin_id"),
      segment = c("codigo_seg", "FCT_CD_SEG", "segment_id", "segment"),
      year = c("year", "ano", "YEAR")
    )
    
    for (key in names(candidates)) {
      if (!(col_dict[[key]] %in% names(df))) {
        col_dict[[key]] <- candidates[[key]][candidates[[key]] %in% names(df)][1]
      }
    }
  }
  
  # Check which columns are available and create indicators
  col_available <- list()
  missing_cols <- character(0)
  
  for (key in names(col_dict)) {
    if (is.na(col_dict[[key]]) || !(col_dict[[key]] %in% names(df))) {
      col_available[[key]] <- FALSE
      missing_cols <- c(missing_cols, paste0(key, " (", col_dict[[key]], ")"))
      col_dict[[key]] <- NA  # Set to NA for safety
    } else {
      col_available[[key]] <- TRUE
    }
  }
  
  # Warn about missing columns but continue
  if (length(missing_cols) > 0) {
    warning("Missing columns (statistics will be skipped): ", paste(missing_cols, collapse = ", "))
  }
  
  # Convert to data.table for faster operations
  dt <- data.table::as.data.table(df)
  
  # Create shorter variable names for cleaner code (only for available columns)
  cpf_col <- if (col_available$cpf) col_dict$cpf else NULL
  cota_col <- if (col_available$cota) col_dict$cota else NULL
  cota_seq_col <- if (col_available$cota_seq) col_dict$cota_seq else NULL
  grupo_col <- if (col_available$grupo) col_dict$grupo else NULL
  adm_col <- if (col_available$adm) col_dict$adm else NULL
  segment_col <- if (col_available$segment) col_dict$segment else NULL
  year_col <- if (col_available$year) col_dict$year else NULL
  
  # Calculate unique counts using data.table (conditional on available columns)
  n_cpfs <- if (col_available$cpf) {
    dt[!is.na(get(cpf_col)), uniqueN(get(cpf_col))]
  } else { NA_integer_ }
  
  n_cotas <- if (col_available$cota && col_available$grupo && col_available$adm && col_available$segment) {
    dt[!is.na(get(cota_col)) & !is.na(get(grupo_col)) & 
       !is.na(get(adm_col)) & !is.na(get(segment_col)), 
       uniqueN(paste(get(cota_col), get(grupo_col), get(adm_col), get(segment_col)))]
  } else { NA_integer_ }
  
  n_cotas_seq <- if (col_available$cota_seq && col_available$grupo && col_available$adm && col_available$segment) {
    dt[!is.na(get(cota_seq_col)) & !is.na(get(grupo_col)) & 
       !is.na(get(adm_col)) & !is.na(get(segment_col)), 
       uniqueN(paste(get(cota_seq_col), get(grupo_col), get(adm_col), get(segment_col)))]
  } else { NA_integer_ }
  
  n_grupos <- if (col_available$grupo) {
    dt[!is.na(get(grupo_col)), uniqueN(get(grupo_col))]
  } else { NA_integer_ }
  
  n_administradores <- if (col_available$adm) {
    dt[!is.na(get(adm_col)), uniqueN(get(adm_col))]
  } else { NA_integer_ }
  
  # Calculate cotas-seq per year using data.table (conditional)
  cotas_por_ano <- if (col_available$cota_seq && col_available$year && col_available$grupo && col_available$adm && col_available$segment) {
    result <- dt[!is.na(get(cota_seq_col)) & !is.na(get(year_col)) & 
                 !is.na(get(grupo_col)) & !is.na(get(adm_col)) & !is.na(get(segment_col)), 
                 .(n_cotas_unicas = uniqueN(paste(get(cota_seq_col), get(grupo_col), 
                                                 get(adm_col), get(segment_col)))), 
                 by = get(year_col)]
    data.table::setnames(result, "get", "year")
    data.table::setorder(result, year)
    as.data.frame(result)  # Convert back to data.frame for compatibility
  } else { 
    data.frame(year = integer(0), n_cotas_unicas = integer(0))
  }
  
  # Calculate all rates at once (conditional on available data)
  rates <- list(
    cotas_per_group_avg = if (!is.na(n_cotas) && !is.na(n_grupos) && n_grupos > 0) round(n_cotas / n_grupos, 3) else NA_real_,
    unique_cotas_per_unique_cpf_avg = if (!is.na(n_cotas_seq) && !is.na(n_cpfs) && n_cpfs > 0) round(n_cotas_seq / n_cpfs, 3) else NA_real_,
    seq_per_cota_avg = if (!is.na(n_cotas_seq) && !is.na(n_cotas) && n_cotas > 0) round(n_cotas_seq / n_cotas, 3) else NA_real_,
    groups_per_admin_avg = if (!is.na(n_grupos) && !is.na(n_administradores) && n_administradores > 0) round(n_grupos / n_administradores, 3) else NA_real_,
    cotas_per_admin_avg = if (!is.na(n_cotas) && !is.na(n_administradores) && n_administradores > 0) round(n_cotas / n_administradores, 3) else NA_real_
  )
  
  # Calculate CPFs per cota_full_id using data.table (conditional)
  cpfs_per_cota_full_id <- if (col_available$cpf && col_available$cota_seq && col_available$grupo && col_available$adm && col_available$segment) {
    dt[!is.na(get(cpf_col)) & !is.na(get(cota_seq_col)) & 
       !is.na(get(grupo_col)) & !is.na(get(adm_col)) & !is.na(get(segment_col)), 
       .(n_cpfs_in_cota = uniqueN(get(cpf_col))), 
       by = .(get(cota_seq_col), get(grupo_col), get(adm_col), get(segment_col))][
       , round(mean(n_cpfs_in_cota), 2)]
  } else { NA_real_ }
  
  # Calculate segment-level statistics using data.table (conditional)
  groups_per_segment <- if (col_available$grupo && col_available$segment) {
    result <- dt[!is.na(get(grupo_col)) & !is.na(get(segment_col)), 
                 .(n_groups = uniqueN(get(grupo_col))), 
                 by = get(segment_col)]
    data.table::setnames(result, "get", "segment")
    data.table::setorder(result, segment)
    as.data.frame(result)  # Convert back to data.frame
  } else { 
    data.frame(segment = character(0), n_groups = integer(0))
  }
  
  cotas_per_segment <- if (col_available$cota && col_available$grupo && col_available$adm && col_available$segment) {
    result <- dt[!is.na(get(cota_col)) & !is.na(get(grupo_col)) & 
                 !is.na(get(adm_col)) & !is.na(get(segment_col)), 
                 .(n_cotas = uniqueN(paste(get(cota_col), get(grupo_col), 
                                          get(adm_col), get(segment_col)))), 
                 by = get(segment_col)]
    data.table::setnames(result, "get", "segment")
    data.table::setorder(result, segment)
    as.data.frame(result)  # Convert back to data.frame
  } else { 
    data.frame(segment = character(0), n_cotas = integer(0))
  }
  
  # Build output content efficiently
  if (is.null(dataset_name)) dataset_name <- "Consortium Dataset"
  current_time <- format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
  
  # Helper function to format table rows
  format_table <- function(data, val_col) {
    sprintf("%s\t%s", data$segment, format(data[[val_col]], big.mark = ","))
  }
  
  # Build output sections
  header <- c(
    sprintf("=== %s DATA DESCRIPTION ===", toupper(dataset_name)),
    sprintf("Generated on: %s", current_time),
    "",
    sprintf("Total rows: %s", format(nrow(df), big.mark = ",")),
    ""
  )
  
  # Build counts section conditionally
  counts <- c()
  if (!is.na(n_cpfs)) {
    counts <- c(counts, sprintf("Total unique CPFs/Participants: %s", format(n_cpfs, big.mark = ",")))
  }
  if (!is.na(n_cotas)) {
    counts <- c(counts, sprintf("Total unique Cotas (cota_id within group-adm-segment): %s", format(n_cotas, big.mark = ",")))
  }
  if (!is.na(n_cotas_seq)) {
    counts <- c(counts, sprintf("Total unique Cotas-seq (cota_full_id within group-adm-segment): %s", format(n_cotas_seq, big.mark = ",")))
  }
  if (!is.na(n_grupos)) {
    counts <- c(counts, sprintf("Total unique Groups: %s", format(n_grupos, big.mark = ",")))
  }
  if (!is.na(n_administradores)) {
    counts <- c(counts, sprintf("Total unique Administrators: %s", format(n_administradores, big.mark = ",")))
  }
  counts <- c(counts, "")
  
  # Build rates section conditionally
  rate_section <- c("=== AVERAGE RATES ===")
  
  if (!is.na(rates$cotas_per_group_avg)) {
    rate_section <- c(rate_section, sprintf("Cotas per group (avg.): %.2f", rates$cotas_per_group_avg))
  }
  if (!is.na(rates$unique_cotas_per_unique_cpf_avg)) {
    rate_section <- c(rate_section, sprintf("Unique cotas per unique CPF (avg.): %.2f", rates$unique_cotas_per_unique_cpf_avg))
  }
  if (!is.na(rates$seq_per_cota_avg)) {
    rate_section <- c(rate_section, sprintf("Seq per cota (avg.): %.2f", rates$seq_per_cota_avg))
  }
  if (!is.na(rates$groups_per_admin_avg)) {
    rate_section <- c(rate_section, sprintf("Groups per admin (avg.): %.2f", rates$groups_per_admin_avg))
  }
  if (!is.na(rates$cotas_per_admin_avg)) {
    rate_section <- c(rate_section, sprintf("Cotas per admin (avg.): %.2f", rates$cotas_per_admin_avg))
  }
  if (!is.na(cpfs_per_cota_full_id)) {
    rate_section <- c(rate_section, sprintf("Participants per cota-cota_seq (avg.): %.2f", cpfs_per_cota_full_id))
  }
  
  # Add empty line if any rates were added, or indicate no rates available
  if (length(rate_section) > 1) {
    rate_section <- c(rate_section, "")
  } else {
    rate_section <- c(rate_section, "No rates could be calculated (missing required columns)", "")
  }
  
  # Build groups per segment section conditionally
  groups_section <- if (nrow(groups_per_segment) > 0) {
    c(
      "=== GROUPS PER SEGMENT ===",
      "Segment\tGroups",
      "-------\t------",
      format_table(groups_per_segment, "n_groups"),
      ""
    )
  } else {
    c(
      "=== GROUPS PER SEGMENT ===",
      "No segment data available",
      ""
    )
  }
  
  # Build cotas per segment section conditionally
  cotas_section <- if (nrow(cotas_per_segment) > 0) {
    c(
      "=== COTAS PER SEGMENT ===",
      "Segment\tCotas",
      "-------\t-----",
      format_table(cotas_per_segment, "n_cotas"),
      ""
    )
  } else {
    c(
      "=== COTAS PER SEGMENT ===",
      "No segment data available",
      ""
    )
  }
  
  # Build yearly section conditionally
  yearly_section <- if (nrow(cotas_por_ano) > 0) {
    c(
      "=== UNIQUE COTAS-SEQ COMBINATIONS PER YEAR ===",
      "Year\tUnique Cotas-seq",
      "----\t----------------",
      sprintf("%d\t%s", cotas_por_ano$year, format(cotas_por_ano$n_cotas_unicas, big.mark = ",")),
      "",
      if (!is.na(n_cotas_seq)) sprintf("Total across all years: %s", format(n_cotas_seq, big.mark = ",")) else ""
    )
  } else {
    c(
      "=== UNIQUE COTAS-SEQ COMBINATIONS PER YEAR ===",
      "No yearly data available (missing year or cota_seq columns)",
      ""
    )
  }
  
  output_lines <- c(header, counts, rate_section, groups_section, cotas_section, yearly_section)
  
  # Output to file or console
  if (!is.null(output_file)) {
    # Write to .txt file
    writeLines(output_lines, output_file)
    cat(sprintf("Data description saved to: %s\n", output_file))
  } else {
    # Print to console
    cat(paste(output_lines, collapse = "\n"))
    cat("\n")
  }
  
  # Return comprehensive results
  return(c(
    list(
      n_cpfs = n_cpfs,
      n_cotas = n_cotas,
      n_cotas_seq = n_cotas_seq,
      n_grupos = n_grupos,
      n_administradores = n_administradores,
      cotas_por_ano = cotas_por_ano,
      cpfs_per_cota_full_id = cpfs_per_cota_full_id,
      groups_per_segment = groups_per_segment,
      cotas_per_segment = cotas_per_segment
    ),
    rates  # Unpack rates list to maintain backward compatibility
  ))
}