#' Generate timestamped folder structure report
#' 
#' Creates formatted text file with directory tree for offline reference.
#' 
#' @param base_path Character. Directory to analyze (default: current directory)
#' @param output_file Character. Output filename (default: auto-timestamped)
#' @param max_depth Integer. Maximum traversal depth (default: 10)
#' @return Character. Path to created file
#' @examples
#' generate_folder_structure()
#' generate_folder_structure("data", "my_structure.txt", 5)
generate_folder_structure <- function(base_path = ".", 
                                    output_file = NULL, 
                                    max_depth = 10) {
  
  # Generate timestamp
  timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
  
  # Default output filename with timestamp
  if (is.null(output_file)) {
    output_file <- paste0("folder_structure_", timestamp, ".txt")
  }
  
  # Function to recursively scan directories
  scan_directory <- function(path, current_depth = 0, prefix = "") {
    
    # Check depth limit
    if (current_depth > max_depth) {
      return(paste0(prefix, "... (max depth reached)\n"))
    }
    
    # Get directory contents
    if (!dir.exists(path)) {
      return(paste0(prefix, "... (directory not found)\n"))
    }
    
    contents <- list.files(path, full.names = TRUE, include.dirs = TRUE)
    if (length(contents) == 0) {
      return("")
    }
    
    # Sort contents: directories first, then files
    info <- file.info(contents)
    directories <- contents[info$isdir & !is.na(info$isdir)]
    files <- contents[!info$isdir & !is.na(info$isdir)]
    
    # Sort alphabetically within each group
    directories <- sort(directories)
    files <- sort(files)
    all_items <- c(directories, files)
    
    result <- ""
    
    for (i in seq_along(all_items)) {
      item <- all_items[i]
      item_name <- basename(item)
      
      # Skip hidden files and common temp files
      if (startsWith(item_name, ".") && !item_name %in% c(".Rhistory")) {
        next
      }
      
      is_last <- (i == length(all_items))
      
      # Determine prefix for this item
      if (current_depth == 0) {
        current_prefix <- ""
        child_prefix <- ""
      } else {
        current_prefix <- paste0(prefix, "├── ")
        child_prefix <- paste0(prefix, "│   ")
        
        if (is_last) {
          current_prefix <- paste0(prefix, "└── ")
          child_prefix <- paste0(prefix, "    ")
        }
      }
      
      # Add current item
      if (file.info(item)$isdir) {
        result <- paste0(result, current_prefix, item_name, "/\n")
        # Recursively add subdirectory contents
        result <- paste0(result, scan_directory(item, current_depth + 1, child_prefix))
      } else {
        # Get file size for display
        size_bytes <- file.info(item)$size
        size_display <- format_file_size(size_bytes)
        result <- paste0(result, current_prefix, item_name, " (", size_display, ")\n")
      }
    }
    
    return(result)
  }
  
  # Helper function to format file sizes
  format_file_size <- function(size_bytes) {
    if (is.na(size_bytes)) return("? KB")
    
    if (size_bytes < 1024) {
      return(paste0(size_bytes, " B"))
    } else if (size_bytes < 1024^2) {
      return(paste0(round(size_bytes / 1024, 1), " KB"))
    } else if (size_bytes < 1024^3) {
      return(paste0(round(size_bytes / 1024^2, 1), " MB"))
    } else {
      return(paste0(round(size_bytes / 1024^3, 1), " GB"))
    }
  }
  
  # Create header
  header <- paste0(
    "======================================================================\n",
    "FOLDER STRUCTURE REPORT\n",
    "======================================================================\n",
    "Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n",
    "Base Path: ", normalizePath(base_path, winslash = "/"), "\n",
    "Working Directory: ", normalizePath(getwd(), winslash = "/"), "\n",
    "R Version: ", R.version.string, "\n",
    "======================================================================\n\n"
  )
  
  # Generate folder structure
  structure_content <- scan_directory(base_path)
  
  # Generate library versions section
  cat("Collecting installed packages info...\n")
  installed_pkgs <- installed.packages()[, c("Package", "Version")]
  installed_pkgs <- installed_pkgs[order(installed_pkgs[, "Package"]), ]
  
  library_section <- paste0(
    "\n======================================================================\n",
    "INSTALLED R PACKAGES\n",
    "======================================================================\n",
    sprintf("%-30s %s\n", "Package", "Version"),
    sprintf("%-30s %s\n", "-------", "-------"),
    paste(sprintf("%-30s %s", installed_pkgs[, "Package"], installed_pkgs[, "Version"]), collapse = "\n"),
    sprintf("\n\nTotal packages installed: %d\n", nrow(installed_pkgs)),
    "======================================================================\n"
  )
  
  # Combine all content
  full_content <- paste0(header, structure_content, library_section)
  
  # Write to file
  output_path <- file.path(dirname(base_path), output_file)
  writeLines(full_content, output_path, sep = "")
  
  # Print summary
  cat("Folder structure report generated successfully!\n")
  cat("Output file:", normalizePath(output_path, winslash = "/"), "\n")
  cat("Timestamp:", timestamp, "\n")
  
  return(invisible(output_path))
}

#' Quick folder structure snapshot
#' 
#' Simplified version for rapid directory overview.
#' 
#' @param depth Integer. Maximum depth to show (default: 10)
#' @return Character. Path to created snapshot file
#' @examples
#' quick_structure_snapshot()
#' quick_structure_snapshot(5)
quick_structure_snapshot <- function(depth = 10) {
  timestamp <- format(Sys.time(), "%Y%m%d_%H%M")
  filename <- paste0("folder_snapshot_", timestamp, ".txt")
  
  result <- generate_folder_structure(
    base_path = ".", 
    output_file = filename, 
    max_depth = depth
  )
  
  cat("\nQuick snapshot saved as:", basename(result), "\n")
  return(invisible(result))
}