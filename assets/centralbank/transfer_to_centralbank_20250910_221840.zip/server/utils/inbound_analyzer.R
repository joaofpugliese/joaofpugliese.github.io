# Inbound folder analysis utilities
# • Input: inbound directory path
# • Output: folder contents analysis and overlap detection

#' Analyze inbound folder contents
#' 
#' Lists files, unzips archives, and detects name overlaps with existing codebase.
#' 
#' @param inbound_path Character. Path to inbound directory
#' @param base_path Character. Base project path for overlap detection
#' @return List. Contains file listings and overlap reports
#' @examples
#' analyze_inbound("server/inbound", ".")
analyze_inbound <- function(inbound_path = "inbound", base_path = ".") {
  
  cat("=== INBOUND FOLDER ANALYSIS ===\n")
  cat("Timestamp:", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n\n")
  
  # Check if inbound folder exists
  if (!dir.exists(inbound_path)) {
    dir.create(inbound_path, recursive = TRUE)
    cat("Created inbound directory:", inbound_path, "\n")
    return(invisible(list(files_initial = character(0), files_final = character(0), overlaps = character(0))))
  }
  
  # Initial contents
  initial_files <- list.files(inbound_path, full.names = FALSE, recursive = TRUE)
  cat("INITIAL CONTENTS:\n")
  if (length(initial_files) == 0) {
    cat("  (empty)\n")
  } else {
    cat(paste("  -", initial_files), sep = "\n")
  }
  cat("\n")
  
  # Process zip files
  zip_files <- list.files(inbound_path, pattern = "\\.zip$", full.names = TRUE, recursive = TRUE)
  if (length(zip_files) > 0) {
    cat("UNZIPPING FILES:\n")
    for (zip_file in zip_files) {
      cat("  Processing:", basename(zip_file), "\n")
      tryCatch({
        unzip(zip_file, exdir = dirname(zip_file))
        cat("    ✓ Extracted successfully\n")
      }, error = function(e) {
        cat("    ✗ Error:", e$message, "\n")
      })
    }
    cat("\n")
  }
  
  # Final contents after unzipping
  final_files <- list.files(inbound_path, full.names = FALSE, recursive = TRUE)
  cat("FINAL CONTENTS:\n")
  if (length(final_files) == 0) {
    cat("  (empty)\n")
  } else {
    cat(paste("  -", final_files), sep = "\n")
  }
  cat("\n")
  
  # Detect overlaps
  overlaps <- detect_file_overlaps(final_files, inbound_path, base_path)
  if (length(overlaps) > 0) {
    cat("OVERLAPPING FILES:\n")
    cat(paste("  ⚠️", overlaps), sep = "\n")
  } else {
    cat("No file name overlaps detected.\n")
  }
  
  return(invisible(list(
    files_initial = initial_files,
    files_final = final_files, 
    overlaps = overlaps
  )))
}

#' Detect file name overlaps between inbound and existing codebase
#' 
#' Finds files with same names in different locations.
#' 
#' @param inbound_files Character. Vector of inbound file names
#' @param inbound_path Character. Inbound directory path  
#' @param base_path Character. Base project path to search
#' @return Character. Vector of overlap descriptions
detect_file_overlaps <- function(inbound_files, inbound_path, base_path) {
  
  if (length(inbound_files) == 0) return(character(0))
  
  # Get all files in project (excluding inbound)
  all_files <- list.files(base_path, full.names = TRUE, recursive = TRUE)
  # Simple exclusion using basename comparison
  all_files <- all_files[!grepl(paste0("/", inbound_path, "/"), all_files, fixed = TRUE)]
  
  overlaps <- character(0)
  
  for (inbound_file in inbound_files) {
    inbound_basename <- basename(inbound_file)
    
    # Find matching basenames in project
    matching_files <- all_files[basename(all_files) == inbound_basename]
    
    if (length(matching_files) > 0) {
      for (match in matching_files) {
        # Get relative path by removing base_path prefix
        relative_path <- gsub(paste0("^", base_path, "/"), "", match)
        overlap_msg <- sprintf("Overlapping code: %s is also present in %s", inbound_basename, relative_path)
        overlaps <- c(overlaps, overlap_msg)
      }
    }
  }
  
  return(overlaps)
}
