
# ---------------------------------------------- # 
#         Data cleaning - Data quality 
# ---------------------------------------------- # 

# Packages ---------------------------------------

library(dplyr)
library(ggplot2)
library(lubridate)


# Cleaning ---------------------------------------

# Importing clean dataset (general)

df <- readRDS("D:/_main/data/treated_data/FCT_general_clean.rds")

# Create additional flags (for data_quality_check 1. and 2.)

# Define group of interest for quality checks
unit_cols <- c('grupo_id', 'adm_id', 'cota_id', 'date_adesao_str')

# Create all flags needed for quality analysis
df <- df %>%
  # Flag for quarter_adesao==quarter_min
  group_by(across(all_of(unit_cols))) %>%
  mutate(
    earliest_date = min(date_base, na.rm = TRUE),
    quarter_min = quarter(earliest_date),
    year_min = year(earliest_date)
  ) %>%
  ungroup() %>%
  mutate(
    quarter_adesao = quarter(date_adesao),
    adesao_min_flag = ifelse(
      (quarter_adesao == quarter_min) & (year_adesao == year_min), 
      1, 0
    ),
    # Flag for quarter_contemp==quarter
    quarter_contemp = quarter(date_contemp),
    year_contemp = year(date_contemp),
    contemp_in_quarter = ifelse(
      (quarter_contemp == quarter) & (year_contemp == year), 
      1, 0
    )
  )

# Create cancellation flag and merge back
cancel_flag_df <- df %>%
  group_by(across(all_of(unit_cols))) %>%
  summarise(
    flag_date_cancel = ifelse(any(!is.na(date_cancel)), 1, 0),
    .groups = 'drop'
  )

df <- df %>%
  left_join(cancel_flag_df, by = unit_cols)

# Create bins within segment (for data_quality_check 3.)

df <- df %>%
  group_by(codigo_seg) %>%
  mutate(
    dec_val  = ntile(valor_bem, 10),  # deciles of value
    quin_dur = ntile(prazo, 5)        # quintiles of duration
  ) %>%
  ungroup()


# Exporting to .rds and .csv ------------------------------

saveRDS(df, "D:/_main/data/treated_data/FCT_data_quality_clean.rds")
write.csv(df, "D:/_main/data/treated_data/FCT_data_quality_clean.csv", row.names = FALSE)

