SELECT
    dac_dt_base,
    COUNT(*) AS total_rows,
    COUNT(CASE WHEN CPF IS NULL THEN 1 END) AS cpf_nulls,
    COUNT(CASE WHEN CPF IS NOT NULL THEN 1 END) AS cpf_non_nulls
FROM sagdwpro_acc.sagtb_fct_fato_cota
-- WHERE dac_dt_base in ('20240330')
GROUP BY dac_dt_base
ORDER BY dac_dt_base;
