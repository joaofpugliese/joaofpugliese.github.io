-- Sample ~1% of groups from sagtb_flc_fato_lance for a specific date
-- Grouped by group, adm, and segment

WITH sampling_frame AS (
    SELECT
        adm_cd,
        gai_cd_grupo,
        fct_cd_seg,
        COUNT(*) as n_records  -- Optional: see how many records per group
    FROM sagdwpro_acc.sagtb_flc_fato_lance
    WHERE 1=1
        AND dac_dt_base = '20190930'  -- Fixed date
        AND fct_cd_seg IN (11, 31, 41)  -- Same segments as your previous query
    GROUP BY adm_cd, gai_cd_grupo, fct_cd_seg
),

-- Add random percentage and filter for ~1% sample
sample_generator AS (
    SELECT
        adm_cd,
        gai_cd_grupo,
        fct_cd_seg,
        n_records,
        rnd = RANDOM(0,100)
    FROM sampling_frame
),

sampled_groups AS(
    SELECT *
    FROM sample_generator
    WHERE rnd <= 1
)

-- Get the actual data for the sampled groups
SELECT
    FLC.*,
    -- Add other columns you need from sagtb_flc_fato_lance
    SG.n_records  -- Include group size for reference
FROM
    sagdwpro_acc.sagtb_flc_fato_lance FLC
INNER JOIN sampled_groups SG
    ON FLC.adm_cd = SG.adm_cd
    AND FLC.gai_cd_grupo = SG.gai_cd_grupo
    AND FLC.fct_cd_seg = SG.fct_cd_seg
WHERE
    FLC.dac_dt_base = '20190930'  -- Same date filter
ORDER BY 
    FLC.adm_cd, FLC.gai_cd_grupo, FLC.cot_cd_cota;
