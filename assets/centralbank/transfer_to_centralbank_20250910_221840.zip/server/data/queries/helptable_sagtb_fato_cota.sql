HELP TABLE sagdwpro_acc.sagtb_fct_fato_cota;

-- IF THIS DOESN'T WORK, CAN TRY:
-- SHOW TABLE sagdwpro_acc.sagtb_fct_fato_cota;