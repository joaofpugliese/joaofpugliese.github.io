WITH aleat AS (
    SELECT DISTINCT
           fct_cd_seg,
           adm_cd,
           gai_cd_grupo
    FROM sagdwpro_acc.sagtb_fct_fato_cota
    WHERE dac_dt_base IN (201212, 201512, 201812, 202112, 202412)   -- multiple periods
),
aaa AS (
    SELECT aleat.*,
           RANDOM(0,100) AS rnd
    FROM aleat
)
SELECT   fct.cot_cd_cota,
         fct.cot_cd_seq_cota,
         fct.fct_cd_seg,
         adm_cd2,       --anonimizado
         gai_cd_grupo2, --anonimizado
         cpf2           --anonimizado,
         /* Diagnostics over time (dac_dt_base) within the quota */
         count(*)                        AS n_rows ,
         count(DISTINCT fct.dac_dt_base) AS n_dates ,
         min(fct.dac_dt_base)            AS min_dac_dt_base ,
         max(fct.dac_dt_base)            AS max_dac_dt_base ,
         min(fct_dt_contemp)             AS fct_dt_contemp_min ,
         max(fct_dt_contemp)             AS fct_dt_contemp_max
         /* Numeric invariance checks (std dev across time) */
         ,
         max(cast(fct.fct_qt_dur_plano AS decimal(18,6))) AS max_sd_fct_qt_dur_plano ,
         max(cast(fct.fct_vl_bem AS       decimal(18,6))) AS max_sd_fct_vl_bem ,
         min(cast(fct.fct_qt_dur_plano AS decimal(18,6))) AS min_sd_fct_qt_dur_plano ,
         min(cast(fct.fct_vl_bem AS       decimal(18,6))) AS min_sd_fct_vl_bem
         /* Categorical invariance checks (distinct counts across time) */
         ,
         count(DISTINCT fct.fct_cd_tip_cotista) AS dcount_fct_cd_tip_cotista ,
         count(DISTINCT fct.fct_st_atual)       AS dcount_fct_st_atual ,
         count(DISTINCT fct.fct_ib_contemp)     AS dcount_fct_ib_contemp
         /* Optional: representative values for inspection (min/max) */
         ,
         min(fct.fct_qt_dur_plano)        AS min_fct_qt_dur_plano ,
         max(fct.fct_qt_dur_plano)        AS max_fct_qt_dur_plano ,
         min(fct.fct_vl_bem)              AS min_fct_vl_bem ,
         max(fct.fct_vl_bem)              AS max_fct_vl_bem ,
         min(fct.fct_cd_tip_cotista)      AS min_fct_cd_tip_cotista ,
         max(fct.fct_cd_tip_cotista)      AS max_fct_cd_tip_cotista ,
         min(fct.fct_st_atual)            AS min_fct_st_atual,
         max(fct.fct_st_atual)            AS max_fct_st_atual,
         min(fct.fct_ib_contemp)          AS min_fct_ib_contemp,
         max(fct.fct_ib_contemp)          AS max_fct_ib_contemp,
         max(fct.fct_pc_lance)	 	      AS max_fct_pc_lance,
         min(fct.fct_pc_lance)		      AS min_fct_pc_lance,
         max(fct.fct_dt_adesao)		      AS max_fct_pc_adesao,
         min(fct.fct_dt_adesao)		      AS min_fct_pc_adesao
FROM     sagdwpro_acc.sagtb_fct_fato_cota AS fct
JOIN     aaa
	ON       fct.fct_cd_seg=aaa.fct_cd_seg
	AND      fct.adm_cd=aaa.adm_cd
	AND      fct.gai_cd_grupo=aaa.gai_cd_grupo
WHERE    rnd <= 2
GROUP BY 1,
         2,
         3,
         4,
         5,
         6