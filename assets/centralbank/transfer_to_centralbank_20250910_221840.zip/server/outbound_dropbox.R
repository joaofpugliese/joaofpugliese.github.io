# Central Bank session completion script
# • Input: none (uses standard folder structure)
# • Output: timestamped zip with all code files and folder structure report
tryCatch({
# Load utilities
if(!grepl("centralbank", getwd())) {
  setwd("data/code/centralbank")
}

source("server/utils/outbound_packager.R") # Load utilities

# Define files/folders to exclude from transfer to Central Bank
exclude_from_transfer <- c(
  "inbound/",                    # Standard inbound folder  
  "outbound/",                   # Standard outbound folder
  "data/mock_data/",             # Mock data - should not be sent to CB
  ".Rhistory",                   # R session history
  ".RData",                      # R workspace data
  "temp_"                        # Any temporary files
)

cat("Files/folders excluded from Central Bank transfer:\n")
cat(paste("  -", exclude_from_transfer), sep = "\n")
cat("\n")

# Package session for outbound transfer
result <- package_outbound(
  base_path = "server",  # Package from server/ folder only
  outbound_path = "transfer_outbound",
  exclude_patterns = exclude_from_transfer
)

cat("\n=== SESSION LOGOUT COMPLETE ===\n")
if (!is.null(result)) {
  cat("Export ready for transfer:", basename(result), "\n")
} else {
  cat("Export failed - check logs above\n")
}

}, error = function(e) {
  cat("An error occurred:\n", conditionMessage(e), "\n")
})