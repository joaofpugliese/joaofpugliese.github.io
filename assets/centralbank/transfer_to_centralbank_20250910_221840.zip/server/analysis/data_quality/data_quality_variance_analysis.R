
# ---------------------------------------------- # 
#              Data Quality Check
# ---------------------------------------------- # 

# Packages ---------------------------------------

library(dplyr)
library(ggplot2)
library(lubridate)
library(fixest)


# Set paths, working directory and df ------------

data_path <- "D:/bases"
personal_path <- "C:/Users/depep.leonardozs/Documents/main"
import_path <- file.path(personal_path, "data", "treated_data")
results_path <- file.path(personal_path, "results", "graphs")

# Create results directory if it doesn't exist
if (!dir.exists(results_path)) {
  dir.create(results_path, recursive = TRUE)
}

# Importing dataset
filename <- file.path(import_path, "registro_cotas_clean.rds")
df <- readRDS(filename)


# 1. How does the share of units with date_adesao = earliest_date behave over time? -----

# Build plot for adesão min flag over time

unit_df <- df %>%
  arrange(year_adesao) %>%
  group_by(across(all_of(unit_cols))) %>%
  slice_head(n = 1) %>%
  ungroup()

summary_df <- unit_df %>%
  group_by(codigo_seg, year_adesao) %>%
  summarise(
    total_units = n(),
    adesao_flag_1 = sum(adesao_min_flag == 1, na.rm = TRUE),
    .groups = 'drop'
  ) %>%
  mutate(
    share_flag_1 = adesao_flag_1 / total_units
  )

# Plot it

codigo_segs <- unique(summary_df$codigo_seg)
figname <- file.path(results_path, "flag_adesao_first_obs.pdf")

plot1 <- ggplot(summary_df, aes(x = year_adesao, y = share_flag_1, color = factor(codigo_seg))) +
  geom_line(size = 1) +
  geom_point(size = 2) +
  labs(
    title = "Share of Units with adesao_min_flag == 1 Over Time",
    x = "Starting Year",
    y = "Share",
    color = "codigo_seg"
  ) +
  theme_classic() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1),
    panel.grid = element_line(color = "grey90"),
    legend.position = "bottom"
  ) +
  scale_x_continuous(breaks = scales::pretty_breaks(n = 8))

print(plot1)
ggsave(figname, plot1, width = 12, height = 6, units = "in")


# 2. " if we drop cancelled quotas ---------------

# Build plot for adesão min flag over time (no cancel)

unit_df_nocancel <- df %>%
  filter(flag_date_cancel == 0) %>%
  arrange(year_adesao) %>%
  group_by(across(all_of(unit_cols))) %>%
  slice_head(n = 1) %>%
  ungroup()

summary_df_nocancel <- unit_df_nocancel %>%
  group_by(codigo_seg, year_adesao) %>%
  summarise(
    total_units = n(),
    adesao_flag_1 = sum(adesao_min_flag == 1, na.rm = TRUE),
    .groups = 'drop'
  ) %>%
  mutate(
    share_flag_1 = adesao_flag_1 / total_units
  )

# Plot it (no cancel)

figname_nocancel <- file.path(results_path, "flag_adesao_first_obs_nocancel.pdf")

plot2 <- ggplot(summary_df_nocancel, aes(x = year_adesao, y = share_flag_1, color = factor(codigo_seg))) +
  geom_line(size = 1) +
  geom_point(size = 2) +
  labs(
    title = "Share of Units with adesao_min_flag == 1 Over Time (No Cancellations)",
    x = "Starting Year",
    y = "Share",
    color = "codigo_seg"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14),
    axis.text.x = element_text(angle = 45, hjust = 1),
    panel.grid = element_line(color = "grey90"),
    legend.position = "bottom"
  ) +
  scale_x_continuous(breaks = scales::pretty_breaks(n = 8))

print(plot2)
ggsave(figname_nocancel, plot2, width = 12, height = 6, units = "in")
 

# 3. Flag variability analysis ---------------

# One-at-a-time regressions, split by segment

m_val_g  <- feols(adesao_min_flag ~ i(dec_val, ref = 5) | grupo_id,
                  data = unit_df, split = ~ codigo_seg)
m_val_a  <- feols(adesao_min_flag ~ i(dec_val, ref = 5) | adm_id,
                  data = unit_df, split = ~ codigo_seg)
m_dur_g <- feols(adesao_min_flag ~ i(quin_dur, ref = 3) | grupo_id,
                  data = unit_df, split = ~ codigo_seg)
m_dur_a <- feols(adesao_min_flag ~ i(quin_dur, ref = 3) | adm_id,
                  data = unit_df, split = ~ codigo_seg)
m_g <- feols(adesao_min_flag ~ 1 | grupo_id,
                  data = unit_df, split = ~ codigo_seg)
m_a <- feols(adesao_min_flag ~ 1 | adm_id,
                  data = unit_df, split = ~ codigo_seg)
m_date_g <- feols(adesao_min_flag ~ 1 | grupo_id + earliest_date,
                     data = unit_df, split = ~ codigo_seg)
m_date_a <- feols(adesao_min_flag ~ 1 | adm_id + earliest_date,
                     data = unit_df, split = ~ codigo_seg)
m_date <- feols(adesao_min_flag ~ 1 | earliest_date,
                  data = unit_df, split = ~ codigo_seg)


# R² by segment 

r2_val_g  <- sapply(m_val_g, r2)
r2_val_a  <- sapply(m_val_a, r2)
r2_dur_g <- sapply(m_dur_g, r2)
r2_dur_a <- sapply(m_dur_a, r2)
r2_g <- sapply(m_g, r2)
r2_a <- sapply(m_a, r2)
r2_date_g <- sapply(m_date_g, r2)
r2_date_a <- sapply(m_date_a, r2)
r2_date <- sapply(m_date, r2)


extract_metrics <- function(r2_result, model_name) {
  metrics_df <- as.data.frame(t(r2_result))
  metrics_df$Model <- model_name
  metrics_df$Segment <- rownames(metrics_df)
  rownames(metrics_df) <- NULL
  return(metrics_df)
}

metrics_val_g <- extract_metrics(r2_val_g, "Value_Group")
metrics_val_a <- extract_metrics(r2_val_a, "Value_Admin")
metrics_dur_g <- extract_metrics(r2_dur_g, "Duration_Group")
metrics_dur_a <- extract_metrics(r2_dur_a, "Duration_Admin")
metrics_g <- extract_metrics(r2_g, "Nothing_Group")
metrics_a <- extract_metrics(r2_a, "Nothing_Admin")
metrics_date_g <- extract_metrics(r2_date_g, "Date_Group")
metrics_date_a <- extract_metrics(r2_date_a, "Date_Admin")
metrics_date <- extract_metrics(r2_date, "Date")

r2_summary <- rbind(metrics_val_g, metrics_val_a, 
                    metrics_dur_g, metrics_dur_a, 
                    metrics_g, metrics_a,
                    metrics_date_g, metrics_date_a,
                    metrics_date)
r2_summary <- r2_summary[, c("Model", "Segment", setdiff(names(r2_summary), c("Model", "Segment")))] %>% 
  select(Model, Segment, r2)

r2_summary %>% 
  capture.output() %>% 
  writeLines(., file.path(import_path, "regressions_rsquared.txt"))

# Coefficients for the first few regressions

summary(m_val_g) %>% 
  capture.output() %>% 
  writeLines(., file.path(import_path, "regressions_val.txt"))
  
summary(m_dur_g) %>% 
  capture.output() %>% 
  writeLines(., file.path(import_path, "regressions_dur.txt"))

  

# Export summary data ----------------------------

outfile_summary_csv <- file.path(import_path, "flag_variability_analysis.csv")
write.csv(list(summary_df, summary_df_nocancel), outfile_summary_csv, row.names = FALSE)

outfile_r2 <- file.path(import_path, "flag_variability_r2_summary.csv")
write.csv(r2_summary, outfile_r2, row.names = FALSE)