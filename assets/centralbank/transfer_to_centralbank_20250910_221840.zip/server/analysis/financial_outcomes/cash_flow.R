
# ---------------------------------------------- # 
#               Cash Flow Analysis
# ---------------------------------------------- # 

# Packages ---------------------------------------

library(dplyr)
library(ggplot2)
library(lubridate)

# Set paths and working directory ----------------

data_path <- "D:/bases"
personal_path <- "C:/Users/depep.leonardozs/Documents/main"
export_path <- file.path(personal_path, "data", "treated_data")

# Importing clean dataset ------------------------------

filename <- file.path(export_path, "FCT_financial_outcomes_clean.rds")
base <- readRDS(filename)

#%% Analysis: Collapse to group level for analysis ------------------------
group_df <- base %>% 
  group_by(adm_id, grupo_id, cota_id, cpf_fake_id) %>%
  summarise(
    npv = mean(npv, na.rm = TRUE),
    renda_cotista = mean(renda_cotista, na.rm = TRUE),
    credit_contemp = mean(credit_contemp, na.rm = TRUE),
    n_npv = mean(n_npv, na.rm = TRUE),
    renda_cotista_log = mean(renda_cotista_log, na.rm = TRUE),
    .groups = 'drop'
  ) %>%
  filter(npv < 0)

#%% Plot results -----------------------------------
plot_npv <- ggplot(group_df, aes(x = renda_cotista_log, y = n_npv)) +
  geom_point(color = "blue", alpha = 0.6) +
  labs(
    x = "Renda Cotista (log)",
    y = "NPV Normalizado",
    title = "NPV vs Renda do Cotista"
  ) +
  theme_minimal() +
  theme(
    panel.grid = element_line(color = "grey90"),
    plot.title = element_text(hjust = 0.5)
  )

print(plot_npv)

#%% Export results ---------------------------------
outfile_rds <- file.path(export_path, "cash_flow_analysis.rds")
saveRDS(group_df, outfile_rds)

outfile_csv <- file.path(export_path, "cash_flow_analysis.csv")
write.csv(group_df, outfile_csv, row.names = FALSE)
