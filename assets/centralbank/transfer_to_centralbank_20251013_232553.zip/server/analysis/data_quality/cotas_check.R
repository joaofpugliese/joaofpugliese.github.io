# ---------------------------------------------- # 
#          COTA Check - Invariant Flag Analysis
# ---------------------------------------------- # 
#
# Simple check of invariant flags in contemplacoes dataset
# Focus: observations with variance in contemplation dates or lance percentages
# ---------------------------------------------- #

# Packages ---------------------------------------
library(data.table)

#%% Load contemplacoes dataset ---------------------
if(grepl("Dropbox", getwd())) {
  df <- readRDS("data/code/centralbank/server/data/output/contemplacoes_cota_level.rds")
} else {
  df <- readRDS("D:/server/data/output/contemplacoes_cota_level.rds")
}

# Convert to data.table
setDT(df)

#%% Invariant flag counts --------------------------
target_count <- sum(df$invariant_perc_lance == 0 | df$invariant_dt_contemp == 0)

cat("=== INVARIANT FLAG COUNTS ===
Number of prazo not matching:", sum(df$invariant_prazo == 0), "out of", nrow(df), "
Number of valor_bem not matching:", sum(df$invariant_valor_bem == 0), "out of", nrow(df), "
Number of tip_cotista not matching:", sum(df$invariant_tip_cotista == 0), "out of", nrow(df), "
Number of status not matching:", sum(df$invariant_status == 0), "out of", nrow(df), "
Number of allocation not matching:", sum(df$invariant_allocation == 0), "out of", nrow(df), "
Number of dt_adesao not matching:", sum(df$invariant_dt_adesao == 0), "out of", nrow(df), "
Number of perc_lance not matching:", sum(df$invariant_perc_lance == 0), "out of", nrow(df), "
Number of dt_contemp not matching:", sum(df$invariant_dt_contemp == 0), "out of", nrow(df), "

Target subset (perc_lance OR dt_contemp variance):", target_count, "out of", nrow(df), "
")

#%% Merge with FCT panel -------------------------

# Create subset of contemplacoes with variance
df_variant <- df[invariant_perc_lance == 1 | invariant_dt_contemp == 0]

# Remove full dataset
rm(df)
gc()

# Ensure keys exist and types match
join_cols <- c("grupo_id", "adm_id", "cpf_id", "codigo_seg", "cota_id", "cota_sub_id")

# Load FCT panel dataset
if(grepl("Dropbox", getwd())) {
  fct_panel <- fread("data/code/centralbank/server/data/output/clean_FCT_panel.csv", 
                     showProgress = TRUE)
} else {
  fct_panel <- fread("D:/server/data/output/clean_FCT_panel.csv", 
                     showProgress = TRUE)
}

# Convert to data.table
setDT(fct_panel)

# Optional but good: set keys for faster join
setkeyv(fct_panel, join_cols)
setkeyv(df_variant, join_cols)

# Optional: reduce size of fct_panel by pre-filtering (only relevant rows)
# This creates a vector of unique combinations that appear in df_variant
filter_keys <- unique(df_variant[, ..join_cols])
fct_panel_filtered <- fct_panel[filter_keys, nomatch = 0]

# Merge only the needed rows
merged_df <- merge(df_variant, fct_panel_filtered, 
                   by = join_cols, all.x = TRUE)


cat("Merge completed:
Original contemplacoes variant subset:", nrow(df_variant), "
Merged dataset rows:", nrow(merged_df), "
Match rate:", round(nrow(merged_df)/nrow(df_variant), 2), "%")

