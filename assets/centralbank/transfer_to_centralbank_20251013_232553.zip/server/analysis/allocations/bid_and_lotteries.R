# ---------------------------------------------- # 
#            Bid and Lotteries Analysis
# ---------------------------------------------- # 

# Packages ---------------------------------------

library(dplyr)
library(ggplot2)
library(lubridate)
library(tidyr)
library(ggplot2)
library(RColorBrewer)


# Importing dataset

# Use fread for faster file reading (header = TRUE is default)
# Add grepl to check if the working directory is Dropbox (outside server) or not
if(grepl("Dropbox", getwd())) {
  df <- readRDS("data/code/centralbank/server/data/output/contemplacoes_cota_level.rds")
} else {
  df <- fread("D:/server/data/output/contemplacoes_cota_level.csv", stringsAsFactors = FALSE, showProgress = TRUE)
}

# 0. Criando um df a nível de grupo-data relativa (mover para cleaning depois) ---------------------

group_df <- df %>% 
  filter(!is.na(date_contemp)) %>% 
  group_by(codigo_seg, grupo_id) %>% 
  mutate(
    total_cotas_grupo = n(),
    min_date_grupo = as.Date(min(date_contemp)),
    prazo_max = round(max(max_prazo)),
    max_date_grupo = max(min_date_grupo + months(prazo_max), as.Date(max(date_contemp))),
    max_date_grupo_1 = min_date_grupo + months(prazo_max),
    max_date_grupo_2 = as.Date(max(date_contemp)),
    #max_date_grupo = as.Date(max(date_contemp)),
    date_contemp = as.Date(date_contemp),
    # Calcular posição temporal normalizada (0 = início, 1 = fim do grupo)
    tempo_normalizado = as.numeric(date_contemp - min_date_grupo) / as.numeric(max_date_grupo - min_date_grupo),
    periodo_5pct = floor(tempo_normalizado * 20) / 20
  ) %>% 
  ungroup() %>% 
  group_by(codigo_seg, grupo_id, periodo_5pct) %>%
  summarise(
    total_cotas_grupo = first(total_cotas_grupo),
    min_date_grupo = first(min_date_grupo),
    max_date_grupo = first(max_date_grupo),
    max_date_grupo_1 = first(max_date_grupo_1),
    max_date_grupo_2 = first(max_date_grupo_2),
    cotas_contempladas_periodo = n(),
    cotas_lance_periodo = sum(allocation_type == "L"),
    cotas_sorteio_periodo = sum(allocation_type == "S"),
    .groups = "drop"
  ) %>%
  arrange(codigo_seg, grupo_id, periodo_5pct) %>%
  group_by(codigo_seg, grupo_id) %>%
  mutate(
    cotas_contempladas_acum = cumsum(cotas_contempladas_periodo),
    cotas_lance_acum = cumsum(cotas_lance_periodo),
    cotas_sorteio_acum = cumsum(cotas_sorteio_periodo),
    pct_contempladas_acum = round(cotas_contempladas_acum / total_cotas_grupo * 100, 1),
    pct_lance_acum = round(cotas_lance_acum / cotas_contempladas_acum * 100, 1),
    pct_sorteio_acum = round(cotas_sorteio_acum / cotas_contempladas_acum * 100, 1)
  ) %>%
  ungroup()

group_df1 <- df %>% 
  filter(!is.na(date_contemp)) %>% 
  group_by(codigo_seg, grupo_id) %>% 
  mutate(
    total_cotas_grupo = n(),
    min_date_grupo = as.Date(min(date_contemp)),
    prazo_max = round(max(max_prazo)),
    max_date_grupo = max(min_date_grupo + months(prazo_max), as.Date(max(date_contemp))),
    max_date_grupo_1 = min_date_grupo + months(prazo_max),
    max_date_grupo_2 = as.Date(max(date_contemp)),
    #max_date_grupo = as.Date(max(date_contemp)),
    date_contemp = as.Date(date_contemp),
    # Calcular posição temporal normalizada (0 = início, 1 = fim do grupo)
    tempo_normalizado = as.numeric(date_contemp - min_date_grupo) / as.numeric(max_date_grupo_1 - min_date_grupo),
    periodo_5pct = floor(tempo_normalizado * 20) / 20
  ) %>% 
  ungroup() %>% 
  group_by(codigo_seg, grupo_id, periodo_5pct) %>%
  summarise(
    total_cotas_grupo = first(total_cotas_grupo),
    min_date_grupo = first(min_date_grupo),
    max_date_grupo = first(max_date_grupo),
    max_date_grupo_1 = first(max_date_grupo_1),
    max_date_grupo_2 = first(max_date_grupo_2),
    cotas_contempladas_periodo = n(),
    cotas_lance_periodo = sum(allocation_type == "L"),
    cotas_sorteio_periodo = sum(allocation_type == "S"),
    .groups = "drop"
  ) %>%
  arrange(codigo_seg, grupo_id, periodo_5pct) %>%
  group_by(codigo_seg, grupo_id) %>%
  mutate(
    cotas_contempladas_acum = cumsum(cotas_contempladas_periodo),
    cotas_lance_acum = cumsum(cotas_lance_periodo),
    cotas_sorteio_acum = cumsum(cotas_sorteio_periodo),
    pct_contempladas_acum = round(cotas_contempladas_acum / total_cotas_grupo * 100, 1),
    pct_lance_acum = round(cotas_lance_acum / cotas_contempladas_acum * 100, 1),
    pct_sorteio_acum = round(cotas_sorteio_acum / cotas_contempladas_acum * 100, 1)
  ) %>%
  ungroup()


# Ver observações com periodo de contemplação maior do que 100%

group_df %>% filter(periodo_5pct > 1) %>% View()

# Presença de diferentes valores de prazo dentro de um mesmo grupo

df %>% 
  group_by(grupo_id) %>% 
  summarise(flag_prazo = n_distinct(max_prazo), n = n(), f = flag_prazo / n) %>% 
  summary()

# Verificando coincidência das duas formas de calcular a data final

df_date_dif <- group_df %>% 
  filter(periodo_5pct >= 0.9 & periodo_5pct <= 1.1) %>% 
  mutate(date_dif = as.numeric(max_date_grupo_2 - max_date_grupo_1) / 30.44) %>% 
  filter(date_dif >= -12 & date_dif <= 12)

df_date_dif %>% 
  ggplot(aes(x = date_dif)) +
  geom_histogram(binwidth = 1, fill = "skyblue", color = "white") +
  labs(title = paste("Diferença entre métodos max contemp vs min contemp + prazo. Bin = 1 mês, n =", nrow(df_date_dif)),
       x = "Diferença (em dias)",
       y = "Frequência")

# Pouquíssimas amostras. Como é a distribuição de data final de grupo?

# max entre dois métodos
group_df %>% 
  group_by(grupo_id) %>% 
  summarize(final_period = max(periodo_5pct)) %>% 
  ggplot(aes(x = final_period)) +
  geom_histogram(binwidth = 0.05, fill = "skyblue", color = "white") +
  labs(title = "Distribuição de periodo_5pct final (max entre dois métodos)",
       x = "Diferença (em dias)",
       y = "Frequência")

# método max min contemp + prazo
group_df1 %>% 
  group_by(grupo_id) %>% 
  summarize(final_period = max(periodo_5pct)) %>% 
  ggplot(aes(x = final_period)) +
  geom_histogram(binwidth = 0.05, fill = "skyblue", color = "white") +
  labs(title = "Distribuição de periodo_5pct final (método max min contemp + prazo)",
       x = "Diferença (em dias)",
       y = "Frequência")


# 1. Análise a nível de grupo ---------------

# Evolução do grupo - Acumulado

plot_group_evolution <- function(selected_segment, selected_group){
  
  plot_group_evolution <- group_df %>%
    filter(codigo_seg == selected_segment &
           grupo_id == selected_group) %>%
    ggplot(aes(x = periodo_5pct)) +
    geom_hline(aes(yintercept = total_cotas_grupo), linetype = "dashed", color = "black", linewidth = 1) +
    geom_line(aes(y = cotas_contempladas_acum, color = "Total Contempladas"), linewidth = 1) +
    geom_line(aes(y = cotas_lance_acum, color = "Lance"), linewidth = 1) +
    geom_line(aes(y = cotas_sorteio_acum, color = "Sorteio"), linewidth = 1) +
    labs(
      title = paste("Grupo", selected_group, "- Evolução das Contemplações ao Longo do Tempo"),
      x = "Data",
      y = "Número de Cotas",
      color = "Tipo"
    ) +
    theme_bw() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 14),
      axis.text.x = element_text(angle = 45, hjust = 1),
      legend.position = "bottom"
    ) +
    scale_y_continuous(breaks = scales::pretty_breaks(n = 6)) +
    scale_color_manual(values = c("Total Contempladas" = "black", "Lance" = "blue", "Sorteio" = "red"))
  
  return(plot_group_evolution)
}

plot_group_evolution("SEG1", 5)

# Evolução do grupo - Fluxo

plot_group_flow <- function(selected_segment, selected_group){
  
  plot_group_flow <- group_df %>%
    filter(codigo_seg == selected_segment &
           grupo_id == selected_group)  %>%
    pivot_longer(
      cols = c(cotas_lance_periodo, cotas_sorteio_periodo),
      names_to = "tipo",
      values_to = "cotas"
    ) %>%
    mutate(
      tipo = case_when(
        tipo == "cotas_lance_periodo" ~ "Lance",
        tipo == "cotas_sorteio_periodo" ~ "Sorteio"
      )
    ) %>%
    ggplot(aes(x = periodo_5pct, y = cotas, fill = tipo)) +
    geom_col() +
    labs(
      title = paste("Grupo", selected_group, "- Fluxo de Contemplações por Período"),
      x = "Data",
      y = "Número de Cotas (por período)",
      fill = "Tipo"
    ) +
    theme_bw() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 14),
      axis.text.x = element_text(angle = 45, hjust = 1),
      legend.position = "bottom"
    ) +
    scale_y_continuous(breaks = scales::pretty_breaks(n = 6)) +
    scale_fill_manual(values = c("Lance" = "blue", "Sorteio" = "darkred"))
  
  return(plot_group_flow)
  
}

plot_group_flow("SEG1", 5)


# 2. Análise a nível de segmento ---------------

data = group_df
selected_segment = "SEG1"
start_year = NULL
end_year = NULL

# Função para filtrar o df por segmento e intervalo de anos

filter_group_df <- function(data, selected_segment, start_year = NULL, end_year = NULL) {
  
  # Primeiro filtrar por segmento
  filtered <- data %>%
    filter(codigo_seg == selected_segment)
  
  # Aplicar filtros de ano condicionalmente
  if (!is.null(start_year)) {
    filtered <- filtered %>%
      filter(year(min_date_grupo) >= start_year)
  }
  
  if (!is.null(end_year)) {
    filtered <- filtered %>%
      filter(year(min_date_grupo) <= end_year)
  }
  
  filtered <- filtered %>% 
  mutate(
    total_cotas_segmento = sum(distinct(., grupo_id, total_cotas_grupo)$total_cotas_grupo),
    n_grupos = n_distinct(grupo_id)
  ) %>% 
  group_by(periodo_5pct) %>% 
  summarise(
    total_cotas_segmento = first(total_cotas_segmento),
    n_grupos = first(n_grupos),
    cotas_contempladas_periodo = sum(cotas_contempladas_periodo),
    cotas_lance_periodo = sum(cotas_lance_periodo),
    cotas_sorteio_periodo = sum(cotas_sorteio_periodo),
    .groups = "drop"
  ) %>%
  arrange(periodo_5pct) %>%
  mutate(
    cotas_contempladas_acum = cumsum(cotas_contempladas_periodo),
    cotas_lance_acum = cumsum(cotas_lance_periodo),
    cotas_sorteio_acum = cumsum(cotas_sorteio_periodo),
    pct_lance_acum = round(cotas_lance_acum / cotas_contempladas_acum * 100, 1),
    pct_sorteio_acum = round(cotas_sorteio_acum / cotas_contempladas_acum * 100, 1)
  ) %>% 
  ungroup()

return(filtered)
}

# test <- filter_group_df(group_df, "SEG1", 2020)

## Evolução do segmento - Acumulado

plot_segment_evolution <- function(segment_data, selected_segment = "Segmento"){
  
  plot_segment_evolution <- segment_data %>%
    ggplot(aes(x = periodo_5pct)) +
    geom_hline(aes(yintercept = total_cotas_segmento), linetype = "dashed", color = "black", linewidth = 1) +
    geom_line(aes(y = cotas_contempladas_acum, color = "Total Contempladas"), linewidth = 1) +
    geom_line(aes(y = cotas_lance_acum, color = "Lance"), linewidth = 1) +
    geom_line(aes(y = cotas_sorteio_acum, color = "Sorteio"), linewidth = 1) +
    labs(
      title = paste("Segmento", selected_segment, "- Evolução das Contemplações"),
      x = "Tempo de Vida do Grupo (0 = Início, 1 = Final)",
      y = "Número de Cotas",
      color = "Tipo"
    ) +
    theme_bw() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 14),
      axis.text.x = element_text(angle = 45, hjust = 1),
      legend.position = "bottom"
    ) +
    scale_y_continuous(breaks = scales::pretty_breaks(n = 6)) +
    scale_x_continuous(breaks = seq(0, 1, 0.1), labels = scales::percent_format()) +
    scale_color_manual(values = c("Total Contempladas" = "black", "Lance" = "blue", "Sorteio" = "red"))
  
  return(plot_segment_evolution)
  
}

# plot_segment_evolution(test)

## Evolução do segmento - Fluxo

plot_segment_flow <- function(segment_data, selected_segment = "Segmento"){
  
  plot_segment_flow <- segment_data %>%
    pivot_longer(
      cols = c(cotas_lance_periodo, cotas_sorteio_periodo),
      names_to = "tipo",
      values_to = "cotas"
    ) %>%
    mutate(
      tipo = case_when(
        tipo == "cotas_lance_periodo" ~ "Lance",
        tipo == "cotas_sorteio_periodo" ~ "Sorteio"
      )
    ) %>%
    ggplot(aes(x = periodo_5pct, y = cotas, fill = tipo)) +
    geom_col() +
    labs(
      title = paste("Segmento", selected_segment, "- Fluxo de Contemplações por Período"),
      x = "Tempo de Vida do Grupo (0 = Início, 1 = Final)",
      y = "Número de Cotas (por período)",
      fill = "Tipo"
    ) +
    theme_bw() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 14),
      axis.text.x = element_text(angle = 45, hjust = 1),
      legend.position = "bottom"
    ) +
    scale_y_continuous(breaks = scales::pretty_breaks(n = 6)) +
    scale_x_continuous(breaks = seq(0, 1, 0.1), labels = scales::percent_format()) +
    scale_fill_manual(values = c("Lance" = "blue", "Sorteio" = "darkred"))
  
  return(plot_segment_flow)
  
}

## plot_segment_flow(test)

# Gráfico comparativo: % de contemplações por lance para todos os segmentos

plot_segments_lance_comparison <- function(data, start_year = NULL, end_year = NULL) {
  
  # Criar dados agregados para todos os segmentos
  segments_list <- unique(data$codigo_seg)
  segments_data <- do.call(rbind, lapply(segments_list, function(seg) {
    result <- filter_group_df(data, seg, start_year, end_year)
    result$codigo_seg <- seg
    return(result)
  }))
  
  # Criar título baseado nos parâmetros
  period_text <- ""
  if (!is.null(start_year) & !is.null(end_year)) {
    period_text <- paste(" (", start_year, "-", end_year, ")")
  } else if (!is.null(start_year)) {
    period_text <- paste(" (a partir de", start_year, ")")
  } else if (!is.null(end_year)) {
    period_text <- paste(" (até", end_year, ")")
  } else {
    period_text <- " (período completo)"
  }
  
  plot_comparison <- segments_data %>%
    ggplot(aes(x = periodo_5pct, y = pct_lance_acum, color = as.factor(codigo_seg))) +
    geom_line(linewidth = 1.2) +
    labs(
      title = paste("Comparação entre Segmentos: % de Cotas Contempladas por Lance", period_text),
      x = "Tempo de Vida do Grupo (0 = Início, 1 = Final)",
      y = "% de Cotas Contempladas por Lance",
      color = "Segmento"
    ) +
    theme_bw() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 14),
      axis.text.x = element_text(angle = 45, hjust = 1),
      legend.position = "bottom"
    ) +
    scale_y_continuous(breaks = scales::pretty_breaks(n = 6), limits = c(0, 100)) +
    scale_x_continuous(breaks = seq(0, 1, 0.1), labels = scales::percent_format()) +
    scale_color_manual(values = colorRampPalette(RColorBrewer::brewer.pal(9, "Set1"))(length(unique(segments_data$codigo_seg))))
  
  return(plot_comparison)
}

## plot_segments_lance_comparison(group_df, 2020, 2023)

# Salvando os gráficos -----------------------------------------------------------------------------

# Criar diretório se não existir
output_dir <- ifelse(grepl("Dropbox", getwd()), 
                     "analysis/allocations/plots/", 
                     "D:/server/data/output/graficos_allocation/")

if (!dir.exists(output_dir)) {
  dir.create(output_dir, recursive = TRUE)
}

# 1. Exemplos de gráficos individuais de grupo
ggsave(paste0(output_dir, "plot_group_evolution_SEG21_G1.png"), 
       plot_group_evolution("SEG21", 1), width = 10, height = 6, dpi = 300)

ggsave(paste0(output_dir, "plot_group_flow_SEG21_G1.png"), 
       plot_group_flow("SEG21", 1), width = 10, height = 6, dpi = 300)

# 2. Comparação entre todos os segmentos (período completo)
ggsave(paste0(output_dir, "plot_segments_comparison_full.png"), 
       plot_segments_lance_comparison(group_df, start_year = 1900), width = 12, height = 8, dpi = 300)

# 3. Gráficos Flow - SEG1, SEG2, SEG3 (período completo)
flow_segments <- c("11", "31", "41")

for(seg in flow_segments) {
  # Filtrar dados do segmento
  segment_data <- filter_group_df(group_df, seg)
  
  # Salvar o dataframe usado
  saveRDS(segment_data, paste0(output_dir, "data_segment_flow_", seg, "_full.rds"))
  
  # Flow plot
  ggsave(paste0(output_dir, "plot_segment_flow_", seg, "_full.png"), 
         plot_segment_flow(segment_data, seg), width = 10, height = 6, dpi = 300)
}

# 4. Gráficos Evolution - Produto cartesiano de segmentos e anos
evolution_segments <- c("11", "31", "41")
evolution_years <- seq(2005, 2023, by = 2)

# Criar produto cartesiano
evolution_combinations <- expand.grid(segment = evolution_segments, 
                                    year = evolution_years, 
                                    stringsAsFactors = FALSE)

# Aplicar função para cada combinação
apply(evolution_combinations, 1, function(row) {
  seg <- row["segment"]
  year <- as.numeric(row["year"])
  
  # Filtrar dados do segmento e ano
  segment_data <- filter_group_df(group_df, seg, start_year = year)
  
  # Salvar o dataframe usado
  saveRDS(segment_data, paste0(output_dir, "data_segment_evolution_", seg, "_", year, ".rds"))
  
  # Evolution plot
  ggsave(paste0(output_dir, "plot_segment_evolution_", seg, "_", year, ".png"), 
         plot_segment_evolution(segment_data, seg), width = 10, height = 6, dpi = 300)
})

cat("Gráficos salvos em:", output_dir, "\n")