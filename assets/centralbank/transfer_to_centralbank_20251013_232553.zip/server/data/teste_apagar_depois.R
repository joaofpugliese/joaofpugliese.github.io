# Criar coluna com quantidade de subsequências por cota
df[, n_subseq := uniqueN(cota_sub_id), by = .(codigo_seg, adm_id, grupo_id, cota_id)]

# Verificar distribuição de CPFs nas cotas com única subsequência
distribuicao_cpfs <- df[n_subseq == 1] %>%
  group_by(codigo_seg, adm_id, grupo_id, cota_id) %>%
  summarise(n_cpfs = n_distinct(cpf_id), .groups = "drop") %>%
  count(n_cpfs, name = "freq_cotas") %>%
  mutate(pct = round(freq_cotas/sum(freq_cotas)*100, 2))

print(distribuicao_cpfs)

# Criar variável safe: 1 se cota tem única subsequência E único CPF
df[, safe := fifelse(
  n_subseq == 1 & 
  uniqueN(cpf_id) == 1, 
  1, 0
), by = .(codigo_seg, adm_id, grupo_id, cota_id)]

# Calcular porcentagem de cotas safe do total
safe_summary <- df[, .(
  total_cotas = uniqueN(paste(codigo_seg, adm_id, grupo_id, cota_id)),
  safe_cotas = uniqueN(paste(codigo_seg, adm_id, grupo_id, cota_id)[safe == 1])
)]

safe_summary[, pct_safe := round(safe_cotas/total_cotas*100, 2)]

cat("\nSafe quotas summary:\n")
cat("Total unique quotas:", safe_summary$total_cotas, "\n")
cat("Safe quotas (single sub_id + single CPF):", safe_summary$safe_cotas, "\n")
cat("Percentage of safe quotas:", safe_summary$pct_safe, "%\n")

# Análise de distribuição de subsequências por cota
distribuicao_subseq <- df %>%
  group_by(codigo_seg, adm_id, grupo_id, cota_id) %>%
  summarise(n_subseq = n_distinct(cota_sub_id), .groups = "drop") %>%
  count(n_subseq, name = "freq_cotas") %>%
  mutate(pct = round(freq_cotas/sum(freq_cotas)*100, 2))

print(distribuicao_subseq)