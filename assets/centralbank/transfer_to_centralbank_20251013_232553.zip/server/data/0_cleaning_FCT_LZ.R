# ---------------------------------------------- # 
#          Data cleaning - General (Optimized for 4M+ observations)
# ---------------------------------------------- #
#
# Performance optimizations implemented:
# - data.table for faster operations (vs dplyr)
# - fread() for faster file import (vs read.delim)
# - Combined operations with := for modify-by-reference
# - Efficient date parsing and calculations
# - fcase() and fifelse() for faster conditionals
# - Early memory cleanup and garbage collection
# - fwrite() for faster CSV export
#
# Additional tips for very large datasets:
# - Consider reading in chunks if memory is limited
# - Use setkey() for indexed operations if doing joins/merges
# - Monitor memory usage with gc() and object.size()
# ---------------------------------------------- #

# Packages ---------------------------------------

library(data.table)
library(dplyr)
library(lubridate)

# Starting block run (if error, stop the script)
# Use fread for faster file reading (header = TRUE is default)
if(grepl("Project", getwd())) {
  df <- fread("data/code/centralbank/server/data/mock_data/mock_FCT_data.csv", header = FALSE, stringsAsFactors = FALSE, showProgress = TRUE)
  source("data/code/centralbank/server/utils/data_description.R")
} else {
  df <- fread("D:/bases/cotas_16092025v2.txt", header = FALSE, stringsAsFactors = FALSE, showProgress = TRUE)
  source("D:/server/utils/data_description.R")
}

# Set column names and remove header row
setnames(df, as.character(df[1,]))
df <- df[-1,]

# Data cleaning ----------------------------------

# Convert to data.table for faster operations
setDT(df)

# Transform column names to lowercase
setnames(df, tolower(names(df)))

# Combined operations using data.table's modify-by-reference for efficiency
df[, `:=`(
  # Date extraction
  year = as.numeric(substr(dac_dt_base, 1, 4)),
  month = as.numeric(substr(dac_dt_base, 5, 6)),
  
  # Token processing - more efficient factor conversion
  codigo_seg = fct_cd_seg,
  adm_id = as.integer(as.factor(adm_cd2)),
  grupo_id = as.integer(as.factor(gai_cd_grupo2)),
  cota_id = as.integer(as.factor(cot_cd_cota2)),
  cota_sub_id = cot_cd_seq_cota,
  cpf_id = as.integer(as.factor(cpf2))
)]

# Create composite ID after other columns exist
df[, cota_full_id := paste(cota_id, cota_sub_id, sep = "-")]

# Treat dates - optimized for large datasets
df[, `:=`(
  # Fast date conversion using data.table
  date_cancel = as.Date(fct_dt_can_cota, format = "%Y-%m-%d"),
  date_contemp = as.Date(fct_dt_contemp, format = "%Y-%m-%d"),
  date_adesao = as.Date(fct_dt_adesao, format = "%Y-%m-%d"),
  
  # Efficient date_base calculation
  date_base = as.Date(paste0(year, "-", month, "-01")) + months(1) - days(1)
)]

# Add quarter after date_base is created
df[, quarter := quarter(date_base)]

# Clean up intermediate and original raw columns efficiently
cols_to_remove <- c("fct_dt_can_cota", "fct_dt_contemp", 
                    "fct_dt_adesao", "dac_dt_base", 
                    "cot_cd_cota2", "cot_cd_seq_cota")
df[, (cols_to_remove) := NULL]
gc()

# Create string date versions (used in multiple analyses)
df[, `:=`(
  #date_cancel_str = fifelse(is.na(date_cancel), NA_character_, 
  #                         tolower(format(date_cancel, "%d%b%Y"))),
  #date_contemp_str = fifelse(is.na(date_contemp), NA_character_, 
  #                          tolower(format(date_contemp, "%d%b%Y"))),
  #date_adesao_str = fifelse(is.na(date_adesao), NA_character_, 
  #                         tolower(format(date_adesao, "%d%b%Y"))),
  #date_base_str = tolower(format(date_base, "%d%b%Y")),
  
  # Year variables (commonly referenced)
  year_adesao = year(date_adesao),
  
  # Basic quarter variables
  quarter_adesao = quarter(date_adesao),
  quarter_contemp = quarter(date_contemp),
  year_contemp = year(date_contemp)
)]


# Converting to numerical values - vectorized approach for efficiency
# Define column mappings (old_name = new_name)
numeric_cols <- c("fct_pc_lance" = "pct_lance", "fct_pc_tx_adm" = "tx_adm", 
                  "fct_pc_tax_adm_antec" = "tx_adm_antecip", "fct_pc_amo_mensal" = "pct_amort_mensal",
                  "fct_vl_bem" = "valor_bem", "fct_pc_acu_amort" = "pct_amort_acumul",
                  "fct_vl_con_acu_fun_comum" = "fundo_comum_acumul", "fct_vl_con_acu_fun_reserva" = "fundo_reserva_acumul",
                  "fct_vl_con_acu_tx_adm" = "tx_adm_acumul", "fct_vl_con_acu_jur_multas" = "juros_multas_acumul",
                  "fct_vl_cre_dat_contemp" = "credit_contemp", "fct_pc_atraso" = "pct_atraso",
                  "fct_vl_ren_fat_men_cotista" = "renda_cotista")

integer_cols <- c("fct_qt_dur_plano" = "prazo")

# Convert all numeric columns at once
df[, (numeric_cols) := lapply(.SD, as.numeric), .SDcols = names(numeric_cols)]
df[, (integer_cols) := lapply(.SD, as.integer), .SDcols = names(integer_cols)]

# Clean up original numeric columns efficiently using defined vectors
df[, (c(names(numeric_cols), names(integer_cols))) := NULL]
gc()

# Categorical variables - efficient assignment
df[, `:=`(
  # Identifying individuals (=1), firms (=0) or non-identified
  #pessoa_fisica = fcase(
  #  fct_cd_tip_cotista == 2, 1,
  #  fct_cd_tip_cotista == 1, 0,
  #  fct_cd_tip_cotista == 3, NA_real_,
  #  default = NA_real_
  #),
  
  # Auction and lottery mechanisms
  auction = fifelse(fct_ib_contemp == "L", 1, 0),
  lottery = fifelse(fct_ib_contemp == "S", 1, 0),
  allocation_type = as.factor(fct_ib_contemp),
  
  # Quota status
  sit_atual = fct_st_atual
)]

# Clean up original categorical columns efficiently
categorical_cols_to_remove <- c("fct_ib_contemp", "fct_st_atual", "adm_cd2", "gai_cd_grupo2", "cpf2", 
                                "fct_st_bem", "fct_cd_seg", "fct_cd_uf_cota", "fct_dt_adi_terc", "fct_dt_aju_acao",
                                "fct_dt_ret_bem", "fct_ib_amo_men_variavel", "fct_ib_imv_construcao", "fct_vl_crd_enc_grupo",
                                "fct_pc_mul_res_grupo", "fct_pc_mul_res_adm")
df[, (categorical_cols_to_remove) := NULL]
gc()

# Create time relationship variables (used across quality + financial analysis)
df[, `:=`(
  earliest_date = min(date_base, na.rm = TRUE),
  quarter_min = quarter(min(date_base, na.rm = TRUE)),
  year_min = year(min(date_base, na.rm = TRUE))
), by = .(grupo_id, adm_id, cota_full_id, date_adesao)]

# Create adesao timing flag (used in financial analysis)
df[, adesao_min_flag := fifelse(
  (quarter_adesao == quarter_min) & (year_adesao == year_min), 
  1, 0
)]

# Create basic flags (used in multiple contexts)
df[, contemp_in_quarter := fifelse(
  !is.na(quarter_contemp) & !is.na(year_contemp) & 
  (quarter_contemp == quarter) & (year_contemp == year), 
  1, 0
)]

# Detecting monthly or trimester date by difference between two consecutive date_base
df[, data_frequency := fifelse(
  (date_base - lag(date_base)) <= 31, "monthly", "trimester"
), by = .(cota_full_id, grupo_id, adm_id, codigo_seg)]

# Fill missing frequency values (first observation in each group)
df[, data_frequency := fifelse(is.na(data_frequency), 
                               shift(data_frequency, type = "lead"), 
                               data_frequency), 
   by = .(cota_full_id, grupo_id, adm_id, codigo_seg)]

#%% Create binning variables for relative comparisons of values (EFFICIENT VERSION)
# Key insight: Only calculate quintiles for periods when people actually join

# Step 1: Identify first periods and capture initial values
df[, `:=`(
  first_date = min(date_base),
  valor_bem_initial = first(valor_bem),
  prazo_initial = first(prazo)
), by = .(cota_full_id, grupo_id, adm_id, codigo_seg)]

# Step 2: Simple, robust approach - separate calculation from assignment

# Create separate dataset with just first periods for quartile calculation  
first_periods <- df[date_base == first_date]

# Calculate group quartiles using random ranking method to break ties
# This ensures approximately equal counts per quartile within each group
first_periods[, quart_val_group := {
  r <- rank(valor_bem, ties.method = "random")
  dplyr::ntile(r, 4)
}, by = .(grupo_id, adm_id, codigo_seg, first_date)]

# Calculate segment quartiles using same method
first_periods[, `:=`(
  quart_val_seg = {
    r <- rank(valor_bem, ties.method = "random")
    dplyr::ntile(r, 4)
  },
  quart_dur_seg = {
    r <- rank(prazo, ties.method = "random")
    dplyr::ntile(r, 4)
  }
), by = .(codigo_seg, first_date)]

# Calculate max/min credit value indicators within groups
first_periods[, `:=`(
  max_credit_val = fifelse(credit_contemp == max(credit_contemp, na.rm = TRUE), 1, 0),
  min_credit_val = fifelse(credit_contemp == min(credit_contemp, na.rm = TRUE), 1, 0)
), by = .(grupo_id, adm_id, codigo_seg, first_date)]

# Simple, clean join back to main dataset - quartiles and credit indicators
quartile_lookup <- first_periods[, .(cota_full_id, quart_val_group, quart_val_seg, quart_dur_seg, 
                                     max_credit_val, min_credit_val)]

df[quartile_lookup, `:=`(
  quart_val_group = i.quart_val_group,
  quart_val_seg = i.quart_val_seg,
  quart_dur_seg = i.quart_dur_seg,
  max_credit_val = i.max_credit_val,
  min_credit_val = i.min_credit_val
), on = .(cota_full_id)]

#%% Sorting dataframe - data.table is much faster for large datasets
setorder(df, adm_id, grupo_id, cota_id, cota_sub_id, date_base)

df %>% head(1000) %>% View()

# Data description ----------------------------------------

# Run dataset description with correct column mappings
col_dict <- list(
  cpf = "cpf_id",              # CPF identifier column
  cota = "cota_id",            # Basic quota identifier  
  cota_seq = "cota_full_id",   # Full quota identifier with sequence
  grupo = "grupo_id",          # Group identifier
  adm = "adm_id",              # Administrator identifier
  segment = "codigo_seg",      # Segment identifier
  year = "year"            # Year variable (using minimum year)
)

# Fast export using data.table
# Save data description report to file based on environment
if(grepl("Project", getwd())) {
  output_file <- "data/code/centralbank/server/data/output/fct_data_description.txt"
} else {
  output_file <- "D:/server/data/output/fct_data_description.txt"
}

data_description(df, col_dict = col_dict, output_file = output_file, dataset_name = "FCT Panel")

# Exporting to .rds and .csv ------------------------------

# Fast export using data.table  
saveRDS(df, "contemplacoes_clean.rds")
fwrite(df, "contemplacoes_clean.csv")

# Use fread for faster file reading (header = TRUE is default)
if(grepl("Project", getwd())) {
  saveRDS(df, "data/code/centralbank/server/data/output/clean_FCT_panel.rds")
  fwrite(df, "data/code/centralbank/server/data/output/clean_FCT_panel.csv")
} else {
  saveRDS(df, "D:/server/data/output/clean_FCT_panel.rds")
  fwrite(df, "D:/server/data/output/clean_FCT_panel.csv")
}

# Print summary for verification
cat("Data cleaning completed successfully!\n")
cat("Final dataset dimensions:", dim(df), "\n")
cat("Memory usage:", format(object.size(df), units = "MB"), "\n")

