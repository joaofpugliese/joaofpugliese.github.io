# ---------------------------------------------- # 
#          Create Sample Datasets for Testing
# ---------------------------------------------- #
#
# Purpose: Sample 100 groups from each main dataset
# - Contemplacoes: 100 groups (cot_cd_cota, cot_cd_seq_cota, fct_cd_seg, adm_cd2, gai_cd_grupo2, cpf2)
# - FCT (fato_cota): 100 groups with ALL their time periods
# - Lance (fato_lance): 100 groups (adm_cd2, gai_cd_grupo2, fct_cd_seg) with ALL their auction records
#
# ---------------------------------------------- #

# File Paths (adjust as needed) -----------------
contemplacoes_path <- "D:/bases/cotas_05092025v2.txt"
fct_path <- "D:/bases/cotas_16092025v2.txt" 
lance_path <- "D:/bases/lance_201909"

# Packages ---------------------------------------
library(data.table)
library(dplyr)

# Set seed for reproducibility
set.seed(42)

cat("Starting sampling process...\n")

# ---------------------------------------------- #
# 1. CONTEMPLACOES
# ---------------------------------------------- #

cat("1. Sampling CONTEMPLACOES dataset...\n")

# Read dataset
contemp_full <- fread(contemplacoes_path, 
                      stringsAsFactors = FALSE, 
                      showProgress = TRUE)

# Transform to lowercase
setnames(contemp_full, tolower(names(contemp_full)))

# Group by: cot_cd_cota, cot_cd_seq_cota, fct_cd_seg, adm_cd2, gai_cd_grupo2, cpf2
group_cols <- c("cot_cd_cota2", "cot_cd_seq_cota", "fct_cd_seg", "adm_cd2", "gai_cd_grupo2", "cpf2")

# Get unique groups and sample 100
unique_groups <- contemp_full[, .N, by = group_cols]
sampled_groups <- unique_groups[sample(.N, min(100, .N))]

# Filter for sampled groups
contemp_sample <- contemp_full[sampled_groups, on = group_cols]

cat("   Sampled", nrow(sampled_groups), "unique groups\n")
cat("   Total rows:", nrow(contemp_sample), "\n")

# Export
fwrite(contemp_sample, "sample_contemplacoes.csv")
saveRDS(contemp_sample, "sample_contemplacoes.rds")
cat("   Exported to sample_contemplacoes.csv/.rds\n\n")

rm(contemp_full, unique_groups, sampled_groups)
gc()

# ---------------------------------------------- #
# 2. FCT (Fato Cota - Panel Data)
# ---------------------------------------------- #

cat("2. Sampling FCT dataset...\n")

# Read dataset
fct_full <- fread(fct_path, 
                  header = FALSE,
                  stringsAsFactors = FALSE, 
                  showProgress = TRUE)

# Set column names from first row and remove it
setnames(fct_full, as.character(fct_full[1,]))
fct_full <- fct_full[-1,]

# Transform to lowercase
setnames(fct_full, tolower(names(fct_full)))

# Group by: cot_cd_cota, cot_cd_seq_cota, fct_cd_seg, adm_cd2, gai_cd_grupo2, cpf2
group_cols <- c("cot_cd_cota2", "cot_cd_seq_cota", "fct_cd_seg", "adm_cd2", "gai_cd_grupo2", "cpf2")

# Get unique groups and sample 100
unique_groups <- fct_full[, .N, by = group_cols]
sampled_groups <- unique_groups[sample(.N, min(100, .N))]

# Filter for sampled groups (preserves panel structure)
fct_sample <- fct_full[sampled_groups, on = group_cols]

cat("   Sampled", nrow(sampled_groups), "unique groups\n")
cat("   Total rows (all periods):", nrow(fct_sample), "\n")

# Export
fwrite(fct_sample, "sample_FCT.csv")
saveRDS(fct_sample, "sample_FCT.rds")
cat("   Exported to sample_FCT.csv/.rds\n\n")

rm(fct_full, unique_groups, sampled_groups)
gc()

# ---------------------------------------------- #
# 3. LANCE (Fato Lance - Auction Data)
# ---------------------------------------------- #

cat("3. Sampling LANCE dataset...\n")

# Read dataset
lance_full <- fread(lance_path, 
                    header = FALSE,
                    stringsAsFactors = FALSE, 
                    showProgress = TRUE)

# Set column names from first row and remove it
setnames(lance_full, as.character(lance_full[1,]))
lance_full <- lance_full[-1,]

# Transform to lowercase
setnames(lance_full, tolower(names(lance_full)))

# Group by: adm_cd2, gai_cd_grupo2, fct_cd_seg
group_cols <- c("adm_cd2", "gai_cd_grupo2", "fct_cd_seg")

# Get unique groups and sample 100
unique_groups <- lance_full[, .N, by = group_cols]
sampled_groups <- unique_groups[sample(.N, min(100, .N))]

# Filter for sampled groups (preserves all auction records)
lance_sample <- lance_full[sampled_groups, on = group_cols]

cat("   Sampled", nrow(sampled_groups), "unique groups\n")
cat("   Total rows (all auction records):", nrow(lance_sample), "\n")

# Export
fwrite(lance_sample, "sample_lance.csv")
saveRDS(lance_sample, "sample_lance.rds")
cat("   Exported to sample_lance.csv/.rds\n\n")

rm(lance_full, unique_groups, sampled_groups)
gc()

# ---------------------------------------------- #
# Summary
# ---------------------------------------------- #

cat(paste0(rep("=", 60), collapse = ""), "\n")
cat("SAMPLING COMPLETE\n")
cat(paste0(rep("=", 60), collapse = ""), "\n")
cat("\nSample files created with 100 unique groups each:\n")
cat("  - Contemplacoes: Groups by (cot_cd_cota2, cot_cd_seq_cota, fct_cd_seg, adm_cd2, gai_cd_grupo2, cpf2)\n")
cat("  - FCT: Groups with all time periods (panel structure preserved)\n")
cat("  - Lance: Groups with all auction records (relational structure preserved)\n")
cat("\nFiles saved to current directory:\n")
cat("  - sample_contemplacoes.csv/.rds\n")
cat("  - sample_FCT.csv/.rds\n")
cat("  - sample_lance.csv/.rds\n")
