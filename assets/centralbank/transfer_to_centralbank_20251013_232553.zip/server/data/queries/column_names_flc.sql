SELECT *
FROM            sagdwpro_acc.sagtb_flc_fato_lance
LIMIT 1;