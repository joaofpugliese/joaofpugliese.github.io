/* === 100 cotas via QUALIFY + painel completo + merge 1:1 com FLC === */
WITH
-- (A) cota elegível: já contemplada por lance em qualquer mês (202212)
elig AS (
  SELECT DISTINCT fct_id_cot
  FROM   sagdwpro_acc.sagtb_fct_fato_cota
  WHERE  fct_ib_contemp = 'L'
    AND dac_dt_base IN (202212)
),

-- (B) amostragem de 100 cotas via QUALIFY (evita SAMPLE/FETCH)
cotas_100 AS (
  SELECT fct_id_cot
  FROM   elig
  QUALIFY ROW_NUMBER() OVER (
             ORDER BY RANDOM(1, 1000000000), fct_id_cot
          ) <= 100
),

-- (C) painel completo de FCT para essas cotas (todas as competências)
fct_panel_sample AS (
  SELECT f.*
  FROM   sagdwpro_acc.sagtb_fct_fato_cota f
  JOIN   cotas_100 s
         ON s.fct_id_cot = f.fct_id_cot
  /* opcional: filtrar janela de meses p/ performance
     WHERE f.dac_dt_base BETWEEN 201201 AND 202512 */
)

-- (D) merge FLC into panel (may create multiple rows per cota-month)
SELECT
    f.fct_id_cot,
    f.dac_dt_base, 
    f.cot_cd_cota2, -- Needs HASH mask
    f.cot_cd_seq_cota,
    f.cpf2, -- Needs HASH mask
    f.adm_cd2, -- Needs HASH mask
    f.gai_cd_grupo2, -- Needs HASH mask
    f.fct_st_bem,
    f.fct_cd_seg,
    f.fct_st_atual,
    f.fct_cd_uf_cota,
    f.fct_ib_contemp,
    f.fct_dt_adesao,
    f.fct_dt_contemp,
    f.fct_dt_adi_terc,
    f.fct_dt_aju_acao,
    f.fct_dt_ret_bem,
    f.fct_dt_can_cota,
    f.fct_ib_amo_men_variavel,
    f.fct_ib_imv_construcao,
    f.fct_qt_dur_plano,
    f.fct_pc_tax_adm_antec,
    f.fct_pc_tx_adm,
    f.fct_pc_amo_mensal,
    f.fct_vl_bem,
    f.fct_pc_acu_amort,
    f.fct_vl_con_acu_fun_comum,
    f.fct_vl_con_acu_fun_reserva,
    f.fct_vl_con_acu_tx_adm,
    f.fct_vl_con_acu_jur_multas,
    f.fct_pc_lance,
    f.fct_vl_cre_dat_contemp,
    f.fct_pc_atraso,
    f.fct_vl_crd_enc_grupo,
    f.fct_pc_mul_res_grupo,
    f.fct_pc_mul_res_adm,
    f.fct_vl_ren_fat_men_cotista,
    flc.flc_vl_lance,
    flc.flc_vl_lan_rec_prop,
    flc.flc_vl_lan_embutido,
    flc.flc_vl_rec_fgts
FROM fct_panel_sample f
LEFT JOIN sagdwpro_acc.sagtb_flc_fato_lance flc
  ON  flc.flc_id_lance = f.fct_id_cot
  AND flc.dac_dt_base  = f.dac_dt_base
ORDER BY f.fct_id_cot, f.dac_dt_base;
