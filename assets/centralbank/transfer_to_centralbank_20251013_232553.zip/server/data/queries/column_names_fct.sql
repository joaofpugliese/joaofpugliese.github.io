SELECT *
FROM            sagdwpro_acc.sagtb_fct_fato_cota
LIMIT 1;