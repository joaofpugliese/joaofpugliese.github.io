SELECT
    fct.fct_cd_seg,
    fct.adm_cd,
    fct.gai_cd_grupo,
    fct.dac_dt_base,

    COUNT(*) AS n_rows,

    MIN(fct.fct_vl_bem) AS min_fct_vl_bem,
    MAX(fct.fct_vl_bem) AS max_fct_vl_bem,

    MIN(fct.fct_qt_dur_plano) AS min_fct_qt_dur_plano,
    MAX(fct.fct_qt_dur_plano) AS max_fct_qt_dur_plano,
    /* Use one of the two lines below for median, depending on your TD version */
    -- MEDIAN(fct.fct_qt_dur_plano) AS median_fct_qt_dur_plano
    PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY fct.fct_qt_dur_plano) AS median_fct_qt_dur_plano,

    AVG(fct.fct_qt_dur_plano) AS avg_fct_qt_dur_plano,

    COUNT(fct.fct_dt_contemp)   AS n_nonnull_fct_dt_contemp,
    COUNT(fct.fct_dt_can_cota)  AS n_nonnull_fct_dt_can_cota,

    SUM(CASE WHEN fct.fct_ib_contemp = 'S' THEN 1 ELSE 0 END) AS n_ib_contemp_S,
    SUM(CASE WHEN fct.fct_ib_contemp = 'L' THEN 1 ELSE 0 END) AS n_ib_contemp_L,

    MIN(fct.fct_dt_adesao) AS min_fct_dt_adesao,
    MAX(fct.fct_dt_adesao) AS max_fct_dt_adesao,

    AVG(fct.fct_pc_lance) AS avg_fct_pc_lance,
    MAX(fct.fct_pc_lance) AS max_fct_pc_lance,
    MIN(fct.fct_pc_lance) AS min_fct_pc_lance

FROM sagdwpro_acc.sagtb_fct_fato_cota AS fct
-- Optional: restrict to canonical dates
-- WHERE fct.dac_dt_base IN (201212, 201512, 201812, 202112, 202412)
GROUP BY
    fct.fct_cd_seg, fct.adm_cd, fct.gai_cd_grupo, fct.dac_dt_base
ORDER BY
    fct.fct_cd_seg, fct.adm_cd, fct.gai_cd_grupo, fct.dac_dt_base;
