WITH aleat AS (
    SELECT DISTINCT
           fct_cd_seg,
           adm_cd,
           gai_cd_grupo
    FROM sagdwpro_acc.sagtb_fct_fato_cota
    WHERE dac_dt_base IN (201212, 201512, 201812, 202112, 202412)
),
aaa AS (
    SELECT aleat.*,
           RANDOM(0,100) AS rnd
    FROM aleat
),
fct_sample AS (
    SELECT fct.*
    FROM   sagdwpro_acc.sagtb_fct_fato_cota AS fct
    JOIN   aaa
           ON fct.fct_cd_seg   = aaa.fct_cd_seg
          AND fct.adm_cd       = aaa.adm_cd
          AND fct.gai_cd_grupo = aaa.gai_cd_grupo
    WHERE aaa.rnd <= 3
),
flc_filtered AS (
    SELECT
        flc.flc_id_lance,
        flc.dac_dt_base,
        flc.flc_vl_lance,
        flc.flc_vl_lan_rec_prop,
        flc.flc_vl_lan_embutido,
        flc.flc_vl_rec_fgts
    FROM sagdwpro_acc.sagtb_flc_fato_lance flc
),
fct_plus_flc AS (
    SELECT
        f.*,
        flc.flc_vl_lance,
        flc.flc_vl_lan_rec_prop,
        flc.flc_vl_lan_embutido,
        flc.flc_vl_rec_fgts
    FROM fct_sample f
    LEFT JOIN flc_filtered flc
           ON flc.flc_id_lance = f.fct_id_cot
          AND flc.dac_dt_base  = f.dac_dt_base
)
SELECT
    f.cot_cd_cota,
    f.cot_cd_seq_cota,
    f.fct_cd_seg,
    f.adm_cd2,
    f.gai_cd_grupo2,
    f.cpf2,
    COUNT(*)                        AS n_rows,
    MIN(f.fct_id_cot)               AS min_fct_id_cot,
    MAX(f.fct_id_cot)               AS max_fct_id_cot,
    MIN(f.dac_dt_base)              AS min_dac_dt_base,
    MAX(f.dac_dt_base)              AS max_dac_dt_base,
    MIN(f.fct_dt_contemp)           AS fct_dt_contemp_min,
    MAX(f.fct_dt_contemp)           AS fct_dt_contemp_max,
    MIN(f.fct_dt_can_cota)          AS fct_dt_can_cota_min,
    MAX(f.fct_dt_can_cota)          AS fct_dt_can_cota_max,
    MIN(f.fct_qt_dur_plano)         AS min_fct_qt_dur_plano,
    MAX(f.fct_qt_dur_plano)         AS max_fct_qt_dur_plano,
    MIN(f.fct_vl_bem)               AS min_fct_vl_bem,
    MAX(f.fct_vl_bem)               AS max_fct_vl_bem,
    MIN(f.fct_cd_tip_cotista)       AS min_fct_cd_tip_cotista,
    MAX(f.fct_cd_tip_cotista)       AS max_fct_cd_tip_cotista,
    MIN(f.fct_st_atual)             AS min_fct_st_atual,
    MAX(f.fct_st_atual)             AS max_fct_st_atual,
    MIN(f.fct_ib_contemp)           AS min_fct_ib_contemp,
    MAX(f.fct_ib_contemp)           AS max_fct_ib_contemp,
    MAX(f.fct_pc_lance)             AS max_fct_pc_lance,
    MIN(f.fct_pc_lance)             AS min_fct_pc_lance,
    MAX(f.fct_dt_adesao)            AS max_fct_pc_adesao,
    MIN(f.fct_dt_adesao)            AS min_fct_pc_adesao,
    MAX(f.fct_vl_cre_dat_contemp)   AS max_fct_vl_cre_dat_contemp,
    MIN(f.fct_vl_cre_dat_contemp)   AS min_fct_vl_cre_dat_contemp,

    /* FLC aggregates */
    MAX(f.flc_vl_lance)             AS flc_vl_lance_max,
    MIN(f.flc_vl_lance)             AS flc_vl_lance_min,
    MAX(f.flc_vl_lan_rec_prop)     AS flc_vl_lan_rec_prop_max,
    MIN(f.flc_vl_lan_rec_prop)     AS flc_vl_lan_rec_prop_min,
    MAX(f.flc_vl_lan_embutido)    AS flc_vl_lan_embutido_max,
    MIN(f.flc_vl_lan_embutido)    AS flc_vl_lan_embutido_min,
    MAX(f.flc_vl_rec_fgts)        AS flc_vl_lan_rec_fgts_max,
    MIN(f.flc_vl_rec_fgts)        AS flc_vl_lan_rec_fgts_min
FROM fct_plus_flc f
GROUP BY
    f.cot_cd_cota,
    f.cot_cd_seq_cota,
    f.fct_cd_seg,
    f.adm_cd2,
    f.gai_cd_grupo2,
    f.cpf2;
