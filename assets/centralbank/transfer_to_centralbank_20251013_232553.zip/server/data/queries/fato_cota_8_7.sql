WITH sampling_frame AS (
    SELECT
        adm_cd,
        gai_cd_grupo,
--        fct_cd_bem_admin,
        MAX(fct_cd_seg) as fct_cd_seg,
        MIN(YEAR(fct_dt_adesao)) AS min_adesao_year
    FROM sagdwpro_acc.sagtb_fct_fato_cota
    WHERE 1=1
        AND fct_dt_adesao IS NOT NULL
        AND fct_cd_seg IN (11, 31, 41)
        AND Year(fct_dt_adesao) >= 2005
    GROUP BY adm_cd, gai_cd_grupo, fct_cd_seg
),
-- 2) Attach a random integer (Teradata allows RANDOM(n) in the SELECT list)
with_rand AS (
  SELECT
    adm_cd,
    gai_cd_grupo,
--    fct_cd_bem_admin,
    fct_cd_seg,
    min_adesao_year,
    RANDOM(0,1000000) AS rnd
  FROM sampling_frame
),

-- 3) Number them within each (seg, year) by that random key
balanced_sample AS (
  SELECT
    adm_cd,
    gai_cd_grupo,
  --  fct_cd_bem_admin,
    fct_cd_seg,
    min_adesao_year,
    ROW_NUMBER() OVER (
      PARTITION BY fct_cd_seg, min_adesao_year
      ORDER BY rnd
    ) AS rn
  FROM with_rand
)

SELECT
    FCT.dac_dt_base,
    FCT.cot_cd_cota,
    FCT.cot_cd_seq_cota,
    FCT.adm_cd,
    FCT.gai_cd_grupo,
    FCT.fct_st_bem,
    FCT.fct_cd_seg,
    FCT.fct_st_atual, 
    FCT.fct_cd_uf_cota,
    FCT.fct_ib_contemp,
    FCT.fct_dt_adesao,
    FCT.fct_dt_contemp,
    FCT.fct_dt_adi_terc,
    FCT.fct_dt_aju_acao,
    FCT.fct_dt_ret_bem,
    FCT.fct_dt_can_cota,
    FCT.fct_ib_amo_men_variavel,
    FCT.fct_ib_imv_construcao,
    FCT.fct_qt_dur_plano,
    FCT.fct_pc_tax_adm_antec,
    FCT.fct_pc_tx_adm,
    FCT.fct_pc_amo_mensal,
    FCT.fct_vl_bem,
    FCT.fct_pc_acu_amort,
    FCT.fct_vl_con_acu_fun_comum,
    FCT.fct_vl_con_acu_fun_reserva,
    FCT.fct_vl_con_acu_tx_adm,
    FCT.fct_vl_con_acu_jur_multas,
    FCT.fct_pc_lance,
    FCT.fct_vl_cre_dat_contemp,
    FCT.fct_pc_atraso,
    FCT.fct_vl_crd_enc_grupo,
    FCT.fct_pc_mul_res_grupo,
    FCT.fct_pc_mul_res_adm,
    FCT.fct_vl_ren_fat_men_cotista
FROM
    sagdwpro_acc.sagtb_fct_fato_cota FCT
INNER JOIN balanced_sample
ON FCT.adm_cd = balanced_sample.adm_cd
    AND FCT.gai_cd_grupo = balanced_sample.gai_cd_grupo
   AND FCT.fct_cd_seg = balanced_sample.fct_cd_seg
WHERE
    balanced_sample.rn <= 5


