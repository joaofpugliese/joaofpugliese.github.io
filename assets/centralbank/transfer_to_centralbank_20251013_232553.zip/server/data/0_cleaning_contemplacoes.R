# ---------------------------------------------- # 
#          Data cleaning - Contemplações (Aggregated Dataset)
# ---------------------------------------------- # 
#
# This script cleans the aggregated contemplações dataset created by cotas_21_8.sql
# Unlike 0_cleaning_FCT.R, this is NOT a panel - each row is a unique cota
# with summary statistics aggregated over time
#
# Performance optimizations implemented:
# - data.table for faster operations (vs dplyr)
# - fread() for faster file import
# - Combined operations with := for modify-by-reference
# - Efficient type conversions and date parsing
# - Early memory cleanup and garbage collection
# ---------------------------------------------- #

# Packages ---------------------------------------

library(data.table)
library(lubridate)
library(dplyr)

# Importing dataset ------------------------------

# Use fread for faster file reading (header = TRUE is default)
# Add grepl to check if the working directory is Dropbox (outside server) or not
if(grepl("Dropbox", getwd())) {
  df <- fread("data/code/centralbank/server/data/mock_data/mock_contemplacoes_data.csv", stringsAsFactors = FALSE, showProgress = TRUE)
  source("data/code/centralbank/server/utils/data_description.R")
} else {
  df <- fread("D:/bases/cotas_05092025v2.txt", stringsAsFactors = FALSE, showProgress = TRUE)
  # Load data description function
  source("D:/server/utils/data_description.R")
}

# Data cleaning ----------------------------------

# Transform column names to lowercase
setnames(df, tolower(names(df)))

# Convert to data.table for faster operations
setDT(df)

# Create clean identifier variables (consistent with 0_cleaning_FCT.R naming)
df[, `:=`(
  # Core identifiers - consistent naming with main dataset
  cota_id = cot_cd_cota2,
  cota_sub_id = cot_cd_seq_cota,
  codigo_seg = fct_cd_seg,
  cpf_id = cpf2,
  
  # Factor conversion for admin and group IDs (consistent with main cleaning)
  adm_id = as.integer(as.factor(adm_cd2)),
  grupo_id = as.integer(as.factor(gai_cd_grupo2))
)]

# Create composite ID (consistent with main dataset)
df[, cota_full_id := paste(cota_id, cota_sub_id, sep = "-")]

# Clean up original ID columns
id_cols_to_remove <- c("cot_cd_cota2", "cot_cd_seq_cota", "fct_cd_seg", 
                       "cpf2", "adm_cd2", "gai_cd_grupo2")
df[, (id_cols_to_remove) := NULL]
gc()

# Convert time diagnostic variables to integers
time_diagnostic_cols <- c("n_rows" = "n_observations", 
                         "n_dates" = "n_periods")

df[, (time_diagnostic_cols) := lapply(.SD, as.integer), .SDcols = names(time_diagnostic_cols)]

# Clean up original time diagnostic columns
df[, (names(time_diagnostic_cols)) := NULL]
gc()

# Convert date variables - handle base date format (YYYYMM)
df[, `:=`(
  # Convert base dates from YYYYMM format to proper dates (last day of month)
  min_date_base = as.Date(paste0(substr(min_dac_dt_base, 1, 4), "-", 
                                substr(min_dac_dt_base, 5, 6), "-01")) + months(1) - days(1),
  max_date_base = as.Date(paste0(substr(max_dac_dt_base, 1, 4), "-", 
                                substr(max_dac_dt_base, 5, 6), "-01")) + months(1) - days(1),
  
  # Convert contemplation dates (assuming MM/DD/YYYY format like main dataset)
  min_date_contemp = as.Date(fct_dt_contemp_min, format = "%m/%d/%Y"),
  max_date_contemp = as.Date(fct_dt_contemp_max, format = "%m/%d/%Y"),
  
  # Convert adesao dates (assuming MM/DD/YYYY format like main dataset)
  min_date_adesao = as.Date(min_fct_pc_adesao, format = "%m/%d/%Y"),
  max_date_adesao = as.Date(max_fct_pc_adesao, format = "%m/%d/%Y")

)]

# Clean up original date columns
date_cols_to_remove <- c("min_dac_dt_base", "max_dac_dt_base", 
                        "fct_dt_contemp_min", "fct_dt_contemp_max")
df[, (date_cols_to_remove) := NULL]
gc()

# Convert numeric aggregate variables (duration and value statistics)
numeric_agg_cols <- c("min_fct_qt_dur_plano" = "min_prazo_obs",
                      "max_fct_qt_dur_plano" = "max_prazo_obs",
                      "min_fct_vl_bem" = "min_valor_bem_obs",
                      "max_fct_vl_bem" = "max_valor_bem_obs",
                      "min_fct_pc_lance" = "min_perc_lance",
                      "max_fct_pc_lance" = "max_perc_lance",
                      "min_fct_vl_cre_dat_contemp" = "min_vl_credito_contemp",
                      "max_fct_vl_cre_dat_contemp" = "max_vl_credito_contemp",
                      
                      # FLC auction variables
                      "flc_pc_lance_max" = "flc_perc_lance_max",
                      "flc_pc_lance_min" = "flc_perc_lance_min",
                      "flc_vl_lance_max" = "flc_vl_lance_max",
                      "flc_vl_lance_min" = "flc_vl_lance_min",
                      "flc_vl_lance_proprio_max" = "flc_vl_lance_proprio_max",
                      "flc_vl_lance_proprio_min" = "flc_vl_lance_proprio_min",
                      "flc_vl_lance_embutido_max" = "flc_vl_lance_embutido_max",
                      "flc_vl_lance_embutido_min" = "flc_vl_lance_embutido_min",
                      "flc_vl_lance_fgts_max" = "flc_vl_lance_fgts_max",
                      "flc_vl_lance_fgts_min" = "flc_vl_lance_fgts_min"
                      )

df[, (numeric_agg_cols) := lapply(.SD, as.numeric), .SDcols = names(numeric_agg_cols)]

# Clean up original numeric columns
df[, (names(numeric_agg_cols)) := NULL]
gc()

# Clean and mutate auction value variables
df[, `:=`(
  # Recalculate percentage lance from FLC values divided by bem values
  fct_pc_lance_input_valorbem_max = flc_vl_lance_max / max_valor_bem_obs,
  fct_pc_lance_input_valorbem_min = flc_vl_lance_min / min_valor_bem_obs,
  
  # Alternative: percentage lance from FLC values divided by credit at contemplation
  fct_pc_lance_input_contemp_max = flc_vl_lance_max / max_vl_credito_contemp,
  fct_pc_lance_input_contemp_min = flc_vl_lance_min / min_vl_credito_contemp,
  
  # Total auction value (sum of all lance components)
  fct_vl_lance_total_max = flc_vl_lance_proprio_max + flc_vl_lance_embutido_max + 
                           flc_vl_lance_fgts_max,
  fct_vl_lance_total_min = flc_vl_lance_proprio_min + flc_vl_lance_embutido_min + 
                           flc_vl_lance_fgts_min,

  fct_pc_lance_inputsum_contemp_max = fct_vl_lance_total_max / max_vl_credito_contemp,
  fct_pc_lance_inputsum_contemp_min = fct_vl_lance_total_min / min_vl_credito_contemp,

  # Percentage lance from total auction value divided by credit at contemplation
  fct_pc_lance_inputsum_contemp_max = fct_vl_lance_total_max / max_vl_credito_contemp,
  fct_pc_lance_inputsum_contemp_min = fct_vl_lance_total_min / min_vl_credito_contemp

)]

# Convert categorical diagnostic variables to integers
categorical_agg_cols <- c("dcount_fct_cd_tip_cotista" = "n_distinct_tip_cotista",
                         "dcount_fct_st_atual" = "n_distinct_status",
                         "dcount_fct_ib_contemp" = "n_distinct_allocation")

df[, (categorical_agg_cols) := lapply(.SD, as.integer), .SDcols = names(categorical_agg_cols)]

# Clean up original categorical diagnostic columns
df[, (names(categorical_agg_cols)) := NULL]
gc()

# Convert representative categorical values
categorical_rep_cols <- c("min_fct_cd_tip_cotista" = "min_tip_cotista",
                         "max_fct_cd_tip_cotista" = "max_tip_cotista",
                         "min_fct_st_atual" = "min_status",
                         "max_fct_st_atual" = "max_status")

df[, (categorical_rep_cols) := lapply(.SD, as.integer), .SDcols = names(categorical_rep_cols)]

df[, (names(categorical_rep_cols)) := NULL]
gc()

# Process allocation type variables (character/factor)
df[, `:=`(
  min_allocation_type = min_fct_ib_contemp,
  max_allocation_type = max_fct_ib_contemp
)]

# Create consistent allocation_type when min equals max (invariant across time)
df[, allocation_type := fifelse(
  min_allocation_type == max_allocation_type, 
  min_allocation_type, 
  NA_character_
)]

# Create consistent date_contemp when min equals max (consistent with 0_cleaning_FCT naming)
df[, date_contemp := fifelse(
  min_date_contemp == max_date_contemp, 
  min_date_contemp, 
  as.Date(NA)
)]

# Create consistent date_adesao when min equals max (consistent with 0_cleaning_FCT naming)
df[, date_adesao := fifelse(
  min_date_adesao == max_date_adesao, 
  min_date_adesao, 
  as.Date(NA)
)]

# Clean up original allocation columns
allocation_cols_to_remove <- c("min_fct_ib_contemp", "max_fct_ib_contemp",
                               "min_fct_pc_adesao", "max_fct_pc_adesao")
df[, (allocation_cols_to_remove) := NULL]
gc()


# Create derived time variables (consistent with main dataset approach)
df[, `:=`(
  # Time span variables
  time_span_months = as.numeric(max_date_base - min_date_base) / 30.44, # approximate months
  time_span_days = as.numeric(max_date_base - min_date_base),
  
  # Year variables for first and last periods
  year_min = year(min_date_base),
  year_max = year(max_date_base),
  year_contemp = year(date_contemp),
  year_adesao = year(date_adesao),
  
  # Data quality flags
  invariant_dt_contemp = fifelse(min_date_contemp == max_date_contemp, 1, 0),
  invariant_prazo = fifelse(min_prazo_obs == max_prazo_obs, 1, 0),
  invariant_valor_bem = fifelse(min_valor_bem_obs == max_valor_bem_obs, 1, 0),
  invariant_tip_cotista = fifelse(n_distinct_tip_cotista == 1, 1, 0),
  invariant_status = fifelse(n_distinct_status == 1, 1, 0),
  invariant_allocation = fifelse(n_distinct_allocation == 1, 1, 0),
  invariant_dt_adesao = fifelse(min_date_adesao == max_date_adesao, 1, 0),
  invariant_perc_lance = fifelse(min_perc_lance == max_perc_lance, 1, 0)
)]

# Create pessoa_fisica flag (consistent with main dataset)
df[, pessoa_fisica := fcase(
  min_tip_cotista == 2 & max_tip_cotista == 2, 1,  # Always individual
  min_tip_cotista == 1 & max_tip_cotista == 1, 0,  # Always firm
  min_tip_cotista == 3 & max_tip_cotista == 3, NA_real_, # Always unidentified
  default = NA_real_  # Mixed or other cases
)]

# Sorting dataframe for consistency
setorder(df, adm_id, grupo_id, cota_id, cota_full_id)

# Data Quality Summary and Dataset Description ------------------------------

# Quick invariant variables table
invariant_flags <- c("invariant_dt_contemp", "invariant_prazo", "invariant_valor_bem", 
                     "invariant_tip_cotista", "invariant_status", "invariant_allocation", 
                     "invariant_dt_adesao", "invariant_perc_lance")

invariant_summary <- sapply(invariant_flags, function(x) table(df[[x]]/sum(!is.na(df[[x]]))))

print(invariant_summary)
summary(df)

# Run dataset description with correct column mappings
col_dict <- list(
  cpf = "cpf_id",              # CPF identifier column
  cota = "cota_id",            # Basic quota identifier  
  cota_seq = "cota_full_id",   # Full quota identifier with sequence
  grupo = "grupo_id",          # Group identifier
  adm = "adm_id",              # Administrator identifier
  segment = "codigo_seg",      # Segment identifier
  year = "year_min"            # Year variable (using minimum year)
)

# Save data description report to file based on environment
if(grepl("Dropbox", getwd())) {
  output_file <- "data/code/centralbank/server/data/output/contemplacoes_cota_description.txt"
} else {
  output_file <- "D:/server/data/output/contemplacoes_cota_description.txt"
}

data_description(as.data.frame(df), col_dict = col_dict, output_file = output_file, dataset_name = "Contemplações")

# Exporting to .rds and .csv ------------------------------
# Use fread for faster file reading (header = TRUE is default)
if(grepl("Dropbox", getwd())) {
  saveRDS(df, "data/code/centralbank/server/data/output/contemplacoes_cota_level.rds")
  fwrite(df, "data/code/centralbank/server/data/output/contemplacoes_cota_level.csv")
} else {
  saveRDS(df, "D:/server/data/output/contemplacoes_cota_level.rds")
  fwrite(df, "D:/server/data/output/contemplacoes_cota_level.csv")
}
