# ---------------------------------------------- # 
#          Data cleaning - Lance
# ---------------------------------------------- #

# Packages ---------------------------------------
library(data.table)
library(dplyr)
library(lubridate)

# Read data --------------------------------------
if(grepl("Project", getwd())) {
  df <- fread("data/code/centralbank/server/data/sample_data/sample_lance.csv", 
              header = FALSE, stringsAsFactors = FALSE, showProgress = TRUE)
  source("data/code/centralbank/server/utils/data_description.R")
} else {
  df <- fread("D:/bases/lance_201909", 
              header = FALSE, stringsAsFactors = FALSE, showProgress = TRUE)
  source("D:/server/utils/data_description.R")
}

# Set column names and remove header row
setnames(df, as.character(df[1,]))
df <- df[-1,]

# Data cleaning ----------------------------------

# Convert to data.table for faster operations
setDT(df)

# Transform column names to lowercase
setnames(df, tolower(names(df)))

# ID variable cleaning following FCT pattern
df[, `:=`(
  # Date extraction
  year = as.numeric(substr(dac_dt_base, 1, 4)),
  month = as.numeric(substr(dac_dt_base, 5, 6)),
  
  # ID processing following FCT pattern
  codigo_seg = fct_cd_seg,
  adm_id = as.integer(as.factor(adm_cd2)),
  grupo_id = as.integer(as.factor(gai_cd_grupo2)),
  cota_id = cot_cd_cota2,
  cota_sub_id = cot_cd_seq_cota,
  cpf_id = cpf2
)]

# Create composite ID after other columns exist
df[, cota_full_id := paste(cota_id, cota_sub_id, sep = "-")]

# Treat dates
df[, `:=`(
  date_base = as.Date(paste0(year, "-", month, "-01")) + months(1) - days(1)
)]

# Add quarter after date_base is created
df[, quarter := quarter(date_base)]

# Clean up intermediate and original raw columns
cols_to_remove <- c("dac_dt_base", "cot_cd_cota2", "cot_cd_seq_cota")
df[, (cols_to_remove) := NULL]
gc()

# Convert the four lance value columns to numeric
lance_cols <- c("flc_vl_lance", "flc_vl_lan_rec_prop", "flc_vl_lan_embutido", "flc_vl_rec_fgts")
df[, (lance_cols) := lapply(.SD, as.numeric), .SDcols = lance_cols]

# Rename variables to remove "flc", change "lan" to lance, add "lance" to fgts
setnames(df, 
         old = c("flc_vl_lance", "flc_vl_lan_rec_prop", "flc_vl_lan_embutido", "flc_vl_rec_fgts"),
         new = c("vl_lance", "vl_lance_prop", "vl_lance_embut", "vl_lance_fgts"))

# Data description and export --------------------
col_dict <- list(
  cpf = "cpf_id",
  cota = "cota_id",
  cota_seq = "cota_full_id",
  grupo = "grupo_id",
  adm = "adm_id",
  segment = "codigo_seg",
  year = "year"
)

# Save data description report to file
if(grepl("Project", getwd())) {
  output_file <- "data/code/centralbank/server/data/output/lance_data_description.txt"
} else {
  output_file <- "D:/server/data/output/lance_data_description.txt"
}

data_description(df, col_dict = col_dict, output_file = output_file, dataset_name = "Bids Panel")

# Export to .rds and .csv
if(grepl("Dropbox", getwd())) {
  saveRDS(df, "data/code/centralbank/server/data/output/clean_bids_panel.rds")
  fwrite(df, "data/code/centralbank/server/data/output/clean_bids_panel.csv")
} else {
  saveRDS(df, "D:/server/data/output/clean_bids_panel.rds")
  fwrite(df, "D:/server/data/output/clean_bids_panel.csv")
}

# Print summary for verification
cat("\nData cleaning completed successfully!\n")
cat("Final dataset dimensions:", dim(df), "\n")
cat("Memory usage:", format(object.size(df), units = "MB"), "\n")
 